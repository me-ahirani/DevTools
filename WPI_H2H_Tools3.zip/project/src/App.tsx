import React, { useState } from 'react';
import Header from './components/Layout/Header';
import Navigation from './components/Layout/Navigation';
import Footer from './components/Layout/Footer';
import JsonGenerator from './components/Tools/JsonGenerator';
import DupCheck from './components/Tools/DupCheck';
import EnvComparison from './components/Tools/EnvComparison';
import PartnerStatus from './components/Tools/PartnerStatus';
import ClientStatus from './components/Tools/ClientStatus';

function App() {
  const [activeTab, setActiveTab] = useState('json-generator');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'json-generator':
        return <JsonGenerator />;
      case 'dup-check':
        return <DupCheck />;
      case 'env-comparison':
        return <EnvComparison />;
      case 'partner-status':
        return <PartnerStatus />;
      case 'client-status':
        return <ClientStatus />;
      default:
        return <JsonGenerator />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="flex flex-1">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            {renderActiveComponent()}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}

export default App;