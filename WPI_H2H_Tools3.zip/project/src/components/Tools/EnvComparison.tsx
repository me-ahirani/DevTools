import React, { useState } from 'react';
import { Search, ArrowRight } from 'lucide-react';

const EnvComparison: React.FC = () => {
  const [sourceEnv, setSourceEnv] = useState('');
  const [targetEnv, setTargetEnv] = useState('');
  const [partnerIds, setPartnerIds] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<any>(null);

  const environments = [
    'Development',
    'Testing',
    'Staging',
    'Production',
    'UAT',
    'Integration'
  ];

  const compareEnvironments = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const ids = partnerIds.split(',').map(id => id.trim()).filter(id => id);
      const result = {
        sourceEnvironment: sourceEnv,
        targetEnvironment: targetEnv,
        partnersCompared: ids.length,
        differences: [
          {
            partnerId: ids[0] || 'P001',
            field: 'status',
            sourceValue: 'active',
            targetValue: 'inactive',
            type: 'mismatch'
          },
          {
            partnerId: ids[1] || 'P002',
            field: 'configuration',
            sourceValue: 'enabled',
            targetValue: 'enabled',
            type: 'match'
          }
        ],
        summary: {
          matches: 1,
          mismatches: 1,
          missing: 0
        }
      };
      
      setComparisonResult(result);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Environment WPI Setup Comparison</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="sourceEnv" className="block text-sm font-medium text-gray-700 mb-2">
              Source Environment
            </label>
            <select
              id="sourceEnv"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={sourceEnv}
              onChange={(e) => setSourceEnv(e.target.value)}
            >
              <option value="">Select source environment</option>
              {environments.map(env => (
                <option key={env} value={env}>{env}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="targetEnv" className="block text-sm font-medium text-gray-700 mb-2">
              Target Environment
            </label>
            <select
              id="targetEnv"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={targetEnv}
              onChange={(e) => setTargetEnv(e.target.value)}
            >
              <option value="">Select target environment</option>
              {environments.map(env => (
                <option key={env} value={env}>{env}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="partnerIds" className="block text-sm font-medium text-gray-700 mb-2">
            Partner IDs (comma-separated)
          </label>
          <textarea
            id="partnerIds"
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter partner IDs to compare"
            value={partnerIds}
            onChange={(e) => setPartnerIds(e.target.value)}
          />
        </div>
        
        <button
          onClick={compareEnvironments}
          disabled={!sourceEnv || !targetEnv || !partnerIds.trim() || isLoading}
          className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center"
        >
          <Search className="w-4 h-4 mr-2" />
          {isLoading ? 'Comparing...' : 'Compare Environments'}
        </button>
      </div>

      {comparisonResult && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Comparison Results</h3>
          
          <div className="flex items-center justify-center mb-6">
            <div className="text-center">
              <span className="text-sm font-medium text-gray-600">{comparisonResult.sourceEnvironment}</span>
              <ArrowRight className="w-6 h-6 mx-4 text-gray-400" />
              <span className="text-sm font-medium text-gray-600">{comparisonResult.targetEnvironment}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{comparisonResult.summary.matches}</div>
              <div className="text-sm text-green-700">Matches</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{comparisonResult.summary.mismatches}</div>
              <div className="text-sm text-red-700">Mismatches</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{comparisonResult.summary.missing}</div>
              <div className="text-sm text-yellow-700">Missing</div>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900">Detailed Differences</h4>
            {comparisonResult.differences.map((diff: any, index: number) => (
              <div key={index} className={`p-4 rounded-lg border ${
                diff.type === 'match' 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-red-50 border-red-200'
              }`}>
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-medium">{diff.partnerId}</span>
                    <span className="mx-2">•</span>
                    <span className="text-gray-600">{diff.field}</span>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    diff.type === 'match' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {diff.type}
                  </span>
                </div>
                <div className="mt-2 text-sm">
                  <span className="text-gray-600">Source: </span>
                  <span className="font-mono">{diff.sourceValue}</span>
                  <span className="mx-4">→</span>
                  <span className="text-gray-600">Target: </span>
                  <span className="font-mono">{diff.targetValue}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EnvComparison;