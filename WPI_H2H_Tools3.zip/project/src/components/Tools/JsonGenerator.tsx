import React, { useState } from 'react';
import { Download, Copy, Check } from 'lucide-react';

const JsonGenerator: React.FC = () => {
  const [partnerIds, setPartnerIds] = useState('');
  const [generatedJson, setGeneratedJson] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateJson = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const ids = partnerIds.split(',').map(id => id.trim()).filter(id => id);
      const jsonData = {
        wpiSetup: {
          partnerIds: ids,
          configuration: {
            environment: "development",
            timestamp: new Date().toISOString(),
            version: "1.0.0"
          },
          partners: ids.map(id => ({
            partnerId: id,
            status: "active",
            settings: {
              enabled: true,
              priority: "high"
            }
          }))
        }
      };
      
      setGeneratedJson(JSON.stringify(jsonData, null, 2));
      setIsLoading(false);
    }, 1000);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJson = () => {
    const blob = new Blob([generatedJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'wpi-setup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Generate JSON for WPI Setup</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="partnerIds" className="block text-sm font-medium text-gray-700 mb-2">
              Partner IDs (comma-separated)
            </label>
            <textarea
              id="partnerIds"
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter partner IDs separated by commas (e.g., P001, P002, P003)"
              value={partnerIds}
              onChange={(e) => setPartnerIds(e.target.value)}
            />
          </div>
          
          <button
            onClick={generateJson}
            disabled={!partnerIds.trim() || isLoading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isLoading ? 'Generating...' : 'Generate JSON'}
          </button>
        </div>
      </div>

      {generatedJson && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Generated JSON</h3>
            <div className="flex space-x-2">
              <button
                onClick={copyToClipboard}
                className="px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-200 flex items-center"
              >
                {copied ? <Check className="w-4 h-4 mr-1" /> : <Copy className="w-4 h-4 mr-1" />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
              <button
                onClick={downloadJson}
                className="px-3 py-2 text-sm bg-green-100 text-green-700 rounded-md hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200 flex items-center"
              >
                <Download className="w-4 h-4 mr-1" />
                Download
              </button>
            </div>
          </div>
          
          <pre className="bg-gray-50 p-4 rounded-md overflow-x-auto text-sm">
            <code>{generatedJson}</code>
          </pre>
        </div>
      )}
    </div>
  );
};

export default JsonGenerator;