import React, { useState } from 'react';
import { Search, CheckCircle, XCircle, Clock } from 'lucide-react';

const PartnerStatus: React.FC = () => {
  const [partnerId, setPartnerId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusResult, setStatusResult] = useState<any>(null);

  const checkStatus = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const result = {
        partnerId: partnerId,
        exists: true,
        status: 'active',
        details: {
          createdDate: '2024-01-15',
          lastModified: '2024-12-20',
          environment: 'Production',
          configuration: {
            enabled: true,
            priority: 'high',
            settings: {
              autoSync: true,
              notifications: true,
              backup: true
            }
          }
        }
      };
      
      setStatusResult(result);
      setIsLoading(false);
    }, 1000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'inactive':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <XCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Check Partner/Client Status in WPI</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="partnerId" className="block text-sm font-medium text-gray-700 mb-2">
              Partner ID
            </label>
            <input
              type="text"
              id="partnerId"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter partner ID to check status"
              value={partnerId}
              onChange={(e) => setPartnerId(e.target.value)}
            />
          </div>
          
          <button
            onClick={checkStatus}
            disabled={!partnerId.trim() || isLoading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center"
          >
            <Search className="w-4 h-4 mr-2" />
            {isLoading ? 'Checking...' : 'Check Status'}
          </button>
        </div>
      </div>

      {statusResult && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Partner Status Results</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <span className="text-sm font-medium text-gray-600">Partner ID:</span>
                <span className="ml-2 font-mono text-gray-900">{statusResult.partnerId}</span>
              </div>
              <div className="flex items-center">
                {getStatusIcon(statusResult.status)}
                <span className={`ml-2 px-2 py-1 rounded text-sm font-medium ${
                  statusResult.status === 'active' ? 'bg-green-100 text-green-800' :
                  statusResult.status === 'inactive' ? 'bg-red-100 text-red-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {statusResult.status.charAt(0).toUpperCase() + statusResult.status.slice(1)}
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">Basic Information</h4>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-gray-600">Created:</span>
                    <span className="ml-2">{statusResult.details.createdDate}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Last Modified:</span>
                    <span className="ml-2">{statusResult.details.lastModified}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Environment:</span>
                    <span className="ml-2">{statusResult.details.environment}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">Configuration</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <span className="text-gray-600">Enabled:</span>
                    <span className="ml-2">
                      {statusResult.details.configuration.enabled ? 
                        <CheckCircle className="w-4 h-4 text-green-500" /> : 
                        <XCircle className="w-4 h-4 text-red-500" />
                      }
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-600">Priority:</span>
                    <span className={`ml-2 px-2 py-1 rounded text-xs ${
                      statusResult.details.configuration.priority === 'high' ? 'bg-red-100 text-red-800' :
                      statusResult.details.configuration.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {statusResult.details.configuration.priority}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Settings</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                {Object.entries(statusResult.details.configuration.settings).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-gray-600 capitalize">{key}:</span>
                    {value ? 
                      <CheckCircle className="w-4 h-4 text-green-500" /> : 
                      <XCircle className="w-4 h-4 text-red-500" />
                    }
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PartnerStatus;