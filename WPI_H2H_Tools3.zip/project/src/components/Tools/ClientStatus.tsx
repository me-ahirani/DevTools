import React, { useState } from 'react';
import { Search, Activity, AlertTriangle } from 'lucide-react';

const ClientStatus: React.FC = () => {
  const [clientId, setClientId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusResult, setStatusResult] = useState<any>(null);

  const checkClientStatus = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const result = {
        clientId: clientId,
        isActive: Math.random() > 0.3, // Random for demo
        lastActivity: '2024-12-20T10:30:00Z',
        details: {
          connectionStatus: 'connected',
          uptime: '99.8%',
          transactions: {
            total: 1250,
            successful: 1238,
            failed: 12
          },
          performance: {
            avgResponseTime: '150ms',
            throughput: '45 req/sec',
            errorRate: '0.96%'
          }
        }
      };
      
      setStatusResult(result);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Check Client ID Active Status in WPI</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="clientId" className="block text-sm font-medium text-gray-700 mb-2">
              Client ID
            </label>
            <input
              type="text"
              id="clientId"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter client ID to check active status"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
            />
          </div>
          
          <button
            onClick={checkClientStatus}
            disabled={!clientId.trim() || isLoading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center"
          >
            <Search className="w-4 h-4 mr-2" />
            {isLoading ? 'Checking...' : 'Check Client Status'}
          </button>
        </div>
      </div>

      {statusResult && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Client Activity Status</h3>
          
          <div className="space-y-6">
            <div className={`p-4 rounded-lg border-2 ${
              statusResult.isActive 
                ? 'bg-green-50 border-green-200' 
                : 'bg-red-50 border-red-200'
            }`}>
              <div className="flex items-center">
                <Activity className={`w-6 h-6 mr-3 ${
                  statusResult.isActive ? 'text-green-600' : 'text-red-600'
                }`} />
                <div>
                  <h4 className={`font-semibold ${
                    statusResult.isActive ? 'text-green-900' : 'text-red-900'
                  }`}>
                    Client ID: {statusResult.clientId}
                  </h4>
                  <p className={`text-sm ${
                    statusResult.isActive ? 'text-green-700' : 'text-red-700'
                  }`}>
                    Status: {statusResult.isActive ? 'ACTIVE' : 'INACTIVE'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Connection Details</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className={`font-medium ${
                      statusResult.details.connectionStatus === 'connected' 
                        ? 'text-green-600' 
                        : 'text-red-600'
                    }`}>
                      {statusResult.details.connectionStatus}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Uptime:</span>
                    <span className="font-medium">{statusResult.details.uptime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Activity:</span>
                    <span className="font-medium">
                      {new Date(statusResult.lastActivity).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Performance Metrics</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Avg Response:</span>
                    <span className="font-medium">{statusResult.details.performance.avgResponseTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Throughput:</span>
                    <span className="font-medium">{statusResult.details.performance.throughput}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Error Rate:</span>
                    <span className={`font-medium ${
                      parseFloat(statusResult.details.performance.errorRate) > 5 
                        ? 'text-red-600' 
                        : 'text-green-600'
                    }`}>
                      {statusResult.details.performance.errorRate}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Transaction Summary</h4>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {statusResult.details.transactions.total}
                  </div>
                  <div className="text-sm text-blue-700">Total</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {statusResult.details.transactions.successful}
                  </div>
                  <div className="text-sm text-green-700">Successful</div>
                </div>
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {statusResult.details.transactions.failed}
                  </div>
                  <div className="text-sm text-red-700">Failed</div>
                </div>
              </div>
            </div>
            
            {statusResult.details.transactions.failed > 10 && (
              <div className="flex items-start p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3 mt-0.5" />
                <div>
                  <h5 className="font-medium text-yellow-900">High Error Rate Detected</h5>
                  <p className="text-sm text-yellow-800 mt-1">
                    This client has experienced {statusResult.details.transactions.failed} failed transactions. 
                    Consider investigating the connection quality or reviewing recent changes.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientStatus;