import React from 'react';
import { Code } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-900 to-blue-800 shadow-lg border-b border-blue-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="bg-white rounded-lg p-2 mr-4">
            <Code className="w-8 h-8 text-blue-900" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">H2H Dev Tool Dashboard</h1>
            <p className="text-sm text-blue-100 mt-1">Development & Testing Utilities</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;