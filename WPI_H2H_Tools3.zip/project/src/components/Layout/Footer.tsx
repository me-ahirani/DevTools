import React from 'react';
import { Code } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-r from-blue-900 to-blue-800 border-t border-blue-700 px-6 py-4 mt-auto">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-white rounded p-1 mr-3">
              <Code className="w-6 h-6 text-blue-900" />
            </div>
            <div className="text-blue-100">
              <p className="text-sm font-medium">H2H Dev Tools</p>
              <p className="text-xs text-blue-200">Development Platform</p>
            </div>
          </div>
          
          <div className="text-right text-blue-100">
            <p className="text-sm">
              © JPMorgan Chase & Co. {currentYear} All rights reserved.
            </p>
            <p className="text-xs text-blue-200 mt-1">
              Internal Development Tools
            </p>
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-blue-700">
          <div className="flex items-center justify-between text-xs text-blue-200">
            <div className="flex space-x-4">
              <span>Internal Use Only</span>
              <span>•</span>
              <span>Version 1.0.0</span>
              <span>•</span>
              <span>Environment: Development</span>
            </div>
            <div>
              <span>Last Updated: {new Date().toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;