export interface Tool {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  featured?: boolean;
}

export interface ToolCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface FileData {
  id: string;
  name: string;
  type: 'json' | 'xml' | 'excel' | 'csv';
  data: any;
  headers?: string[];
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  template: string;
  variables: string[];
}

export interface TableRow {
  [key: string]: any;
}