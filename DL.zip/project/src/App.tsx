import React, { useState, useMemo } from 'react';
import { Layout } from './components/Layout';
import { CategorySection } from './components/CategorySection';
import { FileUploader } from './components/tools/FileUploader';
import { FileComparison } from './components/tools/FileComparison';
import { JSONCreator } from './components/tools/JSONCreator';
import { JSONFormatter } from './components/tools/JSONFormatter';
import { XMLFormatter } from './components/tools/XMLFormatter';
import { XMLXSDTools } from './components/tools/XMLXSDTools';
import { CSVGenerator } from './components/tools/CSVGenerator';
import { Base64Tool } from './components/tools/Base64Tool';
import { RegexGenerator } from './components/tools/RegexGenerator';
import { TokenGenerator } from './components/tools/TokenGenerator';
import { ColorPicker } from './components/tools/ColorPicker';
import { HashGenerator } from './components/tools/HashGenerator';
import { PasswordGenerator } from './components/tools/PasswordGenerator';
import { UUIDGenerator } from './components/tools/UUIDGenerator';
import { URLEncoder } from './components/tools/URLEncoder';
import { QRGenerator } from './components/tools/QRGenerator';
import { PDFTools } from './components/tools/PDFTools';
import { categories, tools } from './data/tools';
import { Tool } from './types';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);

  const filteredCategories = useMemo(() => {
    if (!searchTerm) return categories;
    
    const filtered = categories.filter(category => {
      const categoryTools = tools.filter(tool => tool.category === category.id);
      return categoryTools.some(tool => 
        tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tool.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
    
    return filtered;
  }, [searchTerm]);

  const getToolsForCategory = (categoryId: string) => {
    return tools.filter(tool => {
      if (tool.category !== categoryId) return false;
      if (!searchTerm) return true;
      
      return tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
             tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    });
  };

  const handleToolClick = (tool: Tool) => {
    setSelectedTool(tool);
  };

  const handleBackToTools = () => {
    setSelectedTool(null);
  };

  const renderToolComponent = () => {
    if (!selectedTool) return null;

    switch (selectedTool.id) {
      case 'file-uploader':
        return <FileUploader onBack={handleBackToTools} />;
      case 'file-comparison':
        return <FileComparison onBack={handleBackToTools} />;
      case 'json-creator':
        return <JSONCreator onBack={handleBackToTools} />;
      case 'json-formatter':
        return <JSONFormatter onBack={handleBackToTools} />;
      case 'xml-formatter':
        return <XMLFormatter onBack={handleBackToTools} />;
      case 'xml-xsd-tools':
        return <XMLXSDTools onBack={handleBackToTools} />;
      case 'csv-generator':
        return <CSVGenerator onBack={handleBackToTools} />;
      case 'base64-tool':
        return <Base64Tool onBack={handleBackToTools} />;
      case 'regex-generator':
        return <RegexGenerator onBack={handleBackToTools} />;
      case 'token-generator':
        return <TokenGenerator onBack={handleBackToTools} />;
      case 'color-picker':
        return <ColorPicker onBack={handleBackToTools} />;
      case 'hash-generator':
        return <HashGenerator onBack={handleBackToTools} />;
      case 'password-generator':
        return <PasswordGenerator onBack={handleBackToTools} />;
      case 'uuid-generator':
        return <UUIDGenerator onBack={handleBackToTools} />;
      case 'url-encoder':
        return <URLEncoder onBack={handleBackToTools} />;
      case 'qr-generator':
        return <QRGenerator onBack={handleBackToTools} />;
      case 'pdf-tools':
        return <PDFTools onBack={handleBackToTools} />;
      default:
        return (
          <div className="text-center py-12">
            <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Tool Coming Soon</h2>
              <p className="text-gray-600 mb-6">
                The {selectedTool.name} tool is currently under development.
              </p>
              <button
                onClick={handleBackToTools}
                className="px-6 py-3 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg transition-all transform hover:scale-105"
              >
                Back to Tools
              </button>
            </div>
          </div>
        );
    }
  };

  if (selectedTool) {
    return (
      <Layout searchTerm={searchTerm} onSearchChange={setSearchTerm}>
        {renderToolComponent()}
      </Layout>
    );
  }

  return (
    <Layout searchTerm={searchTerm} onSearchChange={setSearchTerm}>
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-jpmorgan-blue-600/20 to-jpmorgan-blue-700/20 blur-3xl rounded-full"></div>
          <div className="relative">
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-gray-900 via-gray-800 to-gray-700 bg-clip-text text-transparent mb-6">
              Professional Developer Tools
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Enterprise-grade utilities for modern development workflows. 
              Built with precision, designed for professionals.
            </p>
          </div>
        </div>
        
        {/* Featured Tools Quick Access */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {tools.filter(tool => tool.featured).map(tool => (
            <button
              key={tool.id}
              onClick={() => handleToolClick(tool)}
              className="px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg text-sm font-medium transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      {/* Tools by Category */}
      <div className="space-y-12">
        {filteredCategories.map(category => (
          <CategorySection
            key={category.id}
            category={category}
            tools={getToolsForCategory(category.id)}
            onToolClick={handleToolClick}
          />
        ))}
      </div>

      {searchTerm && filteredCategories.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-600 text-lg mb-4">
            No tools found for "{searchTerm}"
          </div>
          <button
            onClick={() => setSearchTerm('')}
            className="px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg transition-all"
          >
            Clear Search
          </button>
        </div>
      )}
    </Layout>
  );
}

export default App;