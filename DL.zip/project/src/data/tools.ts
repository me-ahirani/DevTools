import { Tool, ToolCategory } from '../types';

export const categories: ToolCategory[] = [
  {
    id: 'data-processing',
    name: 'Data Processing',
    description: 'Upload, edit, and manage data files',
    icon: 'Database'
  },
  {
    id: 'formatters',
    name: 'Formatters & Validators',
    description: 'Format and validate code and data',
    icon: 'Code'
  },
  {
    id: 'generators',
    name: 'Generators',
    description: 'Generate content and templates',
    icon: 'Sparkles'
  },
  {
    id: 'encoders',
    name: 'Encoders & Decoders',
    description: 'Encode and decode data formats',
    icon: 'Lock'
  },
  {
    id: 'comparison',
    name: 'File Comparison',
    description: 'Compare file differences',
    icon: 'GitCompare'
  },
  {
    id: 'utilities',
    name: 'Utilities',
    description: 'Additional developer tools',
    icon: 'Wrench'
  },
  {
    id: 'security',
    name: 'Security & Auth',
    description: 'Security tools and authentication',
    icon: 'Shield'
  }
];

export const tools: Tool[] = [
  {
    id: 'file-uploader',
    name: 'File Data Manager',
    description: 'Upload and edit JSON, XML, CSV, and Excel files with dynamic table interface',
    category: 'data-processing',
    icon: 'Upload',
    featured: true
  },
  {
    id: 'file-comparison',
    name: 'File Comparison Tool',
    description: 'Compare files side-by-side with detailed difference analysis',
    category: 'comparison',
    icon: 'GitCompare',
    featured: true
  },
  {
    id: 'json-creator',
    name: 'JSON Creator',
    description: 'Create JSON objects using form-based interface',
    category: 'generators',
    icon: 'Plus',
    featured: true
  },
  {
    id: 'json-formatter',
    name: 'JSON Formatter',
    description: 'Format, validate and prettify JSON data',
    category: 'formatters',
    icon: 'Braces',
    featured: true
  },
  {
    id: 'xml-formatter',
    name: 'XML Formatter',
    description: 'Format and validate XML documents',
    category: 'formatters',
    icon: 'FileCode'
  },
  {
    id: 'xml-xsd-tools',
    name: 'XML/XSD Tools',
    description: 'Convert between XML and XSD, validate XML against XSD schema',
    category: 'formatters',
    icon: 'FileCheck',
    featured: true
  },
  {
    id: 'csv-generator',
    name: 'CSV Generator',
    description: 'Generate CSV files from form data or templates',
    category: 'generators',
    icon: 'Table',
    featured: true
  },
  {
    id: 'base64-tool',
    name: 'Base64 Encoder/Decoder',
    description: 'Encode and decode Base64 strings',
    category: 'encoders',
    icon: 'Hash',
    featured: true
  },
  {
    id: 'regex-generator',
    name: 'Regex Generator',
    description: 'Generate, test, and validate regular expressions with input validation',
    category: 'formatters',
    icon: 'Search',
    featured: true
  },
  {
    id: 'token-generator',
    name: 'Token Generator',
    description: 'Generate OAuth tokens, JWT, API keys with CURL commands',
    category: 'security',
    icon: 'Key',
    featured: true
  },
  {
    id: 'color-picker',
    name: 'Color Picker',
    description: 'Pick colors and convert between formats',
    category: 'utilities',
    icon: 'Palette'
  },
  {
    id: 'hash-generator',
    name: 'Hash Generator',
    description: 'Generate MD5, SHA-1, SHA-256, and other hashes',
    category: 'encoders',
    icon: 'Shield'
  },
  {
    id: 'password-generator',
    name: 'Password Generator',
    description: 'Generate secure passwords with advanced customizable options',
    category: 'security',
    icon: 'Key'
  },
  {
    id: 'uuid-generator',
    name: 'UUID Generator',
    description: 'Generate unique identifiers (UUIDs)',
    category: 'generators',
    icon: 'Fingerprint'
  },
  {
    id: 'url-encoder',
    name: 'URL Encoder/Decoder',
    description: 'Encode and decode URLs for safe transmission',
    category: 'encoders',
    icon: 'Link'
  },
  {
    id: 'qr-generator',
    name: 'QR Code Generator',
    description: 'Generate QR codes for text, URLs, and data',
    category: 'generators',
    icon: 'QrCode'
  },
  {
    id: 'pdf-tools',
    name: 'PDF Tools',
    description: 'View and analyze PDF files',
    category: 'utilities',
    icon: 'FileText'
  }
];