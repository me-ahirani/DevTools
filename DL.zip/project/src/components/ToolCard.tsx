import React from 'react';
import * as Icons from 'lucide-react';
import { Tool } from '../types';

interface ToolCardProps {
  tool: Tool;
  onClick: (tool: Tool) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onClick }) => {
  const IconComponent = Icons[tool.icon as keyof typeof Icons] as React.ComponentType<any>;

  return (
    <div
      onClick={() => onClick(tool)}
      className="group relative bg-white rounded-xl p-6 border border-gray-200 hover:border-jpmorgan-blue-300 hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:scale-[1.02]"
    >
      {tool.featured && (
        <div className="absolute -top-2 -right-2 bg-jpmorgan-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-lg">
          Featured
        </div>
      )}
      
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
          <div className="w-12 h-12 bg-jpmorgan-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
            <IconComponent className="h-6 w-6 text-white" />
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-jpmorgan-blue-600 transition-colors">
            {tool.name}
          </h3>
          <p className="text-gray-600 text-sm mt-1 line-clamp-2">
            {tool.description}
          </p>
        </div>
      </div>
    </div>
  );
};