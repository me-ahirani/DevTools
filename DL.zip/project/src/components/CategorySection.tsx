import React from 'react';
import * as Icons from 'lucide-react';
import { ToolCategory, Tool } from '../types';
import { ToolCard } from './ToolCard';

interface CategorySectionProps {
  category: ToolCategory;
  tools: Tool[];
  onToolClick: (tool: Tool) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({ category, tools, onToolClick }) => {
  if (tools.length === 0) return null;

  const IconComponent = Icons[category.icon as keyof typeof Icons] as React.ComponentType<any>;

  return (
    <section className="mb-12">
      <div className="flex items-center space-x-4 mb-6">
        <div className="w-12 h-12 bg-jpmorgan-blue-600 rounded-lg flex items-center justify-center shadow-lg">
          <IconComponent className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{category.name}</h2>
          <p className="text-gray-600">{category.description}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <ToolCard key={tool.id} tool={tool} onClick={onToolClick} />
        ))}
      </div>
    </section>
  );
};