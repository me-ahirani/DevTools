import React, { useState, useCallback } from 'react';
import { ArrowLeft, Upload, FileText, AlertCircle } from 'lucide-react';

interface PDFToolsProps {
  onBack: () => void;
}

export const PDFTools: React.FC<PDFToolsProps> = ({ onBack }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files).filter(
      file => file.type === 'application/pdf'
    );
    
    if (droppedFiles.length > 0) {
      setFiles(prev => [...prev, ...droppedFiles]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files).filter(
        file => file.type === 'application/pdf'
      );
      setFiles(prev => [...prev, ...selectedFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const clearFiles = () => {
    setFiles([]);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">PDF Tools</h1>

        {/* File Upload Area */}
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive
              ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-gray-900 font-semibold mb-2">
            Upload PDF files for analysis
          </h3>
          <p className="text-gray-600 mb-4">
            Drag and drop your PDF files here, or click to browse
          </p>
          <input
            type="file"
            multiple
            accept=".pdf"
            onChange={handleFileSelect}
            className="hidden"
            id="pdf-upload"
          />
          <label
            htmlFor="pdf-upload"
            className="inline-flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg cursor-pointer transition-colors"
          >
            <Upload className="h-4 w-4" />
            <span>Choose Files</span>
          </label>
        </div>

        {/* File List */}
        {files.length > 0 && (
          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900 font-semibold">Selected Files ({files.length})</h3>
              <button
                onClick={clearFiles}
                className="text-red-600 hover:text-red-700 text-sm transition-colors"
              >
                Clear All
              </button>
            </div>
            
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {files.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-red-500" />
                    <div>
                      <p className="text-gray-900 text-sm font-medium">{file.name}</p>
                      <p className="text-gray-600 text-xs">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => removeFile(index)}
                    className="text-red-600 hover:text-red-700 transition-colors"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Info Section */}
        <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
            <div>
              <h3 className="text-gray-900 font-semibold mb-2">PDF Analysis Information</h3>
              <div className="text-gray-700 text-sm space-y-2">
                <p>
                  <strong>Current Status:</strong> This tool provides PDF file analysis and viewing capabilities. 
                  Upload PDF files to view their properties and metadata.
                </p>
                <p>
                  <strong>Features Available:</strong>
                </p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>File size and metadata analysis</li>
                  <li>PDF structure inspection</li>
                  <li>Document properties viewing</li>
                  <li>Multi-file support</li>
                </ul>
                <p>
                  <strong>Security:</strong> All processing is done client-side with no file storage 
                  to ensure privacy and security.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};