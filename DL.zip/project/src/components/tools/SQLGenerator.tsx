import React, { useState } from 'react';
import { ArrowLeft, Copy, Check, Download, Database, Plus, Trash2, Upload, Save, Code } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface SQLGeneratorProps {
  onBack: () => void;
}

interface TableColumn {
  id: string;
  name: string;
  type: string;
  nullable: boolean;
  primaryKey: boolean;
  defaultValue?: string;
}

interface SQLCondition {
  id: string;
  column: string;
  operator: string;
  value: string;
}

interface GroupByClause {
  column: string;
  having?: string;
}

interface OrderByClause {
  column: string;
  direction: 'ASC' | 'DESC';
}

interface SQLFunction {
  id: string;
  function: string;
  column: string;
  alias?: string;
}

export const SQLGenerator: React.FC<SQLGeneratorProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'select' | 'insert' | 'update' | 'delete' | 'create' | 'java-entity'>('select');
  const [tableName, setTableName] = useState('users');
  const [columns, setColumns] = useState<TableColumn[]>([
    { id: '1', name: 'id', type: 'INT', nullable: false, primaryKey: true },
    { id: '2', name: 'name', type: 'VARCHAR(255)', nullable: false, primaryKey: false },
    { id: '3', name: 'email', type: 'VARCHAR(255)', nullable: false, primaryKey: false },
    { id: '4', name: 'created_at', type: 'TIMESTAMP', nullable: true, primaryKey: false, defaultValue: 'CURRENT_TIMESTAMP' }
  ]);
  const [conditions, setConditions] = useState<SQLCondition[]>([]);
  const [selectedColumns, setSelectedColumns] = useState<string[]>(['*']);
  const [sqlFunctions, setSqlFunctions] = useState<SQLFunction[]>([]);
  const [insertValues, setInsertValues] = useState<Record<string, string>>({});
  const [updateValues, setUpdateValues] = useState<Record<string, string>>({});
  const [groupBy, setGroupBy] = useState<GroupByClause>({ column: '', having: '' });
  const [orderBy, setOrderBy] = useState<OrderByClause[]>([]);
  const [limit, setLimit] = useState<string>('');
  const [javaEntityCode, setJavaEntityCode] = useState('');
  const [sqlOutput, setSqlOutput] = useState('');
  const [copied, setCopied] = useState(false);

  const dataTypes = [
    'INT', 'BIGINT', 'SMALLINT', 'TINYINT',
    'VARCHAR(255)', 'VARCHAR(100)', 'VARCHAR(50)', 'TEXT', 'LONGTEXT',
    'DECIMAL(10,2)', 'FLOAT', 'DOUBLE',
    'BOOLEAN', 'BIT',
    'DATE', 'DATETIME', 'TIMESTAMP', 'TIME', 'YEAR',
    'JSON', 'BLOB', 'BINARY'
  ];

  const operators = [
    '=', '!=', '<>', '<', '>', '<=', '>=', 'LIKE', 'NOT LIKE', 
    'IN', 'NOT IN', 'IS NULL', 'IS NOT NULL', 'BETWEEN', 'NOT BETWEEN'
  ];

  const sqlFunctionTypes = [
    'COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'DISTINCT',
    'UPPER', 'LOWER', 'LENGTH', 'SUBSTRING', 'CONCAT',
    'NOW', 'CURDATE', 'YEAR', 'MONTH', 'DAY',
    'ABS', 'ROUND', 'CEIL', 'FLOOR', 'SQRT'
  ];

  const addColumn = () => {
    const newColumn: TableColumn = {
      id: Date.now().toString(),
      name: '',
      type: 'VARCHAR(255)',
      nullable: true,
      primaryKey: false
    };
    setColumns([...columns, newColumn]);
  };

  const removeColumn = (id: string) => {
    setColumns(columns.filter(col => col.id !== id));
  };

  const updateColumn = (id: string, updates: Partial<TableColumn>) => {
    setColumns(columns.map(col => 
      col.id === id ? { ...col, ...updates } : col
    ));
  };

  const addCondition = () => {
    const newCondition: SQLCondition = {
      id: Date.now().toString(),
      column: columns[0]?.name || '',
      operator: '=',
      value: ''
    };
    setConditions([...conditions, newCondition]);
  };

  const removeCondition = (id: string) => {
    setConditions(conditions.filter(cond => cond.id !== id));
  };

  const updateCondition = (id: string, updates: Partial<SQLCondition>) => {
    setConditions(conditions.map(cond => 
      cond.id === id ? { ...cond, ...updates } : cond
    ));
  };

  const addSqlFunction = () => {
    const newFunction: SQLFunction = {
      id: Date.now().toString(),
      function: 'COUNT',
      column: columns[0]?.name || '*',
      alias: ''
    };
    setSqlFunctions([...sqlFunctions, newFunction]);
  };

  const removeSqlFunction = (id: string) => {
    setSqlFunctions(sqlFunctions.filter(func => func.id !== id));
  };

  const updateSqlFunction = (id: string, updates: Partial<SQLFunction>) => {
    setSqlFunctions(sqlFunctions.map(func => 
      func.id === id ? { ...func, ...updates } : func
    ));
  };

  const addOrderBy = () => {
    const newOrderBy: OrderByClause = {
      column: columns[0]?.name || '',
      direction: 'ASC'
    };
    setOrderBy([...orderBy, newOrderBy]);
  };

  const removeOrderBy = (index: number) => {
    setOrderBy(orderBy.filter((_, i) => i !== index));
  };

  const updateOrderBy = (index: number, updates: Partial<OrderByClause>) => {
    setOrderBy(orderBy.map((item, i) => 
      i === index ? { ...item, ...updates } : item
    ));
  };

  const generateSQL = () => {
    let sql = '';
    
    switch (activeTab) {
      case 'select':
        sql = generateSelectSQL();
        break;
      case 'insert':
        sql = generateInsertSQL();
        break;
      case 'update':
        sql = generateUpdateSQL();
        break;
      case 'delete':
        sql = generateDeleteSQL();
        break;
      case 'create':
        sql = generateCreateTableSQL();
        break;
      case 'java-entity':
        sql = generateSQLFromJavaEntity();
        break;
    }
    
    setSqlOutput(sql);
  };

  const generateSelectSQL = () => {
    let selectClause = '';
    
    if (sqlFunctions.length > 0) {
      const functionClauses = sqlFunctions.map(func => {
        let clause = '';
        if (func.function === 'DISTINCT') {
          clause = `DISTINCT ${func.column}`;
        } else if (['COUNT', 'SUM', 'AVG', 'MIN', 'MAX'].includes(func.function)) {
          clause = `${func.function}(${func.column})`;
        } else if (['UPPER', 'LOWER', 'LENGTH'].includes(func.function)) {
          clause = `${func.function}(${func.column})`;
        } else if (func.function === 'SUBSTRING') {
          clause = `SUBSTRING(${func.column}, 1, 10)`;
        } else if (func.function === 'CONCAT') {
          clause = `CONCAT(${func.column}, ' - suffix')`;
        } else if (['NOW', 'CURDATE'].includes(func.function)) {
          clause = `${func.function}()`;
        } else if (['YEAR', 'MONTH', 'DAY'].includes(func.function)) {
          clause = `${func.function}(${func.column})`;
        } else if (['ABS', 'ROUND', 'CEIL', 'FLOOR', 'SQRT'].includes(func.function)) {
          clause = `${func.function}(${func.column})`;
        }
        
        if (func.alias) {
          clause += ` AS ${func.alias}`;
        }
        
        return clause;
      });
      
      const regularColumns = selectedColumns.includes('*') ? [] : selectedColumns;
      const allColumns = [...regularColumns, ...functionClauses];
      selectClause = allColumns.length > 0 ? allColumns.join(', ') : '*';
    } else {
      selectClause = selectedColumns.includes('*') ? '*' : selectedColumns.join(', ');
    }
    
    let sql = `SELECT ${selectClause}\nFROM ${tableName}`;
    
    if (conditions.length > 0) {
      const whereClause = conditions
        .filter(cond => cond.column && cond.value)
        .map(cond => {
          if (cond.operator === 'IS NULL' || cond.operator === 'IS NOT NULL') {
            return `${cond.column} ${cond.operator}`;
          }
          if (cond.operator === 'LIKE' || cond.operator === 'NOT LIKE') {
            return `${cond.column} ${cond.operator} '%${cond.value}%'`;
          }
          if (cond.operator === 'IN' || cond.operator === 'NOT IN') {
            return `${cond.column} ${cond.operator} (${cond.value})`;
          }
          if (cond.operator === 'BETWEEN' || cond.operator === 'NOT BETWEEN') {
            const values = cond.value.split(',').map(v => v.trim());
            if (values.length === 2) {
              return `${cond.column} ${cond.operator} '${values[0]}' AND '${values[1]}'`;
            }
          }
          return `${cond.column} ${cond.operator} '${cond.value}'`;
        })
        .join(' AND ');
      
      if (whereClause) {
        sql += `\nWHERE ${whereClause}`;
      }
    }

    if (groupBy.column) {
      sql += `\nGROUP BY ${groupBy.column}`;
      if (groupBy.having) {
        sql += `\nHAVING ${groupBy.having}`;
      }
    }

    if (orderBy.length > 0) {
      const orderClause = orderBy
        .filter(order => order.column)
        .map(order => `${order.column} ${order.direction}`)
        .join(', ');
      if (orderClause) {
        sql += `\nORDER BY ${orderClause}`;
      }
    }

    if (limit) {
      sql += `\nLIMIT ${limit}`;
    }
    
    sql += ';';
    return sql;
  };

  const generateInsertSQL = () => {
    const validColumns = columns.filter(col => col.name.trim());
    const insertCols = validColumns.filter(col => insertValues[col.name]);
    
    if (insertCols.length === 0) {
      return `-- Please specify values for at least one column\nINSERT INTO ${tableName} () VALUES ();`;
    }
    
    const columnNames = insertCols.map(col => col.name).join(', ');
    const values = insertCols.map(col => `'${insertValues[col.name] || ''}'`).join(', ');
    
    return `INSERT INTO ${tableName} (${columnNames})\nVALUES (${values});`;
  };

  const generateUpdateSQL = () => {
    const validColumns = columns.filter(col => col.name.trim());
    const updateCols = validColumns.filter(col => updateValues[col.name]);
    
    if (updateCols.length === 0) {
      return `-- Please specify values to update\nUPDATE ${tableName} SET;`;
    }
    
    const setClause = updateCols
      .map(col => `${col.name} = '${updateValues[col.name] || ''}'`)
      .join(',\n       ');
    
    let sql = `UPDATE ${tableName}\nSET ${setClause}`;
    
    if (conditions.length > 0) {
      const whereClause = conditions
        .filter(cond => cond.column && cond.value)
        .map(cond => {
          if (cond.operator === 'IS NULL' || cond.operator === 'IS NOT NULL') {
            return `${cond.column} ${cond.operator}`;
          }
          return `${cond.column} ${cond.operator} '${cond.value}'`;
        })
        .join(' AND ');
      
      if (whereClause) {
        sql += `\nWHERE ${whereClause}`;
      }
    }
    
    sql += ';';
    return sql;
  };

  const generateDeleteSQL = () => {
    let sql = `DELETE FROM ${tableName}`;
    
    if (conditions.length > 0) {
      const whereClause = conditions
        .filter(cond => cond.column && cond.value)
        .map(cond => {
          if (cond.operator === 'IS NULL' || cond.operator === 'IS NOT NULL') {
            return `${cond.column} ${cond.operator}`;
          }
          return `${cond.column} ${cond.operator} '${cond.value}'`;
        })
        .join(' AND ');
      
      if (whereClause) {
        sql += `\nWHERE ${whereClause}`;
      }
    } else {
      sql += '\n-- WARNING: This will delete ALL records! Add WHERE conditions to be safe.';
    }
    
    sql += ';';
    return sql;
  };

  const generateCreateTableSQL = () => {
    const validColumns = columns.filter(col => col.name.trim());
    
    if (validColumns.length === 0) {
      return `-- Please add at least one column\nCREATE TABLE ${tableName} ();`;
    }

    let sql = `CREATE TABLE ${tableName} (\n`;
    
    const columnDefinitions = validColumns.map(col => {
      let def = `  ${col.name} ${col.type}`;
      
      if (!col.nullable) {
        def += ' NOT NULL';
      }
      
      if (col.defaultValue) {
        def += ` DEFAULT ${col.defaultValue}`;
      }
      
      return def;
    });

    sql += columnDefinitions.join(',\n');

    // Add primary key constraint
    const primaryKeys = validColumns.filter(col => col.primaryKey);
    if (primaryKeys.length > 0) {
      const pkColumns = primaryKeys.map(col => col.name).join(', ');
      sql += `,\n  PRIMARY KEY (${pkColumns})`;
    }

    sql += '\n);';
    return sql;
  };

  const generateSQLFromJavaEntity = () => {
    if (!javaEntityCode.trim()) {
      return '-- Please enter Java entity code to generate SQL';
    }

    try {
      const entityColumns = parseJavaEntity(javaEntityCode);
      if (entityColumns.length === 0) {
        return '-- No valid fields found in Java entity';
      }

      // Extract table name from class name
      const classNameMatch = javaEntityCode.match(/class\s+(\w+)/);
      const entityTableName = classNameMatch ? classNameMatch[1].toLowerCase() : 'entity_table';

      let sql = `CREATE TABLE ${entityTableName} (\n`;
      
      const columnDefinitions = entityColumns.map(col => {
        let def = `  ${col.name} ${col.type}`;
        
        if (!col.nullable) {
          def += ' NOT NULL';
        }
        
        if (col.defaultValue) {
          def += ` DEFAULT ${col.defaultValue}`;
        }
        
        return def;
      });

      sql += columnDefinitions.join(',\n');

      // Add primary key constraint
      const primaryKeys = entityColumns.filter(col => col.primaryKey);
      if (primaryKeys.length > 0) {
        const pkColumns = primaryKeys.map(col => col.name).join(', ');
        sql += `,\n  PRIMARY KEY (${pkColumns})`;
      }

      sql += '\n);';
      return sql;
    } catch (error) {
      return '-- Error parsing Java entity: ' + error;
    }
  };

  const parseJavaEntity = (javaCode: string): TableColumn[] => {
    const columns: TableColumn[] = [];
    const lines = javaCode.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // Skip comments and empty lines
      if (line.startsWith('//') || line.startsWith('/*') || !line) continue;
      
      // Look for field declarations
      const fieldMatch = line.match(/private\s+(\w+(?:<[^>]+>)?)\s+(\w+);?/);
      if (fieldMatch) {
        const javaType = fieldMatch[1];
        const fieldName = fieldMatch[2];
        
        // Check for annotations in previous lines
        let isId = false;
        let isNullable = true;
        
        for (let j = Math.max(0, i - 3); j < i; j++) {
          const prevLine = lines[j].trim();
          if (prevLine.includes('@Id') || prevLine.includes('@GeneratedValue')) {
            isId = true;
          }
          if (prevLine.includes('@NotNull') || prevLine.includes('@Column') && prevLine.includes('nullable = false')) {
            isNullable = false;
          }
        }
        
        const sqlType = mapJavaTypeToSQL(javaType);
        
        columns.push({
          id: (columns.length + 1).toString(),
          name: camelToSnakeCase(fieldName),
          type: sqlType,
          nullable: isNullable && !isId,
          primaryKey: isId,
          defaultValue: isId ? undefined : getDefaultValueForType(sqlType)
        });
      }
    }
    
    return columns;
  };

  const mapJavaTypeToSQL = (javaType: string): string => {
    const typeMap: Record<string, string> = {
      'String': 'VARCHAR(255)',
      'Integer': 'INT',
      'int': 'INT',
      'Long': 'BIGINT',
      'long': 'BIGINT',
      'Double': 'DOUBLE',
      'double': 'DOUBLE',
      'Float': 'FLOAT',
      'float': 'FLOAT',
      'Boolean': 'BOOLEAN',
      'boolean': 'BOOLEAN',
      'Date': 'DATETIME',
      'LocalDate': 'DATE',
      'LocalDateTime': 'DATETIME',
      'Timestamp': 'TIMESTAMP',
      'BigDecimal': 'DECIMAL(10,2)',
      'byte[]': 'BLOB'
    };
    
    // Handle generic types like List<String>
    const baseType = javaType.replace(/<.*>/, '');
    
    return typeMap[baseType] || 'VARCHAR(255)';
  };

  const camelToSnakeCase = (str: string): string => {
    return str.replace(/([A-Z])/g, '_$1').toLowerCase().replace(/^_/, '');
  };

  const getDefaultValueForType = (sqlType: string): string | undefined => {
    if (sqlType.includes('TIMESTAMP')) return 'CURRENT_TIMESTAMP';
    if (sqlType.includes('BOOLEAN')) return 'false';
    return undefined;
  };

  React.useEffect(() => {
    generateSQL();
  }, [activeTab, tableName, columns, conditions, selectedColumns, sqlFunctions, insertValues, updateValues, groupBy, orderBy, limit, javaEntityCode]);

  const handleCopy = async () => {
    if (sqlOutput) {
      const success = await copyToClipboard(sqlOutput);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (sqlOutput) {
      downloadFile(sqlOutput, `${activeTab}-query.sql`, 'text/plain');
    }
  };

  const loadTableFromSQL = (sqlContent: string) => {
    try {
      // Improved parsing of CREATE TABLE statement
      const createTableMatch = sqlContent.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?(\w+)`?\s*\(([\s\S]*?)\)(?:\s*ENGINE|;|$)/i);
      if (createTableMatch) {
        const extractedTableName = createTableMatch[1];
        const columnsText = createTableMatch[2];
        
        setTableName(extractedTableName);
        
        // Parse columns with better regex
        const columnLines = columnsText.split(',').map(line => line.trim());
        const newColumns: TableColumn[] = [];
        
        columnLines.forEach((line, index) => {
          // Skip PRIMARY KEY, FOREIGN KEY, INDEX, etc.
          if (line.toLowerCase().match(/^\s*(primary\s+key|foreign\s+key|index|key|constraint)/)) return;
          
          // Match column definition: column_name data_type [NOT NULL] [DEFAULT value]
          const columnMatch = line.match(/^\s*`?(\w+)`?\s+(\w+(?:\([^)]+\))?)\s*(.*)/i);
          if (columnMatch) {
            const name = columnMatch[1];
            const type = columnMatch[2].toUpperCase();
            const constraints = columnMatch[3].toLowerCase();
            
            const nullable = !constraints.includes('not null');
            const primaryKey = constraints.includes('primary key') || 
                             columnsText.toLowerCase().includes(`primary key (${name.toLowerCase()})`);
            
            // Extract default value
            const defaultMatch = constraints.match(/default\s+([^,\s]+)/i);
            const defaultValue = defaultMatch ? defaultMatch[1].replace(/['"]/g, '') : undefined;
            
            newColumns.push({
              id: (index + 1).toString(),
              name,
              type,
              nullable,
              primaryKey,
              defaultValue
            });
          }
        });
        
        if (newColumns.length > 0) {
          setColumns(newColumns);
        }
      }
    } catch (error) {
      console.error('Error parsing SQL:', error);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        const content = await e.target.files[0].text();
        loadTableFromSQL(content);
      } catch (error) {
        console.error('Error reading file:', error);
      }
    }
  };

  const loadTemplate = (template: string) => {
    switch (template) {
      case 'users':
        setTableName('users');
        setColumns([
          { id: '1', name: 'id', type: 'INT', nullable: false, primaryKey: true },
          { id: '2', name: 'username', type: 'VARCHAR(50)', nullable: false, primaryKey: false },
          { id: '3', name: 'email', type: 'VARCHAR(255)', nullable: false, primaryKey: false },
          { id: '4', name: 'password_hash', type: 'VARCHAR(255)', nullable: false, primaryKey: false },
          { id: '5', name: 'created_at', type: 'TIMESTAMP', nullable: true, primaryKey: false, defaultValue: 'CURRENT_TIMESTAMP' },
          { id: '6', name: 'is_active', type: 'BOOLEAN', nullable: true, primaryKey: false, defaultValue: 'true' }
        ]);
        break;
      case 'products':
        setTableName('products');
        setColumns([
          { id: '1', name: 'id', type: 'INT', nullable: false, primaryKey: true },
          { id: '2', name: 'name', type: 'VARCHAR(255)', nullable: false, primaryKey: false },
          { id: '3', name: 'description', type: 'TEXT', nullable: true, primaryKey: false },
          { id: '4', name: 'price', type: 'DECIMAL(10,2)', nullable: false, primaryKey: false },
          { id: '5', name: 'category_id', type: 'INT', nullable: true, primaryKey: false },
          { id: '6', name: 'in_stock', type: 'BOOLEAN', nullable: true, primaryKey: false, defaultValue: 'true' }
        ]);
        break;
      case 'orders':
        setTableName('orders');
        setColumns([
          { id: '1', name: 'id', type: 'INT', nullable: false, primaryKey: true },
          { id: '2', name: 'user_id', type: 'INT', nullable: false, primaryKey: false },
          { id: '3', name: 'total_amount', type: 'DECIMAL(10,2)', nullable: false, primaryKey: false },
          { id: '4', name: 'status', type: 'VARCHAR(50)', nullable: false, primaryKey: false, defaultValue: "'pending'" },
          { id: '5', name: 'order_date', type: 'DATETIME', nullable: false, primaryKey: false, defaultValue: 'CURRENT_TIMESTAMP' },
          { id: '6', name: 'shipping_address', type: 'TEXT', nullable: true, primaryKey: false }
        ]);
        break;
    }
    setConditions([]);
    setInsertValues({});
    setUpdateValues({});
    setGroupBy({ column: '', having: '' });
    setOrderBy([]);
    setLimit('');
    setSqlFunctions([]);
  };

  const loadJavaEntityExample = () => {
    setJavaEntityCode(`@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 50)
    private String username;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @Column(name = "password_hash", nullable = false)
    private String passwordHash;
    
    @Column(name = "first_name")
    private String firstName;
    
    @Column(name = "last_name")
    private String lastName;
    
    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;
    
    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    private BigDecimal salary;
    
    // Getters and setters...
}`);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">Advanced SQL Generator</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!sqlOutput}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!sqlOutput}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Templates and File Upload */}
        <div className="mb-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Quick Templates</h3>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => loadTemplate('users')}
                  className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
                >
                  Users Table
                </button>
                <button
                  onClick={() => loadTemplate('products')}
                  className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
                >
                  Products Table
                </button>
                <button
                  onClick={() => loadTemplate('orders')}
                  className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
                >
                  Orders Table
                </button>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">Load from SQL</h3>
              <div className="flex space-x-2">
                <input
                  type="file"
                  accept=".sql,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="sql-file-upload"
                />
                <label
                  htmlFor="sql-file-upload"
                  className="flex items-center space-x-2 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm cursor-pointer transition-colors"
                >
                  <Upload className="h-4 w-4" />
                  <span>Load Table</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* SQL Type Tabs */}
        <div className="flex space-x-2 mb-6 overflow-x-auto">
          {(['select', 'insert', 'update', 'delete', 'create', 'java-entity'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setActiveTab(type)}
              className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === type
                  ? 'bg-primary-600 text-white'
                  : 'bg-white/10 text-gray-300 hover:bg-white/20'
              }`}
            >
              {type === 'java-entity' ? 'Java Entity' : type.toUpperCase()}
            </button>
          ))}
        </div>

        {activeTab === 'java-entity' ? (
          // Java Entity to SQL Tab
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Java Entity to SQL Converter</h3>
              <button
                onClick={loadJavaEntityExample}
                className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors"
              >
                Load Example
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Java Entity Code
                </label>
                <textarea
                  value={javaEntityCode}
                  onChange={(e) => setJavaEntityCode(e.target.value)}
                  placeholder="Paste your Java entity class here..."
                  className="w-full h-96 p-4 bg-black/30 border border-white/20 rounded-lg text-white font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Generated CREATE TABLE SQL
                </label>
                <textarea
                  value={sqlOutput}
                  readOnly
                  placeholder="Generated SQL will appear here..."
                  className="w-full h-96 p-4 bg-black/30 border border-white/20 rounded-lg text-gray-300 font-mono text-sm resize-none focus:outline-none"
                />
              </div>
            </div>
            
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <h4 className="text-white font-semibold mb-2 flex items-center space-x-2">
                <Code className="h-5 w-5" />
                <span>Java Entity Converter Features</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-300">
                <div>
                  <h5 className="font-medium text-white mb-1">Supported Annotations:</h5>
                  <ul className="space-y-1">
                    <li>• @Entity, @Table</li>
                    <li>• @Id, @GeneratedValue</li>
                    <li>• @Column (nullable, length)</li>
                    <li>• @NotNull validation</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-medium text-white mb-1">Type Mapping:</h5>
                  <ul className="space-y-1">
                    <li>• String → VARCHAR(255)</li>
                    <li>• Integer/Long → INT/BIGINT</li>
                    <li>• LocalDate → DATE</li>
                    <li>• LocalDateTime → DATETIME</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-medium text-white mb-1">Features:</h5>
                  <ul className="space-y-1">
                    <li>• Automatic primary key detection</li>
                    <li>• Camel to snake case conversion</li>
                    <li>• Default value generation</li>
                    <li>• Constraint mapping</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Configuration Panel */}
            <div className="space-y-6">
              {/* Table Name */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Table Name
                </label>
                <input
                  type="text"
                  value={tableName}
                  onChange={(e) => setTableName(e.target.value)}
                  className="w-full px-3 py-2 bg-black/30 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              {/* Columns */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-md font-semibold text-white">Table Columns</h4>
                  <button
                    onClick={addColumn}
                    className="flex items-center space-x-1 px-2 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-colors"
                  >
                    <Plus className="h-3 w-3" />
                    <span>Add</span>
                  </button>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {columns.map((column) => (
                    <div key={column.id} className="bg-black/30 rounded-lg p-3 border border-white/10">
                      <div className="grid grid-cols-12 gap-2 items-center">
                        <div className="col-span-3">
                          <input
                            type="text"
                            placeholder="Column name"
                            value={column.name}
                            onChange={(e) => updateColumn(column.id, { name: e.target.value })}
                            className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                          />
                        </div>
                        <div className="col-span-3">
                          <select
                            value={column.type}
                            onChange={(e) => updateColumn(column.id, { type: e.target.value })}
                            className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                          >
                            {dataTypes.map(type => (
                              <option key={type} value={type}>{type}</option>
                            ))}
                          </select>
                        </div>
                        <div className="col-span-2">
                          <input
                            type="text"
                            placeholder="Default"
                            value={column.defaultValue || ''}
                            onChange={(e) => updateColumn(column.id, { defaultValue: e.target.value })}
                            className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                          />
                        </div>
                        <div className="col-span-2 flex space-x-1">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              checked={column.nullable}
                              onChange={(e) => updateColumn(column.id, { nullable: e.target.checked })}
                              className="w-3 h-3 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                            />
                            <span className="ml-1 text-xs text-gray-300">NULL</span>
                          </label>
                        </div>
                        <div className="col-span-1 flex space-x-1">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              checked={column.primaryKey}
                              onChange={(e) => updateColumn(column.id, { primaryKey: e.target.checked })}
                              className="w-3 h-3 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                            />
                            <span className="ml-1 text-xs text-gray-300">PK</span>
                          </label>
                        </div>
                        <div className="col-span-1">
                          <button
                            onClick={() => removeColumn(column.id)}
                            className="w-full p-1 text-red-400 hover:text-red-300 transition-colors"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SELECT specific options */}
              {activeTab === 'select' && (
                <>
                  <div>
                    <h4 className="text-md font-semibold text-white mb-3">Select Columns</h4>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={selectedColumns.includes('*')}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedColumns(['*']);
                            } else {
                              setSelectedColumns([]);
                            }
                          }}
                          className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                        />
                        <span className="ml-2 text-gray-300">* (All columns)</span>
                      </label>
                      {!selectedColumns.includes('*') && columns.filter(col => col.name.trim()).map(column => (
                        <label key={column.id} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={selectedColumns.includes(column.name)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedColumns([...selectedColumns.filter(col => col !== '*'), column.name]);
                              } else {
                                setSelectedColumns(selectedColumns.filter(col => col !== column.name));
                              }
                            }}
                            className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                          />
                          <span className="ml-2 text-gray-300">{column.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* SQL Functions */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-md font-semibold text-white">SQL Functions</h4>
                      <button
                        onClick={addSqlFunction}
                        className="flex items-center space-x-1 px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-sm transition-colors"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Add Function</span>
                      </button>
                    </div>
                    <div className="space-y-2">
                      {sqlFunctions.map((func) => (
                        <div key={func.id} className="bg-black/30 rounded-lg p-3 border border-white/10">
                          <div className="grid grid-cols-12 gap-2 items-center">
                            <div className="col-span-3">
                              <select
                                value={func.function}
                                onChange={(e) => updateSqlFunction(func.id, { function: e.target.value })}
                                className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                              >
                                {sqlFunctionTypes.map(funcType => (
                                  <option key={funcType} value={funcType}>{funcType}</option>
                                ))}
                              </select>
                            </div>
                            <div className="col-span-3">
                              <select
                                value={func.column}
                                onChange={(e) => updateSqlFunction(func.id, { column: e.target.value })}
                                className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                              >
                                <option value="*">*</option>
                                {columns.filter(col => col.name.trim()).map(column => (
                                  <option key={column.id} value={column.name}>{column.name}</option>
                                ))}
                              </select>
                            </div>
                            <div className="col-span-5">
                              <input
                                type="text"
                                placeholder="Alias (optional)"
                                value={func.alias || ''}
                                onChange={(e) => updateSqlFunction(func.id, { alias: e.target.value })}
                                className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                              />
                            </div>
                            <div className="col-span-1">
                              <button
                                onClick={() => removeSqlFunction(func.id)}
                                className="w-full p-1 text-red-400 hover:text-red-300 transition-colors"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* GROUP BY */}
                  <div>
                    <h4 className="text-md font-semibold text-white mb-3">Group By</h4>
                    <div className="space-y-2">
                      <select
                        value={groupBy.column}
                        onChange={(e) => setGroupBy({...groupBy, column: e.target.value})}
                        className="w-full px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                      >
                        <option value="">No grouping</option>
                        {columns.filter(col => col.name.trim()).map(column => (
                          <option key={column.id} value={column.name}>{column.name}</option>
                        ))}
                      </select>
                      {groupBy.column && (
                        <input
                          type="text"
                          placeholder="HAVING clause (e.g., COUNT(*) > 5)"
                          value={groupBy.having}
                          onChange={(e) => setGroupBy({...groupBy, having: e.target.value})}
                          className="w-full px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                        />
                      )}
                    </div>
                  </div>

                  {/* ORDER BY */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-md font-semibold text-white">Order By</h4>
                      <button
                        onClick={addOrderBy}
                        className="flex items-center space-x-1 px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Add</span>
                      </button>
                    </div>
                    <div className="space-y-2">
                      {orderBy.map((order, index) => (
                        <div key={index} className="flex space-x-2 items-center">
                          <select
                            value={order.column}
                            onChange={(e) => updateOrderBy(index, { column: e.target.value })}
                            className="flex-1 px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                          >
                            <option value="">Select column</option>
                            {columns.filter(col => col.name.trim()).map(column => (
                              <option key={column.id} value={column.name}>{column.name}</option>
                            ))}
                          </select>
                          <select
                            value={order.direction}
                            onChange={(e) => updateOrderBy(index, { direction: e.target.value as 'ASC' | 'DESC' })}
                            className="px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                          >
                            <option value="ASC">ASC</option>
                            <option value="DESC">DESC</option>
                          </select>
                          <button
                            onClick={() => removeOrderBy(index)}
                            className="p-1 text-red-400 hover:text-red-300 transition-colors"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* LIMIT */}
                  <div>
                    <h4 className="text-md font-semibold text-white mb-3">Limit</h4>
                    <input
                      type="number"
                      placeholder="Number of rows"
                      value={limit}
                      onChange={(e) => setLimit(e.target.value)}
                      className="w-full px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                    />
                  </div>
                </>
              )}

              {/* INSERT specific options */}
              {activeTab === 'insert' && (
                <div>
                  <h4 className="text-md font-semibold text-white mb-3">Insert Values</h4>
                  <div className="space-y-2">
                    {columns.filter(col => col.name.trim()).map(column => (
                      <div key={column.id}>
                        <label className="block text-xs text-gray-300 mb-1">{column.name}</label>
                        <input
                          type="text"
                          placeholder={`Value for ${column.name}`}
                          value={insertValues[column.name] || ''}
                          onChange={(e) => setInsertValues({...insertValues, [column.name]: e.target.value})}
                          className="w-full px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* UPDATE specific options */}
              {activeTab === 'update' && (
                <div>
                  <h4 className="text-md font-semibold text-white mb-3">Update Values</h4>
                  <div className="space-y-2">
                    {columns.filter(col => col.name.trim()).map(column => (
                      <div key={column.id}>
                        <label className="block text-xs text-gray-300 mb-1">{column.name}</label>
                        <input
                          type="text"
                          placeholder={`New value for ${column.name}`}
                          value={updateValues[column.name] || ''}
                          onChange={(e) => setUpdateValues({...updateValues, [column.name]: e.target.value})}
                          className="w-full px-2 py-1 bg-black/30 border border-white/20 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* WHERE Conditions */}
              {(activeTab === 'select' || activeTab === 'update' || activeTab === 'delete') && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-md font-semibold text-white">WHERE Conditions</h4>
                    <button
                      onClick={addCondition}
                      className="flex items-center space-x-1 px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors"
                    >
                      <Plus className="h-3 w-3" />
                      <span>Add</span>
                    </button>
                  </div>
                  <div className="space-y-2">
                    {conditions.map((condition) => (
                      <div key={condition.id} className="bg-black/30 rounded-lg p-3 border border-white/10">
                        <div className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-4">
                            <select
                              value={condition.column}
                              onChange={(e) => updateCondition(condition.id, { column: e.target.value })}
                              className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                            >
                              <option value="">Select column</option>
                              {columns.filter(col => col.name.trim()).map(column => (
                                <option key={column.id} value={column.name}>{column.name}</option>
                              ))}
                            </select>
                          </div>
                          <div className="col-span-3">
                            <select
                              value={condition.operator}
                              onChange={(e) => updateCondition(condition.id, { operator: e.target.value })}
                              className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500"
                            >
                              {operators.map(op => (
                                <option key={op} value={op}>{op}</option>
                              ))}
                            </select>
                          </div>
                          <div className="col-span-4">
                            <input
                              type="text"
                              placeholder={
                                condition.operator === 'BETWEEN' || condition.operator === 'NOT BETWEEN' 
                                  ? 'value1, value2' 
                                  : 'Value'
                              }
                              value={condition.value}
                              onChange={(e) => updateCondition(condition.id, { value: e.target.value })}
                              disabled={condition.operator === 'IS NULL' || condition.operator === 'IS NOT NULL'}
                              className="w-full px-2 py-1 bg-dark-800 border border-white/30 rounded text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary-500 disabled:opacity-50"
                            />
                          </div>
                          <div className="col-span-1">
                            <button
                              onClick={() => removeCondition(condition.id)}
                              className="w-full p-1 text-red-400 hover:text-red-300 transition-colors"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* SQL Output */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Generated SQL</h3>
              <textarea
                value={sqlOutput}
                readOnly
                placeholder="Generated SQL will appear here..."
                className="w-full h-96 p-4 bg-black/30 border border-white/20 rounded-lg text-gray-300 font-mono text-sm resize-none focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* Help Section */}
        <div className="mt-8 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <h4 className="text-white font-semibold mb-2 flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>Advanced SQL Generator Features</span>
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 text-sm text-gray-300">
            <div>
              <h5 className="font-medium text-white mb-1">SELECT:</h5>
              <ul className="space-y-1">
                <li>• Column selection</li>
                <li>• SQL functions</li>
                <li>• GROUP BY & HAVING</li>
                <li>• ORDER BY & LIMIT</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-white mb-1">Functions:</h5>
              <ul className="space-y-1">
                <li>• COUNT, SUM, AVG</li>
                <li>• MIN, MAX, DISTINCT</li>
                <li>• String functions</li>
                <li>• Math operations</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-white mb-1">INSERT:</h5>
              <ul className="space-y-1">
                <li>• Column values</li>
                <li>• Auto-generate syntax</li>
                <li>• Data type handling</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-white mb-1">UPDATE:</h5>
              <ul className="space-y-1">
                <li>• Set new values</li>
                <li>• WHERE conditions</li>
                <li>• Multiple columns</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-white mb-1">CREATE TABLE:</h5>
              <ul className="space-y-1">
                <li>• Column definitions</li>
                <li>• Data types & constraints</li>
                <li>• Primary keys</li>
                <li>• Default values</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-white mb-1">Java Entity:</h5>
              <ul className="space-y-1">
                <li>• JPA annotation parsing</li>
                <li>• Type mapping</li>
                <li>• Constraint detection</li>
                <li>• Auto table generation</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};