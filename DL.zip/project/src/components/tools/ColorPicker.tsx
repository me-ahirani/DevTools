import React, { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, Palette } from 'lucide-react';
import { copyToClipboard } from '../../utils/fileUtils';

interface ColorPickerProps {
  onBack: () => void;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({ onBack }) => {
  const [selectedColor, setSelectedColor] = useState('#3B82F6');
  const [colorFormats, setColorFormats] = useState<Record<string, string>>({});
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const rgbToHsl = (r: number, g: number, b: number) => {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;

    if (max === min) {
      h = s = 0;
    } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
        default: h = 0;
      }
      h /= 6;
    }

    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    };
  };

  const updateColorFormats = (hex: string) => {
    const rgb = hexToRgb(hex);
    if (!rgb) return;

    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    
    setColorFormats({
      hex: hex.toUpperCase(),
      rgb: `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`,
      rgba: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 1)`,
      hsl: `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`,
      hsla: `hsla(${hsl.h}, ${hsl.s}%, ${hsl.l}%, 1)`,
      css: `color: ${hex.toLowerCase()};`,
      tailwind: `bg-[${hex.toLowerCase()}]`
    });
  };

  useEffect(() => {
    updateColorFormats(selectedColor);
  }, [selectedColor]);

  const handleCopy = async (format: string, value: string) => {
    const success = await copyToClipboard(value);
    if (success) {
      setCopiedFormat(format);
      setTimeout(() => setCopiedFormat(null), 2000);
    }
  };

  const formatLabels = {
    hex: 'HEX',
    rgb: 'RGB',
    rgba: 'RGBA',
    hsl: 'HSL',
    hsla: 'HSLA',
    css: 'CSS',
    tailwind: 'Tailwind'
  };

  const predefinedColors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
    '#F8C471', '#82E0AA', '#F1948A', '#85C1E9', '#F0E68C'
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h1 className="text-2xl font-bold text-white mb-6">Color Picker & Converter</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Color Picker Section */}
          <div>
            <h2 className="text-xl font-semibold text-white mb-4">Pick a Color</h2>
            
            {/* Main Color Display */}
            <div className="mb-6">
              <div 
                className="w-full h-32 rounded-lg border-4 border-white shadow-lg"
                style={{ backgroundColor: selectedColor }}
              />
              <div className="mt-4 flex items-center space-x-4">
                <input
                  type="color"
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-16 h-16 rounded-lg border-2 border-white/20 cursor-pointer"
                />
                <div>
                  <p className="text-white font-semibold">{selectedColor.toUpperCase()}</p>
                  <p className="text-gray-300 text-sm">Click to pick a color</p>
                </div>
              </div>
            </div>

            {/* Predefined Colors */}
            <div>
              <h3 className="text-lg font-medium text-white mb-3">Quick Colors</h3>
              <div className="grid grid-cols-5 gap-2">
                {predefinedColors.map((color, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedColor(color)}
                    className={`w-12 h-12 rounded-lg border-2 transition-all hover:scale-110 ${
                      selectedColor.toLowerCase() === color.toLowerCase()
                        ? 'border-white shadow-lg'
                        : 'border-white/20'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Color Formats Section */}
          <div>
            <h2 className="text-xl font-semibold text-white mb-4">Color Formats</h2>
            <div className="space-y-3">
              {Object.entries(colorFormats).map(([format, value]) => (
                <div key={format} className="bg-black/30 rounded-lg p-4 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-white font-medium">{formatLabels[format as keyof typeof formatLabels]}</h3>
                    <button
                      onClick={() => handleCopy(format, value)}
                      className="flex items-center space-x-2 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                    >
                      {copiedFormat === format ? (
                        <>
                          <Check className="h-4 w-4" />
                          <span className="text-xs">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4" />
                          <span className="text-xs">Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <code className="text-gray-300 font-mono text-sm break-all bg-black/50 rounded p-2 block">
                    {value}
                  </code>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
          <h3 className="text-white font-semibold mb-2 flex items-center space-x-2">
            <Palette className="h-5 w-5" />
            <span>Color Tips</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
            <div>
              <h4 className="font-medium text-white mb-1">Format Usage:</h4>
              <ul className="space-y-1">
                <li>• HEX: Web development, design</li>
                <li>• RGB: CSS, digital displays</li>
                <li>• HSL: More intuitive color adjustments</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-white mb-1">Accessibility:</h4>
              <ul className="space-y-1">
                <li>• Ensure sufficient contrast ratios</li>
                <li>• Test with colorblind simulators</li>
                <li>• Use tools like WebAIM contrast checker</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};