import React, { useState } from 'react';
import { ArrowLeft, Copy, Check, Download } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface Base64ToolProps {
  onBack: () => void;
}

export const Base64Tool: React.FC<Base64ToolProps> = ({ onBack }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleProcess = (value: string, currentMode: 'encode' | 'decode') => {
    if (!value.trim()) {
      setOutput('');
      setError('');
      return;
    }

    try {
      if (currentMode === 'encode') {
        const encoded = btoa(unescape(encodeURIComponent(value)));
        setOutput(encoded);
        setError('');
      } else {
        const decoded = decodeURIComponent(escape(atob(value)));
        setOutput(decoded);
        setError('');
      }
    } catch (err) {
      setError(`Invalid ${currentMode === 'decode' ? 'Base64' : 'text'} input`);
      setOutput('');
    }
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    handleProcess(value, mode);
  };

  const handleModeChange = (newMode: 'encode' | 'decode') => {
    if (newMode !== mode) {
      setMode(newMode);
      setInput(output);
      setOutput(input);
      setError('');
    }
  };

  const handleCopy = async () => {
    if (output) {
      const success = await copyToClipboard(output);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (output) {
      const filename = mode === 'encode' ? 'encoded.txt' : 'decoded.txt';
      downloadFile(output, filename);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Base64 Encoder/Decoder</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Mode Toggle */}
        <div className="flex space-x-2 mb-6">
          <button
            onClick={() => handleModeChange('encode')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              mode === 'encode'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Encode
          </button>
          <button
            onClick={() => handleModeChange('decode')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              mode === 'decode'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Decode
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {mode === 'encode' ? 'Text to Encode' : 'Base64 to Decode'}
            </label>
            <textarea
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder={
                mode === 'encode'
                  ? 'Enter text to encode...'
                  : 'Enter Base64 string to decode...'
              }
              className="w-full h-32 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {mode === 'encode' ? 'Base64 Encoded' : 'Decoded Text'}
            </label>
            <div className="relative">
              <textarea
                value={output}
                readOnly
                placeholder={
                  mode === 'encode'
                    ? 'Base64 encoded result will appear here...'
                    : 'Decoded text will appear here...'
                }
                className="w-full h-32 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none"
              />
              {error && (
                <div className="absolute top-4 left-4 right-4 bg-red-50 border border-red-300 rounded-lg p-3">
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-jpmorgan-blue-50 border border-jpmorgan-blue-200 rounded-lg">
          <h3 className="text-gray-900 font-semibold mb-2">About Base64 Encoding</h3>
          <p className="text-gray-700 text-sm mb-3">
            Base64 encoding converts binary data into ASCII text format using a radix-64 representation. 
            It's commonly used for encoding data in email, web applications, and data transmission.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="text-gray-900 font-medium mb-1">Common Use Cases:</h4>
              <ul className="text-gray-700 space-y-1">
                <li>• Email attachments</li>
                <li>• Data URLs in web pages</li>
                <li>• API authentication tokens</li>
                <li>• Binary data transmission</li>
              </ul>
            </div>
            <div>
              <h4 className="text-gray-900 font-medium mb-1">Character Set:</h4>
              <ul className="text-gray-700 space-y-1">
                <li>• A-Z (uppercase letters)</li>
                <li>• a-z (lowercase letters)</li>
                <li>• 0-9 (digits)</li>
                <li>• + and / (special characters)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};