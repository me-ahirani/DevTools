import React, { useState } from 'react';
import { Check, Copy, Download, ArrowLeft } from 'lucide-react';
import { downloadFile, copyToClipboard } from '../../utils/fileUtils';

interface XMLFormatterProps {
  onBack: () => void;
}

export const XMLFormatter: React.FC<XMLFormatterProps> = ({ onBack }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const formatXML = (xmlString: string) => {
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xmlString, 'application/xml');
      
      // Check for parsing errors
      const parserError = xmlDoc.getElementsByTagName('parsererror');
      if (parserError.length > 0) {
        throw new Error('Invalid XML format');
      }
      
      const serializer = new XMLSerializer();
      const formatted = serializer.serializeToString(xmlDoc);
      
      // Simple formatting
      const formattedXML = formatted
        .replace(/></g, '>\n<')
        .replace(/^\s*\n/gm, '')
        .split('\n')
        .map((line, index, array) => {
          const depth = line.split('<').length - line.split('</').length;
          const indent = '  '.repeat(Math.max(0, depth - 1));
          return indent + line.trim();
        })
        .join('\n');
      
      setOutput(formattedXML);
      setError('');
    } catch (err) {
      setError('Invalid XML format');
      setOutput('');
    }
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    if (value.trim()) {
      formatXML(value);
    } else {
      setOutput('');
      setError('');
    }
  };

  const handleCopy = async () => {
    if (output) {
      const success = await copyToClipboard(output);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (output) {
      downloadFile(output, 'formatted.xml', 'application/xml');
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-jpmorgan-600 hover:text-jpmorgan-800 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-jpmorgan-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-jpmorgan-800">XML Formatter & Validator</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue hover:bg-jpmorgan-blue-dark disabled:bg-jpmorgan-300 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-jpmorgan-300 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-jpmorgan-700 mb-2">
              Input XML
            </label>
            <textarea
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Paste your XML here..."
              className="w-full h-96 p-4 bg-jpmorgan-50 border border-jpmorgan-300 rounded-lg text-jpmorgan-800 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-jpmorgan-700 mb-2">
              Formatted XML
            </label>
            <div className="relative">
              <textarea
                value={output}
                readOnly
                placeholder="Formatted XML will appear here..."
                className="w-full h-96 p-4 bg-jpmorgan-800 border border-jpmorgan-300 rounded-lg text-jpmorgan-100 font-mono text-sm resize-none focus:outline-none"
              />
              {error && (
                <div className="absolute top-4 left-4 right-4 bg-red-100 border border-red-300 rounded-lg p-3">
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};