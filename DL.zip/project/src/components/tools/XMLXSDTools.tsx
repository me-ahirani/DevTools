import React, { useState, useCallback } from 'react';
import { ArrowLeft, Copy, Check, Download, FileCheck, AlertCircle, Upload } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface XMLXSDToolsProps {
  onBack: () => void;
}

export const XMLXSDTools: React.FC<XMLXSDToolsProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'xml-to-xsd' | 'xsd-to-xml' | 'validate'>('xml-to-xsd');
  const [xmlInput, setXmlInput] = useState('');
  const [xsdInput, setXsdInput] = useState('');
  const [output, setOutput] = useState('');
  const [validationResult, setValidationResult] = useState<{ valid: boolean; errors: string[] } | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState<'xml' | 'xsd' | null>(null);

  const handleDrag = useCallback((e: React.DragEvent, type: 'xml' | 'xsd') => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(type);
    } else if (e.type === "dragleave") {
      setDragActive(null);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, type: 'xml' | 'xsd') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(null);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      processUploadedFile(files[0], type);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: 'xml' | 'xsd') => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0], type);
    }
  };

  const processUploadedFile = async (file: File, type: 'xml' | 'xsd') => {
    try {
      const content = await file.text();
      if (type === 'xml') {
        setXmlInput(content);
      } else {
        setXsdInput(content);
      }
    } catch (error) {
      setError('Error reading file');
    }
  };

  const generateXSDFromXML = () => {
    if (!xmlInput.trim()) {
      setError('Please enter XML content');
      return;
    }

    try {
      // Parse XML to extract structure using browser's DOMParser
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xmlInput, 'application/xml');
      
      // Check for parsing errors
      const parserError = xmlDoc.getElementsByTagName('parsererror');
      if (parserError.length > 0) {
        throw new Error('Invalid XML format');
      }

      // Generate basic XSD structure
      const rootElement = xmlDoc.documentElement;
      const xsd = generateXSDSchema(rootElement);
      
      setOutput(xsd);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error generating XSD');
      setOutput('');
    }
  };

  const generateXMLFromXSD = () => {
    if (!xsdInput.trim()) {
      setError('Please enter XSD content');
      return;
    }

    try {
      // Parse XSD and generate sample XML using browser's DOMParser
      const parser = new DOMParser();
      const xsdDoc = parser.parseFromString(xsdInput, 'application/xml');
      
      // Check for parsing errors
      const parserError = xsdDoc.getElementsByTagName('parsererror');
      if (parserError.length > 0) {
        throw new Error('Invalid XSD format');
      }

      const xml = generateXMLFromXSDSchema(xsdDoc);
      setOutput(xml);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error generating XML');
      setOutput('');
    }
  };

  const validateXMLAgainstXSD = () => {
    if (!xmlInput.trim() || !xsdInput.trim()) {
      setError('Please enter both XML and XSD content');
      return;
    }

    try {
      // Basic validation using browser's DOMParser
      const xmlParser = new DOMParser();
      const xsdParser = new DOMParser();
      
      const xmlDoc = xmlParser.parseFromString(xmlInput, 'application/xml');
      const xsdDoc = xsdParser.parseFromString(xsdInput, 'application/xml');
      
      // Check for parsing errors
      const xmlErrors = xmlDoc.getElementsByTagName('parsererror');
      const xsdErrors = xsdDoc.getElementsByTagName('parsererror');
      
      const errors: string[] = [];
      
      if (xmlErrors.length > 0) {
        errors.push('Invalid XML format');
      }
      
      if (xsdErrors.length > 0) {
        errors.push('Invalid XSD format');
      }

      // Basic structure validation
      if (errors.length === 0) {
        const xmlRoot = xmlDoc.documentElement;
        const xsdElements = xsdDoc.getElementsByTagName('xs:element');
        
        let rootElementFound = false;
        for (let i = 0; i < xsdElements.length; i++) {
          const element = xsdElements[i];
          if (element.getAttribute('name') === xmlRoot.tagName) {
            rootElementFound = true;
            break;
          }
        }
        
        if (!rootElementFound) {
          errors.push(`Root element '${xmlRoot.tagName}' not found in XSD schema`);
        }

        // Additional validation: check if XML elements exist in XSD
        const validateElement = (xmlElement: Element, depth = 0) => {
          if (depth > 10) return; // Prevent infinite recursion
          
          const elementName = xmlElement.tagName;
          let elementFound = false;
          
          // Check if element is defined in XSD
          for (let i = 0; i < xsdElements.length; i++) {
            const xsdElement = xsdElements[i];
            if (xsdElement.getAttribute('name') === elementName) {
              elementFound = true;
              break;
            }
          }
          
          // Also check in complexType definitions
          const complexTypes = xsdDoc.getElementsByTagName('xs:complexType');
          for (let i = 0; i < complexTypes.length; i++) {
            const complexType = complexTypes[i];
            const sequences = complexType.getElementsByTagName('xs:sequence');
            for (let j = 0; j < sequences.length; j++) {
              const sequenceElements = sequences[j].getElementsByTagName('xs:element');
              for (let k = 0; k < sequenceElements.length; k++) {
                if (sequenceElements[k].getAttribute('name') === elementName) {
                  elementFound = true;
                  break;
                }
              }
            }
          }
          
          if (!elementFound && depth > 0) {
            errors.push(`Element '${elementName}' not defined in XSD schema`);
          }
          
          // Recursively validate child elements
          const children = xmlElement.children;
          for (let i = 0; i < children.length; i++) {
            validateElement(children[i], depth + 1);
          }
        };
        
        validateElement(xmlRoot);
      }

      setValidationResult({
        valid: errors.length === 0,
        errors
      });
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error validating XML');
      setValidationResult(null);
    }
  };

  const generateXSDSchema = (element: Element): string => {
    const elementName = element.tagName;
    const attributes = Array.from(element.attributes);
    const children = Array.from(element.children);
    
    let xsd = `<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           targetNamespace="http://example.com"
           xmlns:tns="http://example.com"
           elementFormDefault="qualified">

  <xs:element name="${elementName}" type="tns:${elementName}Type"/>

  <xs:complexType name="${elementName}Type">`;

    if (attributes.length > 0) {
      xsd += '\n    <!-- Attributes -->';
      attributes.forEach(attr => {
        xsd += `\n    <xs:attribute name="${attr.name}" type="xs:string"/>`;
      });
    }

    if (children.length > 0) {
      xsd += '\n    <xs:sequence>';
      const uniqueChildren = Array.from(new Set(children.map(child => child.tagName)));
      uniqueChildren.forEach(childName => {
        // Determine if element appears multiple times
        const count = children.filter(child => child.tagName === childName).length;
        const maxOccurs = count > 1 ? 'unbounded' : '1';
        
        // Try to determine data type from content
        const sampleChild = children.find(child => child.tagName === childName);
        const textContent = sampleChild?.textContent?.trim();
        let dataType = 'xs:string';
        
        if (textContent) {
          if (!isNaN(Number(textContent))) {
            dataType = textContent.includes('.') ? 'xs:decimal' : 'xs:integer';
          } else if (textContent.toLowerCase() === 'true' || textContent.toLowerCase() === 'false') {
            dataType = 'xs:boolean';
          } else if (textContent.match(/^\d{4}-\d{2}-\d{2}$/)) {
            dataType = 'xs:date';
          }
        }
        
        xsd += `\n      <xs:element name="${childName}" type="${dataType}" minOccurs="0" maxOccurs="${maxOccurs}"/>`;
      });
      xsd += '\n    </xs:sequence>';
    } else if (element.textContent?.trim()) {
      xsd += '\n    <xs:simpleContent>\n      <xs:extension base="xs:string">';
      if (attributes.length > 0) {
        attributes.forEach(attr => {
          xsd += `\n        <xs:attribute name="${attr.name}" type="xs:string"/>`;
        });
      }
      xsd += '\n      </xs:extension>\n    </xs:simpleContent>';
    }

    xsd += '\n  </xs:complexType>\n\n</xs:schema>';
    
    return xsd;
  };

  const generateXMLFromXSDSchema = (xsdDoc: Document): string => {
    const elements = xsdDoc.getElementsByTagName('xs:element');
    
    if (elements.length === 0) {
      throw new Error('No elements found in XSD schema');
    }

    const rootElement = elements[0];
    const rootName = rootElement.getAttribute('name') || 'root';
    
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<${rootName} xmlns="http://example.com">`;

    // Add sample content based on XSD structure
    const complexTypes = xsdDoc.getElementsByTagName('xs:complexType');
    if (complexTypes.length > 0) {
      const sequences = xsdDoc.getElementsByTagName('xs:sequence');
      if (sequences.length > 0) {
        const childElements = sequences[0].getElementsByTagName('xs:element');
        for (let i = 0; i < childElements.length; i++) {
          const childName = childElements[i].getAttribute('name');
          const childType = childElements[i].getAttribute('type') || 'xs:string';
          
          if (childName) {
            let sampleValue = `Sample ${childName}`;
            
            // Generate appropriate sample data based on type
            switch (childType) {
              case 'xs:integer':
                sampleValue = '123';
                break;
              case 'xs:decimal':
                sampleValue = '123.45';
                break;
              case 'xs:boolean':
                sampleValue = 'true';
                break;
              case 'xs:date':
                sampleValue = new Date().toISOString().split('T')[0];
                break;
              case 'xs:dateTime':
                sampleValue = new Date().toISOString();
                break;
              default:
                sampleValue = `Sample ${childName}`;
            }
            
            xml += `\n  <${childName}>${sampleValue}</${childName}>`;
          }
        }
      }
      
      // Add sample attributes
      const attributes = xsdDoc.getElementsByTagName('xs:attribute');
      if (attributes.length > 0) {
        // Note: This is a simplified approach - in a real implementation,
        // we'd need to properly associate attributes with their parent elements
        xml = xml.replace(`<${rootName}`, `<${rootName} ${attributes[0].getAttribute('name')}="sample-value"`);
      }
    }

    xml += `\n</${rootName}>`;
    
    return xml;
  };

  const handleCopy = async () => {
    const content = activeTab === 'validate' ? 
      (validationResult ? JSON.stringify(validationResult, null, 2) : '') : 
      output;
    
    if (content) {
      const success = await copyToClipboard(content);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (activeTab === 'validate' && validationResult) {
      downloadFile(JSON.stringify(validationResult, null, 2), 'validation-result.json', 'application/json');
    } else if (output) {
      const extension = activeTab === 'xml-to-xsd' ? 'xsd' : 'xml';
      const mimeType = 'application/xml';
      downloadFile(output, `generated.${extension}`, mimeType);
    }
  };

  const loadSampleData = () => {
    if (activeTab === 'xml-to-xsd') {
      setXmlInput(`<?xml version="1.0" encoding="UTF-8"?>
<employee id="123">
  <name>John Doe</name>
  <department>Engineering</department>
  <salary currency="USD">75000</salary>
  <skills>
    <skill>JavaScript</skill>
    <skill>React</skill>
    <skill>Node.js</skill>
  </skills>
</employee>`);
    } else if (activeTab === 'xsd-to-xml') {
      setXsdInput(`<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           targetNamespace="http://example.com"
           xmlns:tns="http://example.com"
           elementFormDefault="qualified">

  <xs:element name="book" type="tns:bookType"/>

  <xs:complexType name="bookType">
    <xs:sequence>
      <xs:element name="title" type="xs:string"/>
      <xs:element name="author" type="xs:string"/>
      <xs:element name="isbn" type="xs:string"/>
      <xs:element name="price" type="xs:decimal"/>
    </xs:sequence>
    <xs:attribute name="id" type="xs:string" use="required"/>
  </xs:complexType>

</xs:schema>`);
    } else {
      setXmlInput(`<?xml version="1.0" encoding="UTF-8"?>
<book id="1">
  <title>XML Processing Guide</title>
  <author>Jane Smith</author>
  <isbn>978-0123456789</isbn>
  <price>29.99</price>
</book>`);
      setXsdInput(`<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="book">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="title" type="xs:string"/>
        <xs:element name="author" type="xs:string"/>
        <xs:element name="isbn" type="xs:string"/>
        <xs:element name="price" type="xs:decimal"/>
      </xs:sequence>
      <xs:attribute name="id" type="xs:string" use="required"/>
    </xs:complexType>
  </xs:element>
</xs:schema>`);
    }
  };

  const processContent = () => {
    setError('');
    setValidationResult(null);
    setOutput('');

    switch (activeTab) {
      case 'xml-to-xsd':
        generateXSDFromXML();
        break;
      case 'xsd-to-xml':
        generateXMLFromXSD();
        break;
      case 'validate':
        validateXMLAgainstXSD();
        break;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">XML/XSD Tools</h1>
          <div className="flex space-x-2">
            <button
              onClick={loadSampleData}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
            >
              <FileCheck className="h-4 w-4" />
              <span>Load Sample</span>
            </button>
            <button
              onClick={handleCopy}
              disabled={!output && !validationResult}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!output && !validationResult}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-2 mb-6">
          <button
            onClick={() => setActiveTab('xml-to-xsd')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'xml-to-xsd'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            XML to XSD
          </button>
          <button
            onClick={() => setActiveTab('xsd-to-xml')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'xsd-to-xml'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            XSD to XML
          </button>
          <button
            onClick={() => setActiveTab('validate')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'validate'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Validate XML
          </button>
        </div>

        <div className="space-y-6">
          {/* Input Areas */}
          <div className={`grid gap-6 ${activeTab === 'validate' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
            {(activeTab === 'xml-to-xsd' || activeTab === 'validate') && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    XML Input
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="file"
                      accept=".xml"
                      onChange={(e) => handleFileSelect(e, 'xml')}
                      className="hidden"
                      id="xml-file-upload"
                    />
                    <label
                      htmlFor="xml-file-upload"
                      className="flex items-center space-x-1 px-3 py-1 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded text-sm cursor-pointer transition-colors"
                    >
                      <Upload className="h-3 w-3" />
                      <span>Upload XML</span>
                    </label>
                  </div>
                </div>
                <div
                  className={`border-2 border-dashed rounded-lg transition-colors ${
                    dragActive === 'xml'
                      ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
                      : 'border-gray-300'
                  }`}
                  onDragEnter={(e) => handleDrag(e, 'xml')}
                  onDragLeave={(e) => handleDrag(e, 'xml')}
                  onDragOver={(e) => handleDrag(e, 'xml')}
                  onDrop={(e) => handleDrop(e, 'xml')}
                >
                  <textarea
                    value={xmlInput}
                    onChange={(e) => setXmlInput(e.target.value)}
                    placeholder="Enter XML content or drag & drop XML file here..."
                    className="w-full h-64 p-4 bg-white border-none rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                  />
                </div>
              </div>
            )}

            {(activeTab === 'xsd-to-xml' || activeTab === 'validate') && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    XSD Input
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="file"
                      accept=".xsd,.xml"
                      onChange={(e) => handleFileSelect(e, 'xsd')}
                      className="hidden"
                      id="xsd-file-upload"
                    />
                    <label
                      htmlFor="xsd-file-upload"
                      className="flex items-center space-x-1 px-3 py-1 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded text-sm cursor-pointer transition-colors"
                    >
                      <Upload className="h-3 w-3" />
                      <span>Upload XSD</span>
                    </label>
                  </div>
                </div>
                <div
                  className={`border-2 border-dashed rounded-lg transition-colors ${
                    dragActive === 'xsd'
                      ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
                      : 'border-gray-300'
                  }`}
                  onDragEnter={(e) => handleDrag(e, 'xsd')}
                  onDragLeave={(e) => handleDrag(e, 'xsd')}
                  onDragOver={(e) => handleDrag(e, 'xsd')}
                  onDrop={(e) => handleDrop(e, 'xsd')}
                >
                  <textarea
                    value={xsdInput}
                    onChange={(e) => setXsdInput(e.target.value)}
                    placeholder="Enter XSD schema or drag & drop XSD file here..."
                    className="w-full h-64 p-4 bg-white border-none rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Process Button */}
          <div className="text-center">
            <button
              onClick={processContent}
              className="px-6 py-3 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg transition-all transform hover:scale-105 shadow-lg"
            >
              {activeTab === 'xml-to-xsd' ? 'Generate XSD' :
               activeTab === 'xsd-to-xml' ? 'Generate XML' :
               'Validate XML'}
            </button>
          </div>

          {/* Output Area */}
          {activeTab !== 'validate' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {activeTab === 'xml-to-xsd' ? 'Generated XSD' : 'Generated XML'}
              </label>
              <div className="relative">
                <textarea
                  value={output}
                  readOnly
                  placeholder={`${activeTab === 'xml-to-xsd' ? 'XSD' : 'XML'} output will appear here...`}
                  className="w-full h-64 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none"
                />
                {error && (
                  <div className="absolute top-4 left-4 right-4 bg-red-50 border border-red-300 rounded-lg p-3">
                    <p className="text-red-700 text-sm">{error}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Validation Results */}
          {activeTab === 'validate' && validationResult && (
            <div className="bg-gray-50 rounded-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Validation Results</h3>
              <div className={`flex items-center space-x-3 p-4 rounded-lg ${
                validationResult.valid 
                  ? 'bg-green-50 border border-green-200' 
                  : 'bg-red-50 border border-red-200'
              }`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  validationResult.valid ? 'bg-green-500' : 'bg-red-500'
                }`}>
                  {validationResult.valid ? '✓' : '✗'}
                </div>
                <div>
                  <p className={`font-semibold ${validationResult.valid ? 'text-green-700' : 'text-red-700'}`}>
                    {validationResult.valid ? 'XML is valid' : 'XML validation failed'}
                  </p>
                  {validationResult.errors.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {validationResult.errors.map((error, index) => (
                        <li key={index} className="text-red-700 text-sm">• {error}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          )}

          {error && activeTab === 'validate' && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <p className="text-red-700">{error}</p>
              </div>
            </div>
          )}
        </div>

        {/* Help Section */}
        <div className="mt-8 p-4 bg-jpmorgan-blue-50 border border-jpmorgan-blue-200 rounded-lg">
          <h4 className="text-gray-900 font-semibold mb-2">XML/XSD Tools Features</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
            <div>
              <h5 className="font-medium text-gray-900 mb-1">XML to XSD:</h5>
              <ul className="space-y-1">
                <li>• Generate XSD schema from XML</li>
                <li>• Extract element structure</li>
                <li>• Include attributes and types</li>
                <li>• Upload XML files directly</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">XSD to XML:</h5>
              <ul className="space-y-1">
                <li>• Generate sample XML from XSD</li>
                <li>• Follow schema structure</li>
                <li>• Include sample data</li>
                <li>• Upload XSD files directly</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">XML Validation:</h5>
              <ul className="space-y-1">
                <li>• Validate XML against XSD</li>
                <li>• Check structure compliance</li>
                <li>• Detailed error reporting</li>
                <li>• Drag & drop file support</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};