import React, { useState } from 'react';
import { ArrowLeft, Copy, Check, Download } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface URLEncoderProps {
  onBack: () => void;
}

export const URLEncoder: React.FC<URLEncoderProps> = ({ onBack }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleProcess = (value: string, currentMode: 'encode' | 'decode') => {
    if (!value.trim()) {
      setOutput('');
      setError('');
      return;
    }

    try {
      if (currentMode === 'encode') {
        const encoded = encodeURIComponent(value);
        setOutput(encoded);
        setError('');
      } else {
        const decoded = decodeURIComponent(value);
        setOutput(decoded);
        setError('');
      }
    } catch (err) {
      setError(`Invalid ${currentMode === 'decode' ? 'URL encoded' : 'text'} input`);
      setOutput('');
    }
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    handleProcess(value, mode);
  };

  const handleModeChange = (newMode: 'encode' | 'decode') => {
    if (newMode !== mode) {
      setMode(newMode);
      setInput(output);
      setOutput(input);
      setError('');
    }
  };

  const handleCopy = async () => {
    if (output) {
      const success = await copyToClipboard(output);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (output) {
      const filename = mode === 'encode' ? 'encoded-url.txt' : 'decoded-url.txt';
      downloadFile(output, filename);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">URL Encoder/Decoder</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!output}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Mode Toggle */}
        <div className="flex space-x-2 mb-6">
          <button
            onClick={() => handleModeChange('encode')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              mode === 'encode'
                ? 'bg-blue-600 text-white'
                : 'bg-white/10 text-gray-300 hover:bg-white/20'
            }`}
          >
            Encode
          </button>
          <button
            onClick={() => handleModeChange('decode')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              mode === 'decode'
                ? 'bg-blue-600 text-white'
                : 'bg-white/10 text-gray-300 hover:bg-white/20'
            }`}
          >
            Decode
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {mode === 'encode' ? 'URL to Encode' : 'Encoded URL to Decode'}
            </label>
            <textarea
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder={
                mode === 'encode'
                  ? 'Enter URL or text to encode...'
                  : 'Enter encoded URL to decode...'
              }
              className="w-full h-32 p-4 bg-black/30 border border-white/20 rounded-lg text-white font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {mode === 'encode' ? 'URL Encoded' : 'Decoded URL'}
            </label>
            <div className="relative">
              <textarea
                value={output}
                readOnly
                placeholder={
                  mode === 'encode'
                    ? 'URL encoded result will appear here...'
                    : 'Decoded URL will appear here...'
                }
                className="w-full h-32 p-4 bg-black/30 border border-white/20 rounded-lg text-white font-mono text-sm resize-none focus:outline-none"
              />
              {error && (
                <div className="absolute top-4 left-4 right-4 bg-red-500/20 border border-red-500/50 rounded-lg p-3">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <h3 className="text-white font-semibold mb-2">URL Encoding</h3>
          <p className="text-gray-300 text-sm mb-3">
            URL encoding converts characters into a format that can be transmitted over the Internet. 
            Special characters are replaced with a percent sign (%) followed by two hexadecimal digits.
          </p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="text-white font-medium mb-1">Common Encoded Characters:</h4>
              <ul className="text-gray-300 space-y-1">
                <li>Space → %20</li>
                <li>! → %21</li>
                <li># → %23</li>
                <li>& → %26</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-medium mb-1">Use Cases:</h4>
              <ul className="text-gray-300 space-y-1">
                <li>• Query parameters</li>
                <li>• Form data submission</li>
                <li>• API endpoints</li>
                <li>• Safe URL transmission</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};