import React, { useState, useCallback } from 'react';
import { ArrowLeft, Upload, Download, Copy, Check, RefreshCw } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface FileComparisonProps {
  onBack: () => void;
}

interface FileContent {
  name: string;
  content: string;
  lines: string[];
}

interface DiffLine {
  type: 'equal' | 'added' | 'removed' | 'modified';
  leftLine?: string;
  rightLine?: string;
  leftNumber?: number;
  rightNumber?: number;
  index: number;
}

export const FileComparison: React.FC<FileComparisonProps> = ({ onBack }) => {
  const [leftFile, setLeftFile] = useState<FileContent | null>(null);
  const [rightFile, setRightFile] = useState<FileContent | null>(null);
  const [diff, setDiff] = useState<DiffLine[]>([]);
  const [copied, setCopied] = useState(false);
  const [dragActive, setDragActive] = useState<'left' | 'right' | null>(null);

  const handleDrag = useCallback((e: React.DragEvent, side: 'left' | 'right') => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(side);
    } else if (e.type === "dragleave") {
      setDragActive(null);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, side: 'left' | 'right') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(null);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      processFile(files[0], side);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, side: 'left' | 'right') => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0], side);
    }
  };

  const processFile = async (file: File, side: 'left' | 'right') => {
    try {
      const content = await file.text();
      const lines = content.split('\n');
      const fileContent: FileContent = {
        name: file.name,
        content,
        lines
      };

      if (side === 'left') {
        setLeftFile(fileContent);
      } else {
        setRightFile(fileContent);
      }
    } catch (error) {
      console.error('Error reading file:', error);
    }
  };

  const generateDiff = () => {
    if (!leftFile || !rightFile) return;

    const leftLines = leftFile.lines;
    const rightLines = rightFile.lines;
    const maxLines = Math.max(leftLines.length, rightLines.length);
    const newDiff: DiffLine[] = [];

    for (let i = 0; i < maxLines; i++) {
      const leftLine = leftLines[i];
      const rightLine = rightLines[i];

      if (leftLine === rightLine) {
        newDiff.push({
          type: 'equal',
          leftLine: leftLine || '',
          rightLine: rightLine || '',
          leftNumber: leftLine !== undefined ? i + 1 : undefined,
          rightNumber: rightLine !== undefined ? i + 1 : undefined,
          index: i
        });
      } else if (leftLine === undefined) {
        newDiff.push({
          type: 'added',
          rightLine: rightLine || '',
          rightNumber: i + 1,
          index: i
        });
      } else if (rightLine === undefined) {
        newDiff.push({
          type: 'removed',
          leftLine: leftLine || '',
          leftNumber: i + 1,
          index: i
        });
      } else {
        newDiff.push({
          type: 'modified',
          leftLine: leftLine || '',
          rightLine: rightLine || '',
          leftNumber: i + 1,
          rightNumber: i + 1,
          index: i
        });
      }
    }

    setDiff(newDiff);
  };

  React.useEffect(() => {
    if (leftFile && rightFile) {
      generateDiff();
    }
  }, [leftFile, rightFile]);

  const handleCopy = async () => {
    const content = diff.map(line => 
      `${line.leftLine || ''} | ${line.rightLine || ''}`
    ).join('\n');
    
    if (content) {
      const success = await copyToClipboard(content);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (diff.length > 0) {
      const comparisonReport = generateComparisonReport();
      downloadFile(comparisonReport, `comparison-report-${Date.now()}.txt`);
    }
  };

  const generateComparisonReport = () => {
    const stats = {
      total: diff.length,
      equal: diff.filter(d => d.type === 'equal').length,
      added: diff.filter(d => d.type === 'added').length,
      removed: diff.filter(d => d.type === 'removed').length,
      modified: diff.filter(d => d.type === 'modified').length
    };

    return `File Comparison Report
Generated: ${new Date().toISOString()}

Files Compared:
- Left: ${leftFile?.name}
- Right: ${rightFile?.name}

Statistics:
- Total Lines: ${stats.total}
- Unchanged: ${stats.equal}
- Added: ${stats.added}
- Removed: ${stats.removed}
- Modified: ${stats.modified}

Detailed Differences:
${diff.filter(d => d.type !== 'equal').map(line => 
  `Line ${line.leftNumber || line.rightNumber}: ${line.type.toUpperCase()}
  ${line.type === 'added' ? `+ ${line.rightLine}` : 
    line.type === 'removed' ? `- ${line.leftLine}` :
    `- ${line.leftLine}\n+ ${line.rightLine}`}`
).join('\n\n')}`;
  };

  const getLineClass = (line: DiffLine) => {
    const baseClass = "border-l-2 transition-all";
    
    switch (line.type) {
      case 'equal':
        return `${baseClass} border-transparent`;
      case 'added':
        return `${baseClass} border-green-500 bg-green-500/10`;
      case 'removed':
        return `${baseClass} border-red-500 bg-red-500/10`;
      case 'modified':
        return `${baseClass} border-yellow-500 bg-yellow-500/10`;
      default:
        return baseClass;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">File Comparison Tool</h1>
          
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={diff.length === 0}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={diff.length === 0}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* File Upload Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Left File */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Original File (Left)</h3>
            <div
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                dragActive === 'left'
                  ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragEnter={(e) => handleDrag(e, 'left')}
              onDragLeave={(e) => handleDrag(e, 'left')}
              onDragOver={(e) => handleDrag(e, 'left')}
              onDrop={(e) => handleDrop(e, 'left')}
            >
              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-900 mb-2">Drop file here or click to browse</p>
              <input
                type="file"
                onChange={(e) => handleFileSelect(e, 'left')}
                className="hidden"
                id="left-file-upload"
              />
              <label
                htmlFor="left-file-upload"
                className="inline-block px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg cursor-pointer transition-colors"
              >
                Choose File
              </label>
              {leftFile && (
                <p className="text-green-600 text-sm mt-2">✓ {leftFile.name}</p>
              )}
            </div>
          </div>

          {/* Right File */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Modified File (Right)</h3>
            <div
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                dragActive === 'right'
                  ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragEnter={(e) => handleDrag(e, 'right')}
              onDragLeave={(e) => handleDrag(e, 'right')}
              onDragOver={(e) => handleDrag(e, 'right')}
              onDrop={(e) => handleDrop(e, 'right')}
            >
              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-900 mb-2">Drop file here or click to browse</p>
              <input
                type="file"
                onChange={(e) => handleFileSelect(e, 'right')}
                className="hidden"
                id="right-file-upload"
              />
              <label
                htmlFor="right-file-upload"
                className="inline-block px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg cursor-pointer transition-colors"
              >
                Choose File
              </label>
              {rightFile && (
                <p className="text-green-600 text-sm mt-2">✓ {rightFile.name}</p>
              )}
            </div>
          </div>
        </div>

        {/* Diff Display */}
        {diff.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">File Comparison</h3>
            <div className="bg-gray-50 rounded-lg border border-gray-200 overflow-hidden">
              <div className="grid grid-cols-2 gap-px bg-gray-200">
                <div className="bg-gray-50 p-3 text-center">
                  <h4 className="text-gray-900 font-medium">{leftFile?.name}</h4>
                </div>
                <div className="bg-gray-50 p-3 text-center">
                  <h4 className="text-gray-900 font-medium">{rightFile?.name}</h4>
                </div>
              </div>
              
              <div className="max-h-96 overflow-auto">
                {diff.map((line, index) => (
                  <div key={index} className={getLineClass(line)}>
                    <div className="grid grid-cols-2 gap-px w-full">
                      <div className="flex items-center space-x-2 p-2">
                        <span className="text-gray-500 text-xs w-8 text-right">
                          {line.leftNumber || ''}
                        </span>
                        <span className="text-gray-900 flex-1 font-mono text-sm">
                          {line.leftLine || ''}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 p-2 border-l border-gray-200">
                        <span className="text-gray-500 text-xs w-8 text-right">
                          {line.rightNumber || ''}
                        </span>
                        <span className="text-gray-900 flex-1 font-mono text-sm">
                          {line.rightLine || ''}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Comparison Statistics */}
        {diff.length > 0 && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h4 className="text-gray-900 font-semibold mb-3">Comparison Statistics</h4>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{diff.length}</div>
                <div className="text-gray-600">Total Lines</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-500">{diff.filter(d => d.type === 'equal').length}</div>
                <div className="text-gray-600">Unchanged</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{diff.filter(d => d.type === 'added').length}</div>
                <div className="text-gray-600">Added</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{diff.filter(d => d.type === 'removed').length}</div>
                <div className="text-gray-600">Removed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">{diff.filter(d => d.type === 'modified').length}</div>
                <div className="text-gray-600">Modified</div>
              </div>
            </div>
          </div>
        )}

        {/* Legend */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
          <h4 className="text-gray-900 font-semibold mb-3">Comparison Legend</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500/20 border-l-2 border-green-500 rounded-sm"></div>
              <span className="text-gray-700">Added lines</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500/20 border-l-2 border-red-500 rounded-sm"></div>
              <span className="text-gray-700">Removed lines</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-yellow-500/20 border-l-2 border-yellow-500 rounded-sm"></div>
              <span className="text-gray-700">Modified lines</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-transparent border-l-2 border-transparent rounded-sm"></div>
              <span className="text-gray-700">Unchanged</span>
            </div>
          </div>
          <p className="text-gray-600 text-xs mt-3">
            Compare mode shows differences between files with detailed statistics and reporting.
          </p>
        </div>
      </div>
    </div>
  );
};