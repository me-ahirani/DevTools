import React, { useState } from 'react';
import { ArrowLeft, Copy, Check } from 'lucide-react';
import { copyToClipboard } from '../../utils/fileUtils';
import CryptoJS from 'crypto-js';

interface HashGeneratorProps {
  onBack: () => void;
}

export const HashGenerator: React.FC<HashGeneratorProps> = ({ onBack }) => {
  const [input, setInput] = useState('');
  const [hashes, setHashes] = useState<Record<string, string>>({});
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const hashTypes = [
    { name: 'MD5', key: 'md5' },
    { name: 'SHA-1', key: 'sha1' },
    { name: 'SHA-256', key: 'sha256' },
    { name: 'SHA-512', key: 'sha512' },
    { name: 'SHA3-256', key: 'sha3-256' },
    { name: 'SHA3-512', key: 'sha3-512' }
  ];

  const generateHashes = (text: string) => {
    if (!text.trim()) {
      setHashes({});
      return;
    }

    const newHashes: Record<string, string> = {};
    
    try {
      newHashes.md5 = CryptoJS.MD5(text).toString();
      newHashes.sha1 = CryptoJS.SHA1(text).toString();
      newHashes.sha256 = CryptoJS.SHA256(text).toString();
      newHashes.sha512 = CryptoJS.SHA512(text).toString();
      newHashes['sha3-256'] = CryptoJS.SHA3(text, { outputLength: 256 }).toString();
      newHashes['sha3-512'] = CryptoJS.SHA3(text, { outputLength: 512 }).toString();
    } catch (error) {
      console.error('Error generating hashes:', error);
    }

    setHashes(newHashes);
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    generateHashes(value);
  };

  const handleCopy = async (hash: string, hashType: string) => {
    const success = await copyToClipboard(hash);
    if (success) {
      setCopiedHash(hashType);
      setTimeout(() => setCopiedHash(null), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h1 className="text-2xl font-bold text-white mb-6">Hash Generator</h1>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Input Text
          </label>
          <textarea
            value={input}
            onChange={(e) => handleInputChange(e.target.value)}
            placeholder="Enter text to generate hashes..."
            className="w-full h-32 p-4 bg-black/30 border border-white/20 rounded-lg text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="space-y-4">
          {hashTypes.map((hashType) => (
            <div key={hashType.key} className="bg-black/30 rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">{hashType.name}</h3>
                <button
                  onClick={() => handleCopy(hashes[hashType.key] || '', hashType.key)}
                  disabled={!hashes[hashType.key]}
                  className="flex items-center space-x-2 px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded transition-colors"
                >
                  {copiedHash === hashType.key ? (
                    <>
                      <Check className="h-4 w-4" />
                      <span className="text-xs">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      <span className="text-xs">Copy</span>
                    </>
                  )}
                </button>
              </div>
              <div className="bg-black/50 rounded p-3 border border-white/5">
                <code className="text-gray-300 font-mono text-sm break-all">
                  {hashes[hashType.key] || 'Enter text to generate hash...'}
                </code>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <h3 className="text-white font-semibold mb-2">Security Note</h3>
          <p className="text-gray-300 text-sm">
            Hash functions are one-way cryptographic functions. While MD5 and SHA-1 are deprecated for security purposes, 
            they're still useful for checksums. Use SHA-256 or SHA-3 for security-critical applications.
          </p>
        </div>
      </div>
    </div>
  );
};