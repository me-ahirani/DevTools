import React, { useState, useMemo } from 'react';
import { ArrowLeft, Copy, Check, Download, Plus, Trash2, Table, AlertTriangle } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface CSVGeneratorProps {
  onBack: () => void;
}

interface CSVField {
  id: string;
  name: string;
  type: 'text' | 'number' | 'email' | 'date' | 'boolean';
  sampleValue: string;
}

interface CSVRow {
  [key: string]: string;
}

export const CSVGenerator: React.FC<CSVGeneratorProps> = ({ onBack }) => {
  const [fields, setFields] = useState<CSVField[]>([
    { id: '1', name: 'Name', type: 'text', sampleValue: 'John Doe' },
    { id: '2', name: 'Email', type: 'email', sampleValue: 'john@example.com' },
    { id: '3', name: 'Age', type: 'number', sampleValue: '30' },
    { id: '4', name: 'Active', type: 'boolean', sampleValue: 'true' }
  ]);
  const [rows, setRows] = useState<CSVRow[]>([]);
  const [numRows, setNumRows] = useState(10);
  const [csvOutput, setCsvOutput] = useState('');
  const [copied, setCopied] = useState(false);
  const [includeHeaders, setIncludeHeaders] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  // Performance optimization: Use useMemo for expensive calculations
  const estimatedSize = useMemo(() => {
    const avgFieldLength = fields.reduce((sum, field) => sum + (field.sampleValue?.length || 10), 0) / Math.max(fields.length, 1);
    const estimatedBytes = numRows * fields.length * avgFieldLength;
    return {
      bytes: estimatedBytes,
      mb: (estimatedBytes / (1024 * 1024)).toFixed(2),
      isLarge: estimatedBytes > 1024 * 1024 // 1MB threshold
    };
  }, [fields, numRows]);

  const addField = () => {
    const newField: CSVField = {
      id: Date.now().toString(),
      name: '',
      type: 'text',
      sampleValue: ''
    };
    setFields([...fields, newField]);
  };

  const removeField = (id: string) => {
    setFields(fields.filter(field => field.id !== id));
  };

  const updateField = (id: string, updates: Partial<CSVField>) => {
    setFields(fields.map(field => 
      field.id === id ? { ...field, ...updates } : field
    ));
  };

  // Optimized data generation with chunking for large datasets
  const generateSampleData = async () => {
    setIsGenerating(true);
    
    try {
      const sampleData: CSVRow[] = [];
      const chunkSize = 1000; // Process in chunks to prevent UI blocking
      
      for (let chunk = 0; chunk < Math.ceil(numRows / chunkSize); chunk++) {
        const chunkStart = chunk * chunkSize;
        const chunkEnd = Math.min(chunkStart + chunkSize, numRows);
        
        // Use setTimeout to yield control back to the browser
        await new Promise(resolve => setTimeout(resolve, 0));
        
        for (let i = chunkStart; i < chunkEnd; i++) {
          const row: CSVRow = {};
          
          fields.forEach(field => {
            if (!field.name.trim()) return;
            
            switch (field.type) {
              case 'text':
                row[field.name] = field.sampleValue || `Sample ${field.name} ${i + 1}`;
                break;
              case 'email':
                row[field.name] = field.sampleValue || `user${i + 1}@example.com`;
                break;
              case 'number':
                row[field.name] = field.sampleValue || String(Math.floor(Math.random() * 100) + 1);
                break;
              case 'date':
                const date = new Date();
                date.setDate(date.getDate() + i);
                row[field.name] = field.sampleValue || date.toISOString().split('T')[0];
                break;
              case 'boolean':
                row[field.name] = field.sampleValue || (Math.random() > 0.5 ? 'true' : 'false');
                break;
              default:
                row[field.name] = field.sampleValue || `Value ${i + 1}`;
            }
          });
          
          sampleData.push(row);
        }
      }
      
      setRows(sampleData);
      generateCSV(sampleData);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateCSV = (data: CSVRow[]) => {
    if (data.length === 0 || fields.length === 0) {
      setCsvOutput('');
      return;
    }

    const validFields = fields.filter(field => field.name.trim());
    const headers = validFields.map(field => field.name);
    
    let csv = '';
    
    if (includeHeaders) {
      csv += headers.map(header => `"${header}"`).join(',') + '\n';
    }
    
    // Optimized CSV generation
    const csvLines: string[] = [];
    data.forEach(row => {
      const values = headers.map(header => {
        const value = row[header] || '';
        return `"${value.replace(/"/g, '""')}"`;
      });
      csvLines.push(values.join(','));
    });
    
    csv += csvLines.join('\n');
    setCsvOutput(csv);
  };

  React.useEffect(() => {
    if (rows.length > 0) {
      generateCSV(rows);
    }
  }, [rows, includeHeaders, fields]);

  const handleCopy = async () => {
    if (csvOutput) {
      const success = await copyToClipboard(csvOutput);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    if (csvOutput) {
      downloadFile(csvOutput, 'generated.csv', 'text/csv');
    }
  };

  const loadTemplate = (template: string) => {
    switch (template) {
      case 'employees':
        setFields([
          { id: '1', name: 'Employee ID', type: 'number', sampleValue: '1001' },
          { id: '2', name: 'First Name', type: 'text', sampleValue: 'John' },
          { id: '3', name: 'Last Name', type: 'text', sampleValue: 'Doe' },
          { id: '4', name: 'Email', type: 'email', sampleValue: 'john.doe@company.com' },
          { id: '5', name: 'Department', type: 'text', sampleValue: 'Engineering' },
          { id: '6', name: 'Salary', type: 'number', sampleValue: '75000' },
          { id: '7', name: 'Start Date', type: 'date', sampleValue: '2023-01-15' },
          { id: '8', name: 'Active', type: 'boolean', sampleValue: 'true' }
        ]);
        break;
      case 'products':
        setFields([
          { id: '1', name: 'Product ID', type: 'number', sampleValue: '101' },
          { id: '2', name: 'Product Name', type: 'text', sampleValue: 'Laptop Computer' },
          { id: '3', name: 'Category', type: 'text', sampleValue: 'Electronics' },
          { id: '4', name: 'Price', type: 'number', sampleValue: '999.99' },
          { id: '5', name: 'In Stock', type: 'boolean', sampleValue: 'true' },
          { id: '6', name: 'SKU', type: 'text', sampleValue: 'LAP-001' },
          { id: '7', name: 'Launch Date', type: 'date', sampleValue: '2024-01-01' }
        ]);
        break;
      case 'customers':
        setFields([
          { id: '1', name: 'Customer ID', type: 'number', sampleValue: '5001' },
          { id: '2', name: 'Company Name', type: 'text', sampleValue: 'Tech Solutions Inc' },
          { id: '3', name: 'Contact Person', type: 'text', sampleValue: 'Jane Smith' },
          { id: '4', name: 'Email', type: 'email', sampleValue: 'jane@techsolutions.com' },
          { id: '5', name: 'Phone', type: 'text', sampleValue: '+1-555-0123' },
          { id: '6', name: 'Country', type: 'text', sampleValue: 'United States' },
          { id: '7', name: 'Premium Customer', type: 'boolean', sampleValue: 'false' }
        ]);
        break;
    }
  };

  const updateRowValue = (rowIndex: number, fieldName: string, value: string) => {
    const updatedRows = [...rows];
    updatedRows[rowIndex][fieldName] = value;
    setRows(updatedRows);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">CSV Generator</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!csvOutput}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!csvOutput}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Performance Warning */}
        {estimatedSize.isLarge && (
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-yellow-800 font-semibold">Large Dataset Warning</p>
                <p className="text-yellow-700 text-sm">
                  Estimated size: ~{estimatedSize.mb} MB. Generation may take a moment and could impact browser performance.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Templates */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Quick Templates</h3>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => loadTemplate('employees')}
              className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
            >
              Employee Data
            </button>
            <button
              onClick={() => loadTemplate('products')}
              className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
            >
              Product Catalog
            </button>
            <button
              onClick={() => loadTemplate('customers')}
              className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
            >
              Customer List
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Field Configuration */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">CSV Fields</h3>
              <button
                onClick={addField}
                className="flex items-center space-x-2 px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors"
              >
                <Plus className="h-4 w-4" />
                <span>Add Field</span>
              </button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {fields.map((field) => (
                <div key={field.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="grid grid-cols-12 gap-2 items-start">
                    <div className="col-span-4">
                      <input
                        type="text"
                        placeholder="Field Name"
                        value={field.name}
                        onChange={(e) => updateField(field.id, { name: e.target.value })}
                        className="w-full px-2 py-1 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                      />
                    </div>
                    
                    <div className="col-span-3">
                      <select
                        value={field.type}
                        onChange={(e) => updateField(field.id, { type: e.target.value as CSVField['type'] })}
                        className="w-full px-2 py-1 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                      >
                        <option value="text">Text</option>
                        <option value="number">Number</option>
                        <option value="email">Email</option>
                        <option value="date">Date</option>
                        <option value="boolean">Boolean</option>
                      </select>
                    </div>
                    
                    <div className="col-span-4">
                      <input
                        type="text"
                        placeholder="Sample Value"
                        value={field.sampleValue}
                        onChange={(e) => updateField(field.id, { sampleValue: e.target.value })}
                        className="w-full px-2 py-1 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <button
                        onClick={() => removeField(field.id)}
                        className="w-full p-1 text-red-600 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Generation Options */}
            <div className="mt-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Number of Rows: {numRows.toLocaleString()}
                </label>
                <input
                  type="range"
                  min="1"
                  max="10000"
                  value={numRows}
                  onChange={(e) => setNumRows(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer slider"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1</span>
                  <span>10,000</span>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  Estimated size: ~{estimatedSize.mb} MB
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="include-headers"
                  checked={includeHeaders}
                  onChange={(e) => setIncludeHeaders(e.target.checked)}
                  className="w-4 h-4 text-jpmorgan-blue-600 bg-white border-gray-300 rounded focus:ring-jpmorgan-blue-500"
                />
                <label htmlFor="include-headers" className="text-gray-700">
                  Include headers in CSV
                </label>
              </div>

              <button
                onClick={generateSampleData}
                disabled={isGenerating}
                className="w-full px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-all transform hover:scale-105"
              >
                {isGenerating ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                    <span>Generating...</span>
                  </div>
                ) : (
                  'Generate CSV Data'
                )}
              </button>
            </div>
          </div>

          {/* Preview and Output */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">CSV Output</h3>
            
            {/* Data Preview Table */}
            {rows.length > 0 && (
              <div className="mb-4">
                <h4 className="text-md font-medium text-gray-900 mb-2">Data Preview (First 5 rows)</h4>
                <div className="bg-gray-50 rounded-lg border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto max-h-48">
                    <table className="min-w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          {fields.filter(f => f.name.trim()).map(field => (
                            <th key={field.id} className="px-3 py-2 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-b border-gray-200">
                              {field.name}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {rows.slice(0, 5).map((row, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            {fields.filter(f => f.name.trim()).map(field => (
                              <td key={field.id} className="px-3 py-2 text-sm text-gray-900">
                                <input
                                  type="text"
                                  value={row[field.name] || ''}
                                  onChange={(e) => updateRowValue(index, field.name, e.target.value)}
                                  className="w-full bg-transparent border-none text-gray-900 text-xs focus:outline-none focus:bg-white rounded px-1"
                                />
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* CSV Text Output */}
            <div>
              <h4 className="text-md font-medium text-gray-900 mb-2">CSV Text</h4>
              <textarea
                value={csvOutput}
                readOnly
                placeholder="Generated CSV will appear here..."
                className="w-full h-64 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none"
              />
              {csvOutput && (
                <div className="mt-2 text-xs text-gray-500">
                  Generated {rows.length.toLocaleString()} rows • {(csvOutput.length / 1024).toFixed(1)} KB
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Help Section */}
        <div className="mt-8 p-4 bg-jpmorgan-blue-50 border border-jpmorgan-blue-200 rounded-lg">
          <h4 className="text-gray-900 font-semibold mb-2 flex items-center space-x-2">
            <Table className="h-5 w-5" />
            <span>CSV Generator Features</span>
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Field Types:</h5>
              <ul className="space-y-1">
                <li>• Text: Custom text values</li>
                <li>• Number: Numeric data</li>
                <li>• Email: Email addresses</li>
                <li>• Date: Date values (YYYY-MM-DD)</li>
                <li>• Boolean: true/false values</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Performance:</h5>
              <ul className="space-y-1">
                <li>• Optimized for large datasets</li>
                <li>• Chunked processing</li>
                <li>• Memory efficient</li>
                <li>• Size estimation</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Export Options:</h5>
              <ul className="space-y-1">
                <li>• Include/exclude headers</li>
                <li>• Up to 10,000 rows</li>
                <li>• Editable preview data</li>
                <li>• Download as .csv file</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};