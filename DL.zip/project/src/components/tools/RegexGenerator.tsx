import React, { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, Download, TestTube, AlertCircle, CheckCircle } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/fileUtils';

interface RegexGeneratorProps {
  onBack: () => void;
}

interface RegexPattern {
  name: string;
  pattern: string;
  description: string;
  examples: string[];
}

interface TestCase {
  input: string;
  expected: boolean;
  actual?: boolean;
}

export const RegexGenerator: React.FC<RegexGeneratorProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'generator' | 'tester' | 'validator'>('generator');
  const [selectedPattern, setSelectedPattern] = useState<string>('');
  const [customPattern, setCustomPattern] = useState<string>('');
  const [testString, setTestString] = useState<string>('');
  const [testResults, setTestResults] = useState<RegExpMatchArray | null>(null);
  const [validationInput, setValidationInput] = useState<string>('');
  const [validationType, setValidationType] = useState<string>('email');
  const [validationResult, setValidationResult] = useState<{ valid: boolean; message: string } | null>(null);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [copied, setCopied] = useState(false);

  const regexPatterns: RegexPattern[] = [
    {
      name: 'Email Address',
      pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$',
      description: 'Validates email addresses',
      examples: ['user@example.com', 'test.email+tag@domain.co.uk']
    },
    {
      name: 'Phone Number (US)',
      pattern: '^(\\+1[-\\s]?)?\\(?([0-9]{3})\\)?[-\\s]?([0-9]{3})[-\\s]?([0-9]{4})$',
      description: 'US phone number with optional country code',
      examples: ['+1 (555) 123-4567', '555-123-4567', '5551234567']
    },
    {
      name: 'URL',
      pattern: '^https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b([-a-zA-Z0-9()@:%_\\+.~#?&//=]*)$',
      description: 'HTTP/HTTPS URLs',
      examples: ['https://example.com', 'http://www.site.org/path?query=value']
    },
    {
      name: 'Credit Card',
      pattern: '^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3[0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})$',
      description: 'Major credit card numbers (Visa, MasterCard, Amex, etc.)',
      examples: ['4111111111111111', '5555555555554444']
    },
    {
      name: 'Password (Strong)',
      pattern: '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$',
      description: 'Strong password: 8+ chars, uppercase, lowercase, number, special char',
      examples: ['MyPass123!', 'SecureP@ssw0rd']
    },
    {
      name: 'IP Address (IPv4)',
      pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
      description: 'IPv4 address validation',
      examples: ['192.168.1.1', '10.0.0.1', '255.255.255.255']
    },
    {
      name: 'Date (YYYY-MM-DD)',
      pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$',
      description: 'ISO date format',
      examples: ['2024-01-15', '2023-12-31']
    },
    {
      name: 'Hexadecimal Color',
      pattern: '^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$',
      description: 'Hex color codes',
      examples: ['#FF5733', '#abc', '#123456']
    },
    {
      name: 'Social Security Number',
      pattern: '^\\d{3}-\\d{2}-\\d{4}$',
      description: 'US SSN format',
      examples: ['123-45-6789', '987-65-4321']
    },
    {
      name: 'Username',
      pattern: '^[a-zA-Z0-9_]{3,20}$',
      description: 'Username: 3-20 chars, letters, numbers, underscore',
      examples: ['user123', 'john_doe', 'admin']
    }
  ];

  const validationPatterns = {
    email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    phone: /^(\+1[-\s]?)?\(?([0-9]{3})\)?[-\s]?([0-9]{3})[-\s]?([0-9]{4})$/,
    url: /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/,
    number: /^-?\d+(\.\d+)?$/,
    integer: /^-?\d+$/,
    alphanumeric: /^[a-zA-Z0-9]+$/,
    letters: /^[a-zA-Z]+$/,
    creditcard: /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3[0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})$/,
    ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
    date: /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/,
    time: /^([01]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/,
    hexcolor: /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/,
    ssn: /^\d{3}-\d{2}-\d{4}$/,
    zipcode: /^\d{5}(-\d{4})?$/,
    username: /^[a-zA-Z0-9_]{3,20}$/
  };

  const getCurrentPattern = () => {
    return customPattern || selectedPattern;
  };

  const testRegex = () => {
    const pattern = getCurrentPattern();
    if (!pattern || !testString) {
      setTestResults(null);
      return;
    }

    try {
      const regex = new RegExp(pattern, 'g');
      const matches = testString.match(regex);
      setTestResults(matches);
    } catch (error) {
      setTestResults(null);
    }
  };

  const validateInput = () => {
    if (!validationInput.trim()) {
      setValidationResult(null);
      return;
    }

    const pattern = validationPatterns[validationType as keyof typeof validationPatterns];
    const isValid = pattern.test(validationInput);
    
    setValidationResult({
      valid: isValid,
      message: isValid 
        ? `Valid ${validationType}` 
        : `Invalid ${validationType} format`
    });
  };

  const addTestCase = () => {
    const newTestCase: TestCase = {
      input: '',
      expected: true
    };
    setTestCases([...testCases, newTestCase]);
  };

  const updateTestCase = (index: number, updates: Partial<TestCase>) => {
    const updated = testCases.map((tc, i) => 
      i === index ? { ...tc, ...updates } : tc
    );
    setTestCases(updated);
  };

  const removeTestCase = (index: number) => {
    setTestCases(testCases.filter((_, i) => i !== index));
  };

  const runTestCases = () => {
    const pattern = getCurrentPattern();
    if (!pattern) return;

    try {
      const regex = new RegExp(pattern);
      const updated = testCases.map(tc => ({
        ...tc,
        actual: regex.test(tc.input)
      }));
      setTestCases(updated);
    } catch (error) {
      console.error('Invalid regex pattern');
    }
  };

  useEffect(() => {
    if (activeTab === 'tester') {
      testRegex();
    }
  }, [testString, selectedPattern, customPattern, activeTab]);

  useEffect(() => {
    if (activeTab === 'validator') {
      validateInput();
    }
  }, [validationInput, validationType, activeTab]);

  const handleCopy = async () => {
    const content = getCurrentPattern();
    if (content) {
      const success = await copyToClipboard(content);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleDownload = () => {
    const pattern = getCurrentPattern();
    if (pattern) {
      const content = `Regex Pattern: ${pattern}\n\nDescription: ${
        regexPatterns.find(p => p.pattern === selectedPattern)?.description || 'Custom pattern'
      }\n\nTest Cases:\n${testCases.map(tc => 
        `Input: "${tc.input}" | Expected: ${tc.expected} | Actual: ${tc.actual}`
      ).join('\n')}`;
      
      downloadFile(content, 'regex-pattern.txt');
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Regex Generator & Validator</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              disabled={!getCurrentPattern()}
              className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={!getCurrentPattern()}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-2 mb-6">
          <button
            onClick={() => setActiveTab('generator')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'generator'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Pattern Generator
          </button>
          <button
            onClick={() => setActiveTab('tester')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'tester'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Pattern Tester
          </button>
          <button
            onClick={() => setActiveTab('validator')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'validator'
                ? 'bg-jpmorgan-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Input Validator
          </button>
        </div>

        {/* Pattern Generator Tab */}
        {activeTab === 'generator' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Pattern Selection */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Common Patterns</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {regexPatterns.map((pattern) => (
                    <div
                      key={pattern.name}
                      onClick={() => {
                        setSelectedPattern(pattern.pattern);
                        setCustomPattern('');
                      }}
                      className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                        selectedPattern === pattern.pattern
                          ? 'border-jpmorgan-blue-500 bg-jpmorgan-blue-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50'
                      }`}
                    >
                      <h4 className="font-medium text-gray-900 mb-1">{pattern.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{pattern.description}</p>
                      <code className="text-xs text-gray-700 bg-gray-100 px-2 py-1 rounded">
                        {pattern.pattern}
                      </code>
                      <div className="mt-2">
                        <p className="text-xs text-gray-600 mb-1">Examples:</p>
                        {pattern.examples.map((example, idx) => (
                          <span key={idx} className="text-xs text-green-600 mr-2">
                            {example}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Custom Pattern */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Custom Pattern</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Custom Regex Pattern
                    </label>
                    <textarea
                      value={customPattern}
                      onChange={(e) => {
                        setCustomPattern(e.target.value);
                        setSelectedPattern('');
                      }}
                      placeholder="Enter your custom regex pattern..."
                      className="w-full h-24 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Current Pattern
                    </label>
                    <div className="p-4 bg-gray-50 border border-gray-300 rounded-lg">
                      <code className="text-gray-900 font-mono text-sm break-all">
                        {getCurrentPattern() || 'No pattern selected'}
                      </code>
                    </div>
                  </div>

                  {getCurrentPattern() && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        JavaScript Usage
                      </label>
                      <div className="p-4 bg-gray-50 border border-gray-300 rounded-lg">
                        <code className="text-green-600 font-mono text-sm">
                          const regex = new RegExp('{getCurrentPattern()}');<br/>
                          const isValid = regex.test(inputString);
                        </code>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Pattern Tester Tab */}
        {activeTab === 'tester' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Test String
                </label>
                <textarea
                  value={testString}
                  onChange={(e) => setTestString(e.target.value)}
                  placeholder="Enter text to test against the regex pattern..."
                  className="w-full h-32 p-4 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Test Results
                </label>
                <div className="h-32 p-4 bg-gray-50 border border-gray-300 rounded-lg overflow-auto">
                  {testResults ? (
                    <div>
                      <p className="text-green-600 font-semibold mb-2">✓ Match Found</p>
                      <div className="space-y-1">
                        {testResults.map((match, index) => (
                          <div key={index} className="text-gray-900 font-mono text-sm">
                            Match {index + 1}: <span className="text-yellow-600">"{match}"</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : testString && getCurrentPattern() ? (
                    <p className="text-red-600">✗ No Match</p>
                  ) : (
                    <p className="text-gray-500">Enter a test string and select a pattern</p>
                  )}
                </div>
              </div>
            </div>

            {/* Test Cases */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Test Cases</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={addTestCase}
                    className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-colors"
                  >
                    Add Test Case
                  </button>
                  <button
                    onClick={runTestCases}
                    disabled={!getCurrentPattern() || testCases.length === 0}
                    className="flex items-center space-x-1 px-3 py-1 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded text-sm transition-colors"
                  >
                    <TestTube className="h-3 w-3" />
                    <span>Run Tests</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                {testCases.map((testCase, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="col-span-6">
                      <input
                        type="text"
                        placeholder="Test input"
                        value={testCase.input}
                        onChange={(e) => updateTestCase(index, { input: e.target.value })}
                        className="w-full px-2 py-1 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-1 focus:ring-jpmorgan-blue-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <select
                        value={testCase.expected.toString()}
                        onChange={(e) => updateTestCase(index, { expected: e.target.value === 'true' })}
                        className="w-full px-2 py-1 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-1 focus:ring-jpmorgan-blue-500"
                      >
                        <option value="true">Should Match</option>
                        <option value="false">Should Not Match</option>
                      </select>
                    </div>
                    <div className="col-span-2 text-center">
                      {testCase.actual !== undefined && (
                        <span className={`text-sm font-semibold ${
                          testCase.actual === testCase.expected ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {testCase.actual === testCase.expected ? '✓ Pass' : '✗ Fail'}
                        </span>
                      )}
                    </div>
                    <div className="col-span-2 text-center">
                      <button
                        onClick={() => removeTestCase(index)}
                        className="text-red-600 hover:text-red-700 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Input Validator Tab */}
        {activeTab === 'validator' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Validation Type
                </label>
                <select
                  value={validationType}
                  onChange={(e) => setValidationType(e.target.value)}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                >
                  <option value="email">Email Address</option>
                  <option value="phone">Phone Number</option>
                  <option value="url">URL</option>
                  <option value="number">Number</option>
                  <option value="integer">Integer</option>
                  <option value="alphanumeric">Alphanumeric</option>
                  <option value="letters">Letters Only</option>
                  <option value="creditcard">Credit Card</option>
                  <option value="ipv4">IPv4 Address</option>
                  <option value="date">Date (YYYY-MM-DD)</option>
                  <option value="time">Time (HH:MM)</option>
                  <option value="hexcolor">Hex Color</option>
                  <option value="ssn">Social Security Number</option>
                  <option value="zipcode">ZIP Code</option>
                  <option value="username">Username</option>
                </select>

                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Input to Validate
                  </label>
                  <input
                    type="text"
                    value={validationInput}
                    onChange={(e) => setValidationInput(e.target.value)}
                    placeholder={`Enter ${validationType} to validate...`}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Validation Result
                </label>
                <div className="h-32 p-4 bg-gray-50 border border-gray-300 rounded-lg flex items-center justify-center">
                  {validationResult ? (
                    <div className={`flex items-center space-x-3 ${
                      validationResult.valid ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {validationResult.valid ? (
                        <CheckCircle className="h-8 w-8" />
                      ) : (
                        <AlertCircle className="h-8 w-8" />
                      )}
                      <div>
                        <p className="font-semibold">{validationResult.message}</p>
                        <p className="text-sm opacity-75">
                          {validationResult.valid ? 'Input matches the expected format' : 'Input does not match the expected format'}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500">Enter input to validate</p>
                  )}
                </div>

                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Pattern Used
                  </label>
                  <div className="p-3 bg-gray-50 border border-gray-300 rounded-lg">
                    <code className="text-gray-700 font-mono text-sm break-all">
                      {validationPatterns[validationType as keyof typeof validationPatterns]?.source || 'No pattern'}
                    </code>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Help Section */}
        <div className="mt-8 p-4 bg-jpmorgan-blue-50 border border-jpmorgan-blue-200 rounded-lg">
          <h4 className="text-gray-900 font-semibold mb-2">Regex Tools Features</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Pattern Generator:</h5>
              <ul className="space-y-1">
                <li>• Common regex patterns</li>
                <li>• Custom pattern creation</li>
                <li>• JavaScript code examples</li>
                <li>• Pattern explanations</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Pattern Tester:</h5>
              <ul className="space-y-1">
                <li>• Real-time pattern testing</li>
                <li>• Match highlighting</li>
                <li>• Test case management</li>
                <li>• Batch testing</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Input Validator:</h5>
              <ul className="space-y-1">
                <li>• Pre-built validation types</li>
                <li>• Real-time validation</li>
                <li>• Clear success/error states</li>
                <li>• Pattern visualization</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};