import React, { useState, useCallback } from 'react';
import { ArrowLeft, Upload, Download, Plus, Trash2, Edit3, Save, X, FileText, Copy } from 'lucide-react';
import * as XLSX from 'xlsx';
import { parseString, Builder } from 'xml2js';
import { FileData, TableRow } from '../../types';

interface FileUploaderProps {
  onBack: () => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onBack }) => {
  const [files, setFiles] = useState<FileData[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null);
  const [editingCell, setEditingCell] = useState<{ row: number; col: string } | null>(null);
  const [editValue, setEditValue] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    droppedFiles.forEach(processFile);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(processFile);
    }
  };

  const processFile = async (file: File) => {
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    try {
      if (fileExtension === 'json') {
        const text = await file.text();
        const jsonData = JSON.parse(text);
        const processedData = Array.isArray(jsonData) ? jsonData : [jsonData];
        
        const newFile: FileData = {
          id: Date.now().toString(),
          name: file.name,
          type: 'json',
          data: processedData,
          headers: processedData.length > 0 ? Object.keys(processedData[0]) : []
        };
        
        setFiles(prev => [...prev, newFile]);
      } else if (fileExtension === 'csv') {
        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim());
        if (lines.length === 0) return;
        
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const data = lines.slice(1).map(line => {
          const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
          const row: TableRow = {};
          headers.forEach((header, index) => {
            row[header] = values[index] || '';
          });
          return row;
        });
        
        const newFile: FileData = {
          id: Date.now().toString(),
          name: file.name,
          type: 'csv',
          data: data,
          headers: headers
        };
        
        setFiles(prev => [...prev, newFile]);
      } else if (fileExtension === 'xml') {
        const text = await file.text();
        parseString(text, (err, result) => {
          if (!err) {
            const newFile: FileData = {
              id: Date.now().toString(),
              name: file.name,
              type: 'xml',
              data: result,
              headers: []
            };
            setFiles(prev => [...prev, newFile]);
          }
        });
      } else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        const newFile: FileData = {
          id: Date.now().toString(),
          name: file.name,
          type: 'excel',
          data: jsonData,
          headers: jsonData.length > 0 ? Object.keys(jsonData[0] as object) : []
        };
        
        setFiles(prev => [...prev, newFile]);
      }
    } catch (error) {
      console.error('Error processing file:', error);
    }
  };

  const addRow = () => {
    if (!selectedFile) return;
    
    const newRow: TableRow = {};
    selectedFile.headers?.forEach(header => {
      newRow[header] = '';
    });
    
    const updatedFile = {
      ...selectedFile,
      data: [...selectedFile.data, newRow]
    };
    
    setSelectedFile(updatedFile);
    setFiles(prev => prev.map(f => f.id === selectedFile.id ? updatedFile : f));
  };

  const duplicateRow = (index: number) => {
    if (!selectedFile) return;
    
    const rowToDuplicate = { ...selectedFile.data[index] };
    const updatedData = [...selectedFile.data];
    updatedData.splice(index + 1, 0, rowToDuplicate);
    
    const updatedFile = {
      ...selectedFile,
      data: updatedData
    };
    
    setSelectedFile(updatedFile);
    setFiles(prev => prev.map(f => f.id === selectedFile.id ? updatedFile : f));
  };

  const deleteRow = (index: number) => {
    if (!selectedFile) return;
    
    const updatedFile = {
      ...selectedFile,
      data: selectedFile.data.filter((_: any, i: number) => i !== index)
    };
    
    setSelectedFile(updatedFile);
    setFiles(prev => prev.map(f => f.id === selectedFile.id ? updatedFile : f));
  };

  const startEdit = (row: number, col: string, value: any) => {
    setEditingCell({ row, col });
    setEditValue(String(value || ''));
  };

  const saveEdit = () => {
    if (!selectedFile || !editingCell) return;
    
    const updatedData = [...selectedFile.data];
    updatedData[editingCell.row][editingCell.col] = editValue;
    
    const updatedFile = {
      ...selectedFile,
      data: updatedData
    };
    
    setSelectedFile(updatedFile);
    setFiles(prev => prev.map(f => f.id === selectedFile.id ? updatedFile : f));
    setEditingCell(null);
    setEditValue('');
  };

  const cancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  const downloadFile = (file: FileData) => {
    let content = '';
    let mimeType = '';
    let filename = '';
    
    if (file.type === 'json') {
      content = JSON.stringify(file.data, null, 2);
      mimeType = 'application/json';
      filename = file.name.replace(/\.[^/.]+$/, '') + '_modified.json';
    } else if (file.type === 'csv') {
      const headers = file.headers || [];
      const csvContent = [
        headers.join(','),
        ...file.data.map((row: TableRow) => 
          headers.map(header => `"${(row[header] || '').toString().replace(/"/g, '""')}"`).join(',')
        )
      ].join('\n');
      content = csvContent;
      mimeType = 'text/csv';
      filename = file.name.replace(/\.[^/.]+$/, '') + '_modified.csv';
    } else if (file.type === 'xml') {
      const builder = new Builder();
      content = builder.buildObject(file.data);
      mimeType = 'application/xml';
      filename = file.name.replace(/\.[^/.]+$/, '') + '_modified.xml';
    } else if (file.type === 'excel') {
      const ws = XLSX.utils.json_to_sheet(file.data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, file.name.replace(/\.[^/.]+$/, '') + '_modified.xlsx');
      return;
    }
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const renderTable = (file: FileData) => {
    if (file.type === 'xml') {
      return (
        <div className="bg-gray-50 text-gray-900 p-4 rounded-lg font-mono text-sm overflow-auto max-h-96 border border-gray-200">
          <pre>{JSON.stringify(file.data, null, 2)}</pre>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto max-h-96">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-b border-gray-200">
                Actions
              </th>
              {file.headers?.map(header => (
                <th key={header} className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-b border-gray-200">
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {file.data.map((row: TableRow, rowIndex: number) => (
              <tr key={rowIndex} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => duplicateRow(rowIndex)}
                      className="text-jpmorgan-blue-600 hover:text-jpmorgan-blue-700 transition-colors p-1 rounded hover:bg-jpmorgan-blue-50"
                      title="Duplicate row"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteRow(rowIndex)}
                      className="text-red-600 hover:text-red-700 transition-colors p-1 rounded hover:bg-red-50"
                      title="Delete row"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
                {file.headers?.map(header => (
                  <td key={header} className="px-4 py-3 whitespace-nowrap">
                    {editingCell?.row === rowIndex && editingCell?.col === header ? (
                      <div className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="px-3 py-2 bg-white border border-gray-300 rounded text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-jpmorgan-blue-500 focus:border-transparent min-w-[150px]"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') saveEdit();
                            if (e.key === 'Escape') cancelEdit();
                          }}
                        />
                        <button
                          onClick={saveEdit}
                          className="text-green-600 hover:text-green-700 p-1 rounded hover:bg-green-50"
                        >
                          <Save className="h-4 w-4" />
                        </button>
                        <button
                          onClick={cancelEdit}
                          className="text-red-600 hover:text-red-700 p-1 rounded hover:bg-red-50"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => startEdit(rowIndex, header, row[header])}
                        className="cursor-pointer hover:bg-gray-100 px-3 py-2 rounded text-sm text-gray-900 min-h-[32px] min-w-[100px] flex items-center transition-colors"
                      >
                        {String(row[header] || '')}
                      </div>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">File Data Manager</h1>

        {/* File Upload Area */}
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors mb-6 ${
            dragActive
              ? 'border-jpmorgan-blue-400 bg-jpmorgan-blue-50'
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-gray-900 font-semibold mb-2">
            Upload JSON, XML, CSV, or Excel Files
          </h3>
          <p className="text-gray-600 mb-4">
            Drag and drop your files here, or click to browse
          </p>
          <input
            type="file"
            multiple
            accept=".json,.xml,.csv,.xlsx,.xls"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg cursor-pointer transition-all transform hover:scale-105 shadow-lg"
          >
            <Upload className="h-4 w-4" />
            <span>Choose Files</span>
          </label>
        </div>

        {/* File List and Editor */}
        {files.length > 0 && (
          <div className="space-y-6">
            {/* Uploaded Files List */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Uploaded Files</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {files.map((file) => (
                  <div
                    key={file.id}
                    onClick={() => setSelectedFile(file)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all transform hover:scale-[1.02] ${
                      selectedFile?.id === file.id
                        ? 'border-jpmorgan-blue-500 bg-jpmorgan-blue-50 shadow-lg'
                        : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-jpmorgan-blue-600 rounded-lg flex items-center justify-center">
                          <FileText className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 text-sm truncate max-w-[120px]">{file.name}</p>
                          <p className="text-xs text-gray-500 uppercase">{file.type}</p>
                          <p className="text-xs text-gray-500">{file.data.length} rows</p>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          downloadFile(file);
                        }}
                        className="text-gray-500 hover:text-gray-700 transition-colors p-2 rounded hover:bg-gray-100"
                      >
                        <Download className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* File Editor */}
            {selectedFile && (
              <div className="bg-gray-50 rounded-lg border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      Editing: {selectedFile.name}
                    </h3>
                    <p className="text-gray-600 text-sm">
                      {selectedFile.type.toUpperCase()} • {selectedFile.data.length} rows
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    {selectedFile.type !== 'xml' && (
                      <button
                        onClick={addRow}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Add Row</span>
                      </button>
                    )}
                    <button
                      onClick={() => downloadFile(selectedFile)}
                      className="flex items-center space-x-2 px-4 py-2 bg-jpmorgan-blue-600 hover:bg-jpmorgan-blue-700 text-white rounded-lg text-sm transition-colors"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
                
                {renderTable(selectedFile)}
              </div>
            )}
          </div>
        )}

        {files.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <Edit3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <p className="text-lg mb-2">No files uploaded yet</p>
            <p className="text-sm">Upload JSON, XML, CSV, or Excel files to start editing data</p>
          </div>
        )}

        {/* Help Section */}
        <div className="mt-8 p-4 bg-jpmorgan-blue-50 border border-jpmorgan-blue-200 rounded-lg">
          <h4 className="text-gray-900 font-semibold mb-2">File Data Manager Features</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Supported Formats:</h5>
              <ul className="space-y-1">
                <li>• JSON files (.json)</li>
                <li>• XML files (.xml)</li>
                <li>• CSV files (.csv)</li>
                <li>• Excel files (.xlsx, .xls)</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Edit Features:</h5>
              <ul className="space-y-1">
                <li>• Click cells to edit values</li>
                <li>• Add/duplicate/remove rows</li>
                <li>• Real-time data updates</li>
                <li>• Keyboard shortcuts (Enter/Escape)</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-1">Export Options:</h5>
              <ul className="space-y-1">
                <li>• Download modified files</li>
                <li>• Preserve original format</li>
                <li>• Automatic file naming</li>
                <li>• Multiple file support</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};