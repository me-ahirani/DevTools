import React, { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, RefreshCw as Refresh } from 'lucide-react';
import { copyToClipboard } from '../../utils/fileUtils';

interface UUIDGeneratorProps {
  onBack: () => void;
}

export const UUIDGenerator: React.FC<UUIDGeneratorProps> = ({ onBack }) => {
  const [uuids, setUuids] = useState<string[]>([]);
  const [count, setCount] = useState(5);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const generateUUID = (): string => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  };

  const generateUUIDs = () => {
    const newUuids = Array.from({ length: count }, () => generateUUID());
    setUuids(newUuids);
  };

  useEffect(() => {
    generateUUIDs();
  }, [count]);

  const handleCopy = async (uuid: string, index: number) => {
    const success = await copyToClipboard(uuid);
    if (success) {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  const handleCopyAll = async () => {
    const allUuids = uuids.join('\n');
    await copyToClipboard(allUuids);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Tools</span>
        </button>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">UUID Generator</h1>
          <div className="flex space-x-2">
            <button
              onClick={handleCopyAll}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Copy className="h-4 w-4" />
              <span>Copy All</span>
            </button>
            <button
              onClick={generateUUIDs}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
            >
              <Refresh className="h-4 w-4" />
              <span>Generate</span>
            </button>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Number of UUIDs: {count}
          </label>
          <input
            type="range"
            min="1"
            max="20"
            value={count}
            onChange={(e) => setCount(parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>1</span>
            <span>20</span>
          </div>
        </div>

        <div className="space-y-3">
          {uuids.map((uuid, index) => (
            <div
              key={index}
              className="flex items-center space-x-3 p-3 bg-black/30 rounded-lg border border-white/10"
            >
              <code className="flex-1 text-white font-mono text-sm break-all">
                {uuid}
              </code>
              <button
                onClick={() => handleCopy(uuid, index)}
                className="flex items-center space-x-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
              >
                {copiedIndex === index ? (
                  <>
                    <Check className="h-4 w-4" />
                    <span className="text-xs">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    <span className="text-xs">Copy</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <h3 className="text-white font-semibold mb-2">About UUIDs</h3>
          <p className="text-gray-300 text-sm">
            UUID (Universally Unique Identifier) is a 128-bit number used to identify information in computer systems. 
            The probability of duplicating a UUID is negligible, making it perfect for database keys, session IDs, and unique identifiers.
          </p>
        </div>
      </div>
    </div>
  );
};