# WPI H2H Tools Frontend

React-based frontend application for the WPI H2H Tools suite.

## Features

- **Partner Status Checker** - Monitor partner API connections and health
- **Client Status Checker** - View client account information and usage
- **Duplicate Data Checker** - Find and analyze duplicate entries
- **Environment Comparison** - Compare configuration files between environments
- **JSON Data Generator** - Create mock JSON data with templates

## Technology Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- ESLint

## Getting Started

```bash
# Navigate to frontend directory
cd wpi_tools/frontend

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

The application will be available at `http://localhost:5173`

## Project Structure

```
src/
├── components/
│   ├── Layout/
│   │   ├── Header.tsx
│   │   ├── Navigation.tsx
│   │   └── Footer.tsx
│   └── Tools/
│       ├── PartnerStatus.tsx
│       ├── ClientStatus.tsx
│       ├── DupCheck.tsx
│       ├── EnvComparison.tsx
│       └── JsonGenerator.tsx
├── App.tsx
├── main.tsx
└── index.css
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npm run preview` - Preview production build