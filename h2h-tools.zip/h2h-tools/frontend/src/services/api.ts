import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Partner Status API
export const partnerStatusApi = {
  getPartnerStatus: (partnerId: string) => 
    api.get(`/partner-status/${partnerId}`),
  
  getAllPartnerStatuses: () => 
    api.get('/partner-status'),
  
  createPartnerStatus: (data: any) => 
    api.post('/partner-status', data),
  
  updatePartnerStatus: (partnerId: string, data: any) => 
    api.put(`/partner-status/${partnerId}`, data),
  
  deletePartnerStatus: (partnerId: string) => 
    api.delete(`/partner-status/${partnerId}`),
  
  syncPartnerStatus: (partnerId: string) => 
    api.post(`/partner-status/${partnerId}/sync`),
  
  getPartnerHealth: (partnerId: string) => 
    api.get(`/partner-status/${partnerId}/health`),
};

// Client Status API
export const clientStatusApi = {
  getClientStatus: (clientId: string) => 
    api.get(`/client-status/${clientId}`),
  
  getAllClientStatuses: () => 
    api.get('/client-status'),
  
  createClientStatus: (data: any) => 
    api.post('/client-status', data),
  
  updateClientStatus: (clientId: string, data: any) => 
    api.put(`/client-status/${clientId}`, data),
  
  deleteClientStatus: (clientId: string) => 
    api.delete(`/client-status/${clientId}`),
  
  getClientUsage: (clientId: string) => 
    api.get(`/client-status/${clientId}/usage`),
  
  getClientServices: (clientId: string) => 
    api.get(`/client-status/${clientId}/services`),
};

// Duplicate Check API
export const duplicateCheckApi = {
  checkDuplicates: (data: any) => 
    api.post('/duplicate-check', data),
  
  checkEmailDuplicates: (data: any) => 
    api.post('/duplicate-check/email', data),
  
  checkPhoneDuplicates: (data: any) => 
    api.post('/duplicate-check/phone', data),
  
  checkIdDuplicates: (data: any) => 
    api.post('/duplicate-check/id', data),
};

// Environment Comparison API
export const environmentComparisonApi = {
  compareEnvironments: (data: any) => 
    api.post('/environment-comparison', data),
  
  compareConfigurations: (data: any) => 
    api.post('/environment-comparison/config', data),
  
  compareProperties: (data: any) => 
    api.post('/environment-comparison/properties', data),
};

// JSON Generator API
export const jsonGeneratorApi = {
  generateJson: (data: any) => 
    api.post('/json-generator', data),
  
  generateMockData: (data: any) => 
    api.post('/json-generator/mock-data', data),
  
  generateFromTemplate: (data: any) => 
    api.post('/json-generator/template', data),
  
  getAvailableTemplates: () => 
    api.get('/json-generator/templates'),
};

export default api;