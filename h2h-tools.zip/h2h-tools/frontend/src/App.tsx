import React from 'react';
import Navigation from './components/Layout/Navigation';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import PartnerStatus from './components/Tools/WPI/PartnerStatus';
import ClientStatus from './components/Tools/WPI/ClientStatus';
import DupCheck from './components/Tools/WPI/DupCheck';
import EnvComparison from './components/Tools/WPI/EnvComparison';
import JsonGenerator from './components/Tools/WPI/JsonGenerator';

function App() {
  const [activeTab, setActiveTab] = React.useState('partner-status');
  const [mainTab, setMainTab] = React.useState('wpi-tools');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'partner-status':
        return <PartnerStatus />;
      case 'client-status':
        return <ClientStatus />;
      case 'dup-check':
        return <DupCheck />;
      case 'env-comparison':
        return <EnvComparison />;
      case 'json-generator':
        return <JsonGenerator />;
      default:
        return <PartnerStatus />;
    }
  };

  const renderMainTabContent = () => {
    switch (mainTab) {
      case 'wpi-tools':
        return <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />;
      case 'security-tools':
        return <div className="p-8 text-center text-lg text-gray-700">Security Tools coming soon...</div>;
      case 'file-tools':
        return <div className="p-8 text-center text-lg text-gray-700">File Tools coming soon...</div>;
      default:
        return null;
    }
  };

  const renderMainTabButtons = () => (
    <div className="flex space-x-8 border-b border-gray-200 bg-white rounded-t-md">
      <button
        className={`py-3 px-6 font-semibold text-lg transition-colors duration-200 ${mainTab === 'wpi-tools' ? 'border-b-4 border-blue-900 text-blue-900 bg-gray-100' : 'border-b-4 border-transparent text-gray-500 hover:text-gray-700'}`}
        onClick={() => setMainTab('wpi-tools')}
      >
        WPI Tools
      </button>
      <button
        className={`py-3 px-6 font-semibold text-lg transition-colors duration-200 ${mainTab === 'security-tools' ? 'border-b-4 border-blue-900 text-blue-900 bg-gray-100' : 'border-b-4 border-transparent text-gray-500 hover:text-gray-700'}`}
        onClick={() => setMainTab('security-tools')}
      >
        Security Tools
      </button>
      <button
        className={`py-3 px-6 font-semibold text-lg transition-colors duration-200 ${mainTab === 'file-tools' ? 'border-b-4 border-blue-900 text-blue-900 bg-gray-100' : 'border-b-4 border-transparent text-gray-500 hover:text-gray-700'}`}
        onClick={() => setMainTab('file-tools')}
      >
        File Tools
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="container mx-auto max-w-4xl px-2">
        {renderMainTabButtons()}
        {mainTab === 'wpi-tools' && renderMainTabContent()}
        {mainTab !== 'wpi-tools' && renderMainTabContent()}
      </div>
      <main className="flex-1 container mx-auto max-w-4xl px-2 py-8">
        {mainTab === 'wpi-tools' && renderActiveComponent()}
      </main>
      <Footer />
    </div>
  );
}

export default App;