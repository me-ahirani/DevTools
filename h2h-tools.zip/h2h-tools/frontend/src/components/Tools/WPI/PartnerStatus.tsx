import React, { useState } from 'react';
import { partnerStatusApi } from '../../../services/api';

interface PartnerStatusData {
  partnerId: string;
  status: string;
  lastSync: string;
  connectionHealth: string;
  apiVersion: string;
  endpoints: {
    [key: string]: string;
  };
  metrics: {
    requestsToday: number;
    errorRate: string;
    avgResponseTime: string;
  };
}

const PartnerStatus: React.FC = () => {
  const [partnerId, setPartnerId] = useState('');
  const [statusData, setStatusData] = useState<PartnerStatusData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const checkPartnerStatus = async () => {
    if (!partnerId.trim()) {
      setError('Please enter a Partner ID');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await partnerStatusApi.getPartnerStatus(partnerId);
      setStatusData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch partner status');
    } finally {
      setLoading(false);
    }
  };

  const syncPartnerStatus = async () => {
    if (!partnerId.trim()) return;

    setLoading(true);
    try {
      const response = await partnerStatusApi.syncPartnerStatus(partnerId);
      setStatusData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to sync partner status');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
      case 'connected':
      case 'good':
        return 'text-green-600 bg-green-100';
      case 'warning':
        return 'text-yellow-600 bg-yellow-100';
      case 'error':
      case 'disconnected':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Partner Status Checker</h2>
        
        <div className="mb-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <label htmlFor="partnerId" className="block text-sm font-medium text-gray-700 mb-2">
                Partner ID
              </label>
              <input
                type="text"
                id="partnerId"
                value={partnerId}
                onChange={(e) => setPartnerId(e.target.value)}
                placeholder="Enter Partner ID (e.g., PART-12345)"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex items-end gap-2">
              <button
                onClick={checkPartnerStatus}
                disabled={loading}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Checking...' : 'Check Status'}
              </button>
              {statusData && (
                <button
                  onClick={syncPartnerStatus}
                  disabled={loading}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Sync
                </button>
              )}
            </div>
          </div>
          
          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}
        </div>

        {statusData && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Partner ID</h3>
                <p className="text-lg font-semibold text-gray-900">{statusData.partnerId}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Status</h3>
                <span className={`inline-flex px-2 py-1 text-sm font-medium rounded-full ${getStatusColor(statusData.status)}`}>
                  {statusData.status}
                </span>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Last Sync</h3>
                <p className="text-sm text-gray-900">{new Date(statusData.lastSync).toLocaleString()}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">API Version</h3>
                <p className="text-lg font-semibold text-gray-900">{statusData.apiVersion}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Endpoint Status</h3>
                <div className="space-y-3">
                  {Object.entries(statusData.endpoints).map(([endpoint, status]) => (
                    <div key={endpoint} className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-600 capitalize">{endpoint}</span>
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(status)}`}>
                        {status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Performance Metrics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Requests Today</span>
                    <span className="text-sm font-semibold text-gray-900">{statusData.metrics.requestsToday.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Error Rate</span>
                    <span className="text-sm font-semibold text-gray-900">{statusData.metrics.errorRate}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Avg Response Time</span>
                    <span className="text-sm font-semibold text-gray-900">{statusData.metrics.avgResponseTime}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PartnerStatus;