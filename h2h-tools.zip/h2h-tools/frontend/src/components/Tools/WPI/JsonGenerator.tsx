import React, { useState, useEffect } from 'react';
import { jsonGeneratorApi } from '../../../services/api';

interface JsonField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  value: string;
  required: boolean;
}

const JsonGenerator: React.FC = () => {
  const [fields, setFields] = useState<JsonField[]>([
    { name: 'id', type: 'string', value: '{{uuid}}', required: true },
    { name: 'name', type: 'string', value: '{{name}}', required: true },
    { name: 'email', type: 'string', value: '{{email}}', required: true },
    { name: 'age', type: 'number', value: '{{number(18,65)}}', required: false }
  ]);
  const [generatedJson, setGeneratedJson] = useState('');
  const [recordCount, setRecordCount] = useState(5);
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const response = await jsonGeneratorApi.getAvailableTemplates();
      setTemplates(response.data);
    } catch (err) {
      console.error('Failed to load templates:', err);
    }
  };

  const addField = () => {
    setFields([...fields, { name: '', type: 'string', value: '', required: false }]);
  };

  const removeField = (index: number) => {
    setFields(fields.filter((_, i) => i !== index));
  };

  const updateField = (index: number, updates: Partial<JsonField>) => {
    const newFields = [...fields];
    newFields[index] = { ...newFields[index], ...updates };
    setFields(newFields);
  };

  const generateJson = async () => {
    setError('');
    setLoading(true);
    
    try {
      const requestData = {
        fields,
        recordCount
      };

      const response = await jsonGeneratorApi.generateJson(requestData);
      setGeneratedJson(JSON.stringify(response.data, null, 2));
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to generate JSON. Please check your field configurations.');
    } finally {
      setLoading(false);
    }
  };

  const generateFromTemplate = async (templateName: string) => {
    setLoading(true);
    try {
      const requestData = {
        fields,
        recordCount
      };

      const response = await jsonGeneratorApi.generateFromTemplate(requestData);
      setGeneratedJson(JSON.stringify(response.data, null, 2));
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to generate from template.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedJson);
      // You could add a toast notification here
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const downloadJson = () => {
    const blob = new Blob([generatedJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'generated-data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">JSON Data Generator</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Configuration Panel */}
          <div className="space-y-6">
            <div>
              <label htmlFor="recordCount" className="block text-sm font-medium text-gray-700 mb-2">
                Number of Records
              </label>
              <input
                type="number"
                id="recordCount"
                value={recordCount}
                onChange={(e) => setRecordCount(Math.max(1, parseInt(e.target.value) || 1))}
                min="1"
                max="100"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Templates */}
            {templates.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Quick Templates</h3>
                <div className="flex gap-2 flex-wrap">
                  {templates.map((template, index) => (
                    <button
                      key={index}
                      onClick={() => generateFromTemplate(template.name)}
                      disabled={loading}
                      className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 transition-colors"
                    >
                      {template.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Fields Configuration</h3>
                <button
                  onClick={addField}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors text-sm"
                >
                  Add Field
                </button>
              </div>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {fields.map((field, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-1">Field Name</label>
                        <input
                          type="text"
                          value={field.name}
                          onChange={(e) => updateField(index, { name: e.target.value })}
                          placeholder="field_name"
                          className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-1">Type</label>
                        <select
                          value={field.type}
                          onChange={(e) => updateField(index, { type: e.target.value as JsonField['type'] })}
                          className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                        >
                          <option value="string">String</option>
                          <option value="number">Number</option>
                          <option value="boolean">Boolean</option>
                          <option value="array">Array</option>
                          <option value="object">Object</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <label className="block text-xs font-medium text-gray-600 mb-1">
                        Value/Template
                      </label>
                      <input
                        type="text"
                        value={field.value}
                        onChange={(e) => updateField(index, { value: e.target.value })}
                        placeholder="{{uuid}}, {{name}}, {{email}}, {{number(1,100)}}, {{boolean}}"
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                      />
                    </div>

                    <div className="flex justify-between items-center">
                      <label className="flex items-center text-sm">
                        <input
                          type="checkbox"
                          checked={field.required}
                          onChange={(e) => updateField(index, { required: e.target.checked })}
                          className="mr-2"
                        />
                        Required
                      </label>
                      <button
                        onClick={() => removeField(index)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={generateJson}
              disabled={loading}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Generating...' : 'Generate JSON'}
            </button>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-md">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}
          </div>

          {/* Output Panel */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-800">Generated JSON</h3>
              {generatedJson && (
                <div className="flex gap-2">
                  <button
                    onClick={copyToClipboard}
                    className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                  >
                    Copy
                  </button>
                  <button
                    onClick={downloadJson}
                    className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
                  >
                    Download
                  </button>
                </div>
              )}
            </div>

            <div className="bg-gray-900 rounded-lg p-4 h-96 overflow-auto">
              <pre className="text-green-400 text-sm font-mono whitespace-pre-wrap">
                {generatedJson || 'Click "Generate JSON" to create sample data...'}
              </pre>
            </div>

            {generatedJson && (
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                <h4 className="text-sm font-medium text-blue-800 mb-2">Template Placeholders:</h4>
                <ul className="text-xs text-blue-700 space-y-1">
                  <li><code>{'{{uuid}}'}</code> - Generates a random UUID-like string</li>
                  <li><code>{'{{name}}'}</code> - Generates a random name</li>
                  <li><code>{'{{email}}'}</code> - Generates a random email address</li>
                  <li><code>{'{{number(min,max)}}'}</code> - Generates a random number in range</li>
                  <li><code>{'{{boolean}}'}</code> - Generates a random boolean value</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JsonGenerator;