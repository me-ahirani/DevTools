import React, { useState } from 'react';
import { environmentComparisonApi } from '../../../services/api';

interface ComparisonResult {
  key: string;
  env1Value: string;
  env2Value: string;
  status: 'match' | 'different' | 'missing';
}

interface EnvironmentComparisonResponse {
  results: ComparisonResult[];
  env1Name: string;
  env2Name: string;
  summary: {
    match: number;
    different: number;
    missing: number;
  };
}

const EnvComparison: React.FC = () => {
  const [env1Data, setEnv1Data] = useState('');
  const [env2Data, setEnv2Data] = useState('');
  const [env1Name, setEnv1Name] = useState('Development');
  const [env2Name, setEnv2Name] = useState('Production');
  const [results, setResults] = useState<ComparisonResult[]>([]);
  const [summary, setSummary] = useState<{match: number; different: number; missing: number} | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const compareEnvironments = async () => {
    if (!env1Data.trim() || !env2Data.trim()) {
      setError('Please provide configuration data for both environments');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const requestData = {
        env1Name,
        env2Name,
        env1Data,
        env2Data
      };

      const response = await environmentComparisonApi.compareEnvironments(requestData);
      const responseData: EnvironmentComparisonResponse = response.data;
      
      setResults(responseData.results);
      setSummary(responseData.summary);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to compare environments');
    } finally {
      setLoading(false);
    }
  };

  const clearComparison = () => {
    setResults([]);
    setSummary(null);
    setEnv1Data('');
    setEnv2Data('');
    setError('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'match':
        return 'text-green-600 bg-green-100';
      case 'different':
        return 'text-red-600 bg-red-100';
      case 'missing':
        return 'text-yellow-600 bg-yellow-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'match':
        return '✓';
      case 'different':
        return '✗';
      case 'missing':
        return '⚠';
      default:
        return '?';
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Environment Configuration Comparison</h2>
        
        <div className="space-y-6">
          {/* Environment Names */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="env1Name" className="block text-sm font-medium text-gray-700 mb-2">
                Environment 1 Name
              </label>
              <input
                type="text"
                id="env1Name"
                value={env1Name}
                onChange={(e) => setEnv1Name(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label htmlFor="env2Name" className="block text-sm font-medium text-gray-700 mb-2">
                Environment 2 Name
              </label>
              <input
                type="text"
                id="env2Name"
                value={env2Name}
                onChange={(e) => setEnv2Name(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Configuration Data */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <label htmlFor="env1Data" className="block text-sm font-medium text-gray-700 mb-2">
                {env1Name} Configuration
              </label>
              <textarea
                id="env1Data"
                value={env1Data}
                onChange={(e) => setEnv1Data(e.target.value)}
                placeholder="DATABASE_URL=postgres://localhost:5432/dev&#10;API_KEY=dev-key-123&#10;DEBUG=true&#10;PORT=3000"
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
              />
            </div>
            <div>
              <label htmlFor="env2Data" className="block text-sm font-medium text-gray-700 mb-2">
                {env2Name} Configuration
              </label>
              <textarea
                id="env2Data"
                value={env2Data}
                onChange={(e) => setEnv2Data(e.target.value)}
                placeholder="DATABASE_URL=postgres://prod-db:5432/prod&#10;API_KEY=prod-key-456&#10;DEBUG=false&#10;PORT=80"
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button
              onClick={compareEnvironments}
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? 'Comparing...' : 'Compare Environments'}
            </button>
            
            {results.length > 0 && (
              <button
                onClick={clearComparison}
                className="px-6 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              >
                Clear Results
              </button>
            )}
          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          {/* Results */}
          {results.length > 0 && summary && (
            <div className="space-y-6">
              {/* Summary */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Comparison Summary</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{summary.match}</div>
                    <div className="text-sm text-gray-600">Matching</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{summary.different}</div>
                    <div className="text-sm text-gray-600">Different</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">{summary.missing}</div>
                    <div className="text-sm text-gray-600">Missing</div>
                  </div>
                </div>
              </div>

              {/* Detailed Results */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-100 px-4 py-3 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">Configuration Comparison</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Status</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Configuration Key</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">{env1Name}</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">{env2Name}</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {results.map((result, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(result.status)}`}>
                              {getStatusIcon(result.status)} {result.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 font-mono text-sm text-gray-900">{result.key}</td>
                          <td className="px-4 py-3 font-mono text-sm text-gray-600 max-w-xs truncate" title={result.env1Value}>
                            {result.env1Value}
                          </td>
                          <td className="px-4 py-3 font-mono text-sm text-gray-600 max-w-xs truncate" title={result.env2Value}>
                            {result.env2Value}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnvComparison;