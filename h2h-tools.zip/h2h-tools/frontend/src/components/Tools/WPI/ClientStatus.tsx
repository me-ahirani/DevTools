import React, { useState } from 'react';
import { clientStatusApi } from '../../../services/api';

interface ClientData {
  clientId: string;
  name: string;
  status: string;
  lastActivity: string;
  accountType: string;
  region: string;
  services: {
    [key: string]: string;
  };
  usage: {
    apiCalls: string;
    dataTransfer: string;
    storageUsed: string;
  };
}

const ClientStatus: React.FC = () => {
  const [clientId, setClientId] = useState('');
  const [clientData, setClientData] = useState<ClientData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const checkClientStatus = async () => {
    if (!clientId.trim()) {
      setError('Please enter a Client ID');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await clientStatusApi.getClientStatus(clientId);
      setClientData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch client status');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'text-green-600 bg-green-100';
      case 'maintenance':
        return 'text-yellow-600 bg-yellow-100';
      case 'inactive':
      case 'suspended':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getAccountTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'enterprise':
        return 'text-purple-600 bg-purple-100';
      case 'professional':
        return 'text-blue-600 bg-blue-100';
      case 'basic':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Client Status Checker</h2>
        
        <div className="mb-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <label htmlFor="clientId" className="block text-sm font-medium text-gray-700 mb-2">
                Client ID
              </label>
              <input
                type="text"
                id="clientId"
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                placeholder="Enter Client ID (e.g., CLI-67890)"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={checkClientStatus}
                disabled={loading}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Checking...' : 'Check Status'}
              </button>
            </div>
          </div>
          
          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}
        </div>

        {clientData && (
          <div className="space-y-6">
            {/* Client Overview */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Client Name</h3>
                  <p className="text-lg font-semibold text-gray-900">{clientData.name}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Client ID</h3>
                  <p className="text-lg font-semibold text-gray-900">{clientData.clientId}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Account Type</h3>
                  <span className={`inline-flex px-3 py-1 text-sm font-medium rounded-full ${getAccountTypeColor(clientData.accountType)}`}>
                    {clientData.accountType}
                  </span>
                </div>
              </div>
            </div>

            {/* Status and Activity */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Status</h3>
                <span className={`inline-flex px-2 py-1 text-sm font-medium rounded-full ${getStatusColor(clientData.status)}`}>
                  {clientData.status}
                </span>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Last Activity</h3>
                <p className="text-sm text-gray-900">{new Date(clientData.lastActivity).toLocaleString()}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Region</h3>
                <p className="text-lg font-semibold text-gray-900">{clientData.region}</p>
              </div>
            </div>

            {/* Services and Usage */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Service Status</h3>
                <div className="space-y-3">
                  {Object.entries(clientData.services).map(([service, status]) => (
                    <div key={service} className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-600">{service}</span>
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(status)}`}>
                        {status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Usage Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">API Calls (Today)</span>
                    <span className="text-sm font-semibold text-gray-900">{clientData.usage.apiCalls}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Data Transfer</span>
                    <span className="text-sm font-semibold text-gray-900">{clientData.usage.dataTransfer}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Storage Used</span>
                    <span className="text-sm font-semibold text-gray-900">{clientData.usage.storageUsed}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientStatus;