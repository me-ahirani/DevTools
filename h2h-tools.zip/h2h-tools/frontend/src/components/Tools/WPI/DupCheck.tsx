import React, { useState } from 'react';
import { duplicateCheckApi } from '../../../services/api';

interface DuplicateResult {
  field: string;
  value: string;
  count: number;
  records: Array<{
    id: string;
    source: string;
    lastUpdated: string;
  }>;
}

interface DuplicateCheckResponse {
  duplicates: DuplicateResult[];
  totalDuplicates: number;
  checkType: string;
}

const DupCheck: React.FC = () => {
  const [inputData, setInputData] = useState('');
  const [checkType, setCheckType] = useState('email');
  const [results, setResults] = useState<DuplicateResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const checkForDuplicates = async () => {
    if (!inputData.trim()) {
      setError('Please enter data to check for duplicates');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const requestData = {
        data: inputData,
        checkType: checkType
      };

      let response;
      switch (checkType) {
        case 'email':
          response = await duplicateCheckApi.checkEmailDuplicates(requestData);
          break;
        case 'phone':
          response = await duplicateCheckApi.checkPhoneDuplicates(requestData);
          break;
        case 'id':
          response = await duplicateCheckApi.checkIdDuplicates(requestData);
          break;
        default:
          response = await duplicateCheckApi.checkDuplicates(requestData);
      }

      const responseData: DuplicateCheckResponse = response.data;
      setResults(responseData.duplicates);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to check for duplicates');
    } finally {
      setLoading(false);
    }
  };

  const clearResults = () => {
    setResults([]);
    setInputData('');
    setError('');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Duplicate Data Checker</h2>
        
        <div className="space-y-6">
          <div>
            <label htmlFor="checkType" className="block text-sm font-medium text-gray-700 mb-2">
              Data Type
            </label>
            <select
              id="checkType"
              value={checkType}
              onChange={(e) => setCheckType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="email">Email Addresses</option>
              <option value="phone">Phone Numbers</option>
              <option value="id">Customer IDs</option>
              <option value="name">Names</option>
              <option value="custom">Custom Field</option>
            </select>
          </div>

          <div>
            <label htmlFor="inputData" className="block text-sm font-medium text-gray-700 mb-2">
              Data to Check (one item per line)
            </label>
            <textarea
              id="inputData"
              value={inputData}
              onChange={(e) => setInputData(e.target.value)}
              placeholder={`Enter ${checkType} values, one per line:\n\nexample@email.com\ntest@email.com\nexample@email.com\nuser@email.com`}
              rows={8}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
            />
          </div>

          <div className="flex gap-4">
            <button
              onClick={checkForDuplicates}
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? 'Checking...' : 'Check for Duplicates'}
            </button>
            
            {results.length > 0 && (
              <button
                onClick={clearResults}
                className="px-6 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              >
                Clear Results
              </button>
            )}
          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          {results.length > 0 && (
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                <h3 className="text-lg font-semibold text-yellow-800 mb-2">
                  Duplicates Found: {results.length}
                </h3>
                <p className="text-yellow-700">
                  The following {checkType} values have multiple occurrences in your data.
                </p>
              </div>

              {results.map((result, index) => (
                <div key={index} className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="text-lg font-semibold text-gray-800">{result.value}</h4>
                      <p className="text-sm text-gray-600">Found {result.count} times</p>
                    </div>
                    <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm font-medium">
                      Duplicate
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <h5 className="text-sm font-medium text-gray-700">Record Sources:</h5>
                    {result.records.map((record, recordIndex) => (
                      <div key={recordIndex} className="bg-white p-3 rounded border border-gray-200">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-600">ID:</span> {record.id}
                          </div>
                          <div>
                            <span className="font-medium text-gray-600">Source:</span> {record.source}
                          </div>
                          <div>
                            <span className="font-medium text-gray-600">Last Updated:</span> {record.lastUpdated}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {results.length === 0 && inputData && !loading && !error && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-md">
              <p className="text-green-600">✓ No duplicates found in the provided data.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DupCheck;