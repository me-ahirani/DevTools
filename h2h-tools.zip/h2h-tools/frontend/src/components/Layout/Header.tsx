import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-900 text-white shadow-lg">
      <div className="container mx-auto max-w-4xl px-2 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {/* Tools Icon Logo SVG (Square) */}
            <span className="inline-block">
              <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="3" y="3" width="30" height="30" rx="6" fill="#38bdf8" />
                <g>
                  <path d="M24.5 19.5l-2-2m-1.5-1.5l-6 6a2 2 0 102.83 2.83l6-6m-2.83-2.83a2 2 0 112.83 2.83" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="13.5" cy="13.5" r="2.5" stroke="#fff" strokeWidth="2"/>
                </g>
              </svg>
            </span>
            <h1 className="text-3xl font-bold">H2H Tools</h1>
          </div>
          <div className="flex items-center space-x-4">
            {/* User Login Icon */}
            <span className="inline-block">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="16" cy="16" r="16" fill="#38bdf8" />
                <circle cx="16" cy="13" r="5" fill="#fff" />
                <rect x="8" y="21" width="16" height="6" rx="3" fill="#fff" />
              </svg>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;