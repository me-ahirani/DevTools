import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white py-1">
      <div className="container mx-auto max-w-4xl px-2">
        <div className="border-t border-gray-800 mt-4 pt-4 text-center text-gray-100">
          <p>&copy; 2025 JPMorgan Chase & Co. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;