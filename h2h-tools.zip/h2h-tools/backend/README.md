# WPI H2H Tools Backend

Spring Boot REST API backend for the WPI H2H Tools application.

## Features

- **Partner Status Management** - CRUD operations for partner status tracking
- **Client Status Management** - Client information and usage monitoring
- **Duplicate Data Checking** - API for finding duplicate entries
- **Environment Comparison** - Configuration comparison between environments
- **JSON Data Generation** - Mock data generation with templates

## API Endpoints

### Partner Status
- `GET /api/partner-status/{partnerId}` - Get partner status
- `GET /api/partner-status` - Get all partner statuses
- `POST /api/partner-status` - Create partner status
- `PUT /api/partner-status/{partnerId}` - Update partner status
- `DELETE /api/partner-status/{partnerId}` - Delete partner status
- `POST /api/partner-status/{partnerId}/sync` - Sync partner status
- `GET /api/partner-status/{partnerId}/health` - Get partner health

### Client Status
- `GET /api/client-status/{clientId}` - Get client status
- `GET /api/client-status` - Get all client statuses
- `POST /api/client-status` - Create client status
- `PUT /api/client-status/{clientId}` - Update client status
- `DELETE /api/client-status/{clientId}` - Delete client status
- `GET /api/client-status/{clientId}/usage` - Get client usage
- `GET /api/client-status/{clientId}/services` - Get client services

### Duplicate Check
- `POST /api/duplicate-check` - Check for duplicates
- `POST /api/duplicate-check/email` - Check email duplicates
- `POST /api/duplicate-check/phone` - Check phone duplicates
- `POST /api/duplicate-check/id` - Check ID duplicates

### Environment Comparison
- `POST /api/environment-comparison` - Compare environments
- `POST /api/environment-comparison/config` - Compare configurations
- `POST /api/environment-comparison/properties` - Compare properties

### JSON Generator
- `POST /api/json-generator` - Generate JSON data
- `POST /api/json-generator/mock-data` - Generate mock data
- `POST /api/json-generator/template` - Generate from template
- `GET /api/json-generator/templates` - Get available templates

## Running the Application

```bash
# Navigate to backend directory
cd wpi_tools/backend

# Run with Maven
./mvnw spring-boot:run

# Or build and run JAR
./mvnw clean package
java -jar target/h2h-tools-backend-0.0.1-SNAPSHOT.jar
```

The API will be available at `http://localhost:8080`

## Database

Uses H2 in-memory database for development. Access H2 console at:
`http://localhost:8080/h2-console`

## Technology Stack

- Spring Boot 3.2.0
- Spring Data JPA
- H2 Database
- Maven
- Java 17