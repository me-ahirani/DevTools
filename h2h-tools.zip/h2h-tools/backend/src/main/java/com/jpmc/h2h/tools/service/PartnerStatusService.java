package com.jpmc.h2h.tools.service;

import com.jpmc.h2h.tools.model.PartnerStatus;
import com.jpmc.h2h.tools.repository.PartnerStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class PartnerStatusService {

    @Autowired
    private PartnerStatusRepository partnerStatusRepository;

    public PartnerStatus getPartnerStatus(String partnerId) {
        Optional<PartnerStatus> status = partnerStatusRepository.findByPartnerId(partnerId);
        return status.orElse(createMockPartnerStatus(partnerId));
    }

    public List<PartnerStatus> getAllPartnerStatuses() {
        return partnerStatusRepository.findAll();
    }

    public PartnerStatus createPartnerStatus(PartnerStatus partnerStatus) {
        partnerStatus.setLastSync(LocalDateTime.now());
        return partnerStatusRepository.save(partnerStatus);
    }

    public PartnerStatus updatePartnerStatus(String partnerId, PartnerStatus partnerStatus) {
        Optional<PartnerStatus> existing = partnerStatusRepository.findByPartnerId(partnerId);
        if (existing.isPresent()) {
            PartnerStatus existingStatus = existing.get();
            existingStatus.setStatus(partnerStatus.getStatus());
            existingStatus.setConnectionHealth(partnerStatus.getConnectionHealth());
            existingStatus.setApiVersion(partnerStatus.getApiVersion());
            existingStatus.setEndpoints(partnerStatus.getEndpoints());
            existingStatus.setMetrics(partnerStatus.getMetrics());
            existingStatus.setLastSync(LocalDateTime.now());
            return partnerStatusRepository.save(existingStatus);
        }
        return null;
    }

    public boolean deletePartnerStatus(String partnerId) {
        Optional<PartnerStatus> existing = partnerStatusRepository.findByPartnerId(partnerId);
        if (existing.isPresent()) {
            partnerStatusRepository.delete(existing.get());
            return true;
        }
        return false;
    }

    public PartnerStatus syncPartnerStatus(String partnerId) {
        Optional<PartnerStatus> existing = partnerStatusRepository.findByPartnerId(partnerId);
        if (existing.isPresent()) {
            PartnerStatus status = existing.get();
            status.setLastSync(LocalDateTime.now());
            // Simulate sync operation
            status.setStatus("Active");
            status.setConnectionHealth("Good");
            return partnerStatusRepository.save(status);
        }
        return null;
    }

    public Map<String, Object> getPartnerHealth(String partnerId) {
        Optional<PartnerStatus> status = partnerStatusRepository.findByPartnerId(partnerId);
        if (status.isPresent()) {
            Map<String, Object> health = new HashMap<>();
            health.put("partnerId", partnerId);
            health.put("status", status.get().getStatus());
            health.put("connectionHealth", status.get().getConnectionHealth());
            health.put("lastSync", status.get().getLastSync());
            health.put("endpoints", status.get().getEndpoints());
            return health;
        }
        return null;
    }

    private PartnerStatus createMockPartnerStatus(String partnerId) {
        PartnerStatus mockStatus = new PartnerStatus(partnerId, "Active", "Good", "v2.1");
        
        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("auth", "Connected");
        endpoints.put("data", "Connected");
        endpoints.put("webhook", "Connected");
        mockStatus.setEndpoints(endpoints);
        
        Map<String, String> metrics = new HashMap<>();
        metrics.put("requestsToday", "1247");
        metrics.put("errorRate", "0.2%");
        metrics.put("avgResponseTime", "145ms");
        mockStatus.setMetrics(metrics);
        
        return mockStatus;
    }
}