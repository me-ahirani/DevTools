package com.jpmc.h2h.tools.controller;

import com.jpmc.h2h.tools.dto.DuplicateCheckRequest;
import com.jpmc.h2h.tools.dto.DuplicateCheckResponse;
import com.jpmc.h2h.tools.service.DuplicateCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/duplicate-check")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000"})
public class DuplicateCheckController {

    @Autowired
    private DuplicateCheckService duplicateCheckService;

    @PostMapping
    public ResponseEntity<DuplicateCheckResponse> checkDuplicates(@RequestBody DuplicateCheckRequest request) {
        DuplicateCheckResponse response = duplicateCheckService.checkDuplicates(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/email")
    public ResponseEntity<DuplicateCheckResponse> checkEmailDuplicates(@RequestBody DuplicateCheckRequest request) {
        DuplicateCheckResponse response = duplicateCheckService.checkEmailDuplicates(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/phone")
    public ResponseEntity<DuplicateCheckResponse> checkPhoneDuplicates(@RequestBody DuplicateCheckRequest request) {
        DuplicateCheckResponse response = duplicateCheckService.checkPhoneDuplicates(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/id")
    public ResponseEntity<DuplicateCheckResponse> checkIdDuplicates(@RequestBody DuplicateCheckRequest request) {
        DuplicateCheckResponse response = duplicateCheckService.checkIdDuplicates(request);
        return ResponseEntity.ok(response);
    }
}
