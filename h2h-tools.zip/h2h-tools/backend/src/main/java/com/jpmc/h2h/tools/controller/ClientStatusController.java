package com.jpmc.h2h.tools.controller;

import com.jpmc.h2h.tools.model.ClientStatus;
import com.jpmc.h2h.tools.service.ClientStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/client-status")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000"})
public class ClientStatusController {

    @Autowired
    private ClientStatusService clientStatusService;

    @GetMapping("/{clientId}")
    public ResponseEntity<ClientStatus> getClientStatus(@PathVariable String clientId) {
        ClientStatus status = clientStatusService.getClientStatus(clientId);
        if (status != null) {
            return ResponseEntity.ok(status);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<ClientStatus>> getAllClientStatuses() {
        List<ClientStatus> statuses = clientStatusService.getAllClientStatuses();
        return ResponseEntity.ok(statuses);
    }

    @PostMapping
    public ResponseEntity<ClientStatus> createClientStatus(@RequestBody ClientStatus clientStatus) {
        ClientStatus created = clientStatusService.createClientStatus(clientStatus);
        return ResponseEntity.ok(created);
    }

    @PutMapping("/{clientId}")
    public ResponseEntity<ClientStatus> updateClientStatus(
            @PathVariable String clientId, 
            @RequestBody ClientStatus clientStatus) {
        ClientStatus updated = clientStatusService.updateClientStatus(clientId, clientStatus);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{clientId}")
    public ResponseEntity<Void> deleteClientStatus(@PathVariable String clientId) {
        boolean deleted = clientStatusService.deleteClientStatus(clientId);
        if (deleted) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{clientId}/usage")
    public ResponseEntity<Map<String, Object>> getClientUsage(@PathVariable String clientId) {
        Map<String, Object> usage = clientStatusService.getClientUsage(clientId);
        if (usage != null) {
            return ResponseEntity.ok(usage);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{clientId}/services")
    public ResponseEntity<Map<String, String>> getClientServices(@PathVariable String clientId) {
        Map<String, String> services = clientStatusService.getClientServices(clientId);
        if (services != null) {
            return ResponseEntity.ok(services);
        }
        return ResponseEntity.notFound().build();
    }
}