package com.jpmc.h2h.tools.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Map;

@Entity
@Table(name = "client_status")
public class ClientStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String clientId;
    
    private String name;
    private String status;
    private LocalDateTime lastActivity;
    private String accountType;
    private String region;
    
    @ElementCollection
    @CollectionTable(name = "client_services", joinColumns = @JoinColumn(name = "client_id"))
    @MapKeyColumn(name = "service_name")
    @Column(name = "service_status")
    private Map<String, String> services;
    
    @ElementCollection
    @CollectionTable(name = "client_usage", joinColumns = @JoinColumn(name = "client_id"))
    @MapKeyColumn(name = "usage_type")
    @Column(name = "usage_value")
    private Map<String, String> usage;

    // Constructors
    public ClientStatus() {}

    public ClientStatus(String clientId, String name, String status, String accountType, String region) {
        this.clientId = clientId;
        this.name = name;
        this.status = status;
        this.accountType = accountType;
        this.region = region;
        this.lastActivity = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getLastActivity() { return lastActivity; }
    public void setLastActivity(LocalDateTime lastActivity) { this.lastActivity = lastActivity; }

    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public Map<String, String> getServices() { return services; }
    public void setServices(Map<String, String> services) { this.services = services; }

    public Map<String, String> getUsage() { return usage; }
    public void setUsage(Map<String, String> usage) { this.usage = usage; }
}