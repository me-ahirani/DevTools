package com.jpmc.h2h.tools.service;

import com.jpmc.h2h.tools.dto.JsonGeneratorRequest;
import com.jpmc.h2h.tools.dto.JsonField;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class JsonGeneratorService {

    private final Random random = new Random();
    private final String[] names = {"John Doe", "Jane Smith", "Bob Johnson", "Alice Brown", "Charlie Wilson"};
    private final String[] domains = {"example.com", "test.com", "demo.org"};

    public List<Map<String, Object>> generateJson(JsonGeneratorRequest request) {
        List<Map<String, Object>> records = new ArrayList<>();
        
        for (int i = 0; i < request.getRecordCount(); i++) {
            Map<String, Object> record = new HashMap<>();
            
            for (JsonField field : request.getFields()) {
                if (field.getName() != null && !field.getName().trim().isEmpty()) {
                    Object value = generateMockValue(field.getType(), field.getValue());
                    record.put(field.getName(), value);
                }
            }
            
            records.add(record);
        }
        
        return records;
    }

    public List<Map<String, Object>> generateMockData(JsonGeneratorRequest request) {
        return generateJson(request);
    }

    public Map<String, Object> generateFromTemplate(JsonGeneratorRequest request) {
        if (!request.getFields().isEmpty()) {
            Map<String, Object> template = new HashMap<>();
            
            for (JsonField field : request.getFields()) {
                if (field.getName() != null && !field.getName().trim().isEmpty()) {
                    Object value = generateMockValue(field.getType(), field.getValue());
                    template.put(field.getName(), value);
                }
            }
            
            return template;
        }
        
        return new HashMap<>();
    }

    public List<Map<String, Object>> getAvailableTemplates() {
        List<Map<String, Object>> templates = new ArrayList<>();
        
        Map<String, Object> userTemplate = new HashMap<>();
        userTemplate.put("name", "User Template");
        userTemplate.put("description", "Basic user information");
        userTemplate.put("fields", Arrays.asList("id", "name", "email", "age"));
        templates.add(userTemplate);
        
        Map<String, Object> productTemplate = new HashMap<>();
        productTemplate.put("name", "Product Template");
        productTemplate.put("description", "Product information");
        productTemplate.put("fields", Arrays.asList("id", "name", "price", "category", "inStock"));
        templates.add(productTemplate);
        
        return templates;
    }

    private Object generateMockValue(String type, String template) {
        if (template.contains("{{")) {
            return processTemplate(template);
        }

        switch (type) {
            case "number":
                try {
                    return Double.parseDouble(template);
                } catch (NumberFormatException e) {
                    return random.nextInt(100);
                }
            case "boolean":
                return "true".equalsIgnoreCase(template) || random.nextBoolean();
            case "array":
                try {
                    // Simple array parsing - in real implementation, use JSON parser
                    return Arrays.asList(template.split(","));
                } catch (Exception e) {
                    return new ArrayList<>();
                }
            case "object":
                return new HashMap<>();
            default:
                return template;
        }
    }

    private Object processTemplate(String template) {
        if (template.contains("{{uuid}}")) {
            return UUID.randomUUID().toString().substring(0, 8) + "-" + 
                   UUID.randomUUID().toString().substring(0, 4);
        }
        
        if (template.contains("{{name}}")) {
            return names[random.nextInt(names.length)];
        }
        
        if (template.contains("{{email}}")) {
            String username = UUID.randomUUID().toString().substring(0, 8);
            String domain = domains[random.nextInt(domains.length)];
            return username + "@" + domain;
        }
        
        Pattern numberPattern = Pattern.compile("\\{\\{number\\((\\d+),(\\d+)\\)\\}\\}");
        Matcher matcher = numberPattern.matcher(template);
        if (matcher.find()) {
            int min = Integer.parseInt(matcher.group(1));
            int max = Integer.parseInt(matcher.group(2));
            return random.nextInt(max - min + 1) + min;
        }
        
        if (template.contains("{{boolean}}")) {
            return random.nextBoolean();
        }
        
        return template;
    }
}