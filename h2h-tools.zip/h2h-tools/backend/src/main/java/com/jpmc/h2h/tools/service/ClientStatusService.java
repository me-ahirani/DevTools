package com.jpmc.h2h.tools.service;

import com.jpmc.h2h.tools.model.ClientStatus;
import com.jpmc.h2h.tools.repository.ClientStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ClientStatusService {

    @Autowired
    private ClientStatusRepository clientStatusRepository;

    public ClientStatus getClientStatus(String clientId) {
        Optional<ClientStatus> status = clientStatusRepository.findByClientId(clientId);
        return status.orElse(createMockClientStatus(clientId));
    }

    public List<ClientStatus> getAllClientStatuses() {
        return clientStatusRepository.findAll();
    }

    public ClientStatus createClientStatus(ClientStatus clientStatus) {
        clientStatus.setLastActivity(LocalDateTime.now());
        return clientStatusRepository.save(clientStatus);
    }

    public ClientStatus updateClientStatus(String clientId, ClientStatus clientStatus) {
        Optional<ClientStatus> existing = clientStatusRepository.findByClientId(clientId);
        if (existing.isPresent()) {
            ClientStatus existingStatus = existing.get();
            existingStatus.setName(clientStatus.getName());
            existingStatus.setStatus(clientStatus.getStatus());
            existingStatus.setAccountType(clientStatus.getAccountType());
            existingStatus.setRegion(clientStatus.getRegion());
            existingStatus.setServices(clientStatus.getServices());
            existingStatus.setUsage(clientStatus.getUsage());
            existingStatus.setLastActivity(LocalDateTime.now());
            return clientStatusRepository.save(existingStatus);
        }
        return null;
    }

    public boolean deleteClientStatus(String clientId) {
        Optional<ClientStatus> existing = clientStatusRepository.findByClientId(clientId);
        if (existing.isPresent()) {
            clientStatusRepository.delete(existing.get());
            return true;
        }
        return false;
    }

    public Map<String, Object> getClientUsage(String clientId) {
        Optional<ClientStatus> status = clientStatusRepository.findByClientId(clientId);
        if (status.isPresent()) {
            Map<String, Object> usage = new HashMap<>();
            usage.put("clientId", clientId);
            usage.put("usage", status.get().getUsage());
            usage.put("lastActivity", status.get().getLastActivity());
            return usage;
        }
        return null;
    }

    public Map<String, String> getClientServices(String clientId) {
        Optional<ClientStatus> status = clientStatusRepository.findByClientId(clientId);
        return status.map(ClientStatus::getServices).orElse(null);
    }

    private ClientStatus createMockClientStatus(String clientId) {
        ClientStatus mockStatus = new ClientStatus(clientId, "Acme Corporation", "Active", "Enterprise", "US-East");
        
        Map<String, String> services = new HashMap<>();
        services.put("Data Processing", "Active");
        services.put("API Gateway", "Active");
        services.put("Analytics", "Active");
        services.put("Reporting", "Maintenance");
        mockStatus.setServices(services);
        
        Map<String, String> usage = new HashMap<>();
        usage.put("apiCalls", "15420");
        usage.put("dataTransfer", "2.3 GB");
        usage.put("storageUsed", "45.7 GB");
        mockStatus.setUsage(usage);
        
        return mockStatus;
    }
}