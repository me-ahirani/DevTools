package com.jpmc.h2h.tools.controller;

import com.jpmc.h2h.tools.model.PartnerStatus;
import com.jpmc.h2h.tools.service.PartnerStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/partner-status")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000"})
public class PartnerStatusController {

    @Autowired
    private PartnerStatusService partnerStatusService;

    @GetMapping("/{partnerId}")
    public ResponseEntity<PartnerStatus> getPartnerStatus(@PathVariable String partnerId) {
        PartnerStatus status = partnerStatusService.getPartnerStatus(partnerId);
        if (status != null) {
            return ResponseEntity.ok(status);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<PartnerStatus>> getAllPartnerStatuses() {
        List<PartnerStatus> statuses = partnerStatusService.getAllPartnerStatuses();
        return ResponseEntity.ok(statuses);
    }

    @PostMapping
    public ResponseEntity<PartnerStatus> createPartnerStatus(@RequestBody PartnerStatus partnerStatus) {
        PartnerStatus created = partnerStatusService.createPartnerStatus(partnerStatus);
        return ResponseEntity.ok(created);
    }

    @PutMapping("/{partnerId}")
    public ResponseEntity<PartnerStatus> updatePartnerStatus(
            @PathVariable String partnerId,
            @RequestBody PartnerStatus partnerStatus) {
        PartnerStatus updated = partnerStatusService.updatePartnerStatus(partnerId, partnerStatus);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{partnerId}")
    public ResponseEntity<Void> deletePartnerStatus(@PathVariable String partnerId) {
        boolean deleted = partnerStatusService.deletePartnerStatus(partnerId);
        if (deleted) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{partnerId}/sync")
    public ResponseEntity<PartnerStatus> syncPartnerStatus(@PathVariable String partnerId) {
        PartnerStatus synced = partnerStatusService.syncPartnerStatus(partnerId);
        if (synced != null) {
            return ResponseEntity.ok(synced);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{partnerId}/health")
    public ResponseEntity<Map<String, Object>> getPartnerHealth(@PathVariable String partnerId) {
        Map<String, Object> health = partnerStatusService.getPartnerHealth(partnerId);
        if (health != null) {
            return ResponseEntity.ok(health);
        }
        return ResponseEntity.notFound().build();
    }
}