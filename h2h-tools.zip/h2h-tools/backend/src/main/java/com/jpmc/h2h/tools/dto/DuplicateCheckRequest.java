package com.jpmc.h2h.tools.dto;

public class DuplicateCheckRequest {
    private String data;
    private String checkType;

    public DuplicateCheckRequest() {}

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getCheckType() { return checkType; }
    public void setCheckType(String checkType) { this.checkType = checkType; }
}