package com.jpmc.h2h.tools.dto;

import java.util.List;
import java.util.Map;

public class EnvironmentComparisonResponse {
    private List<ComparisonResult> results;
    private String env1Name;
    private String env2Name;
    private Map<String, Integer> summary;

    public EnvironmentComparisonResponse() {}

    public List<ComparisonResult> getResults() { return results; }
    public void setResults(List<ComparisonResult> results) { this.results = results; }

    public String getEnv1Name() { return env1Name; }
    public void setEnv1Name(String env1Name) { this.env1Name = env1Name; }

    public String getEnv2Name() { return env2Name; }
    public void setEnv2Name(String env2Name) { this.env2Name = env2Name; }

    public Map<String, Integer> getSummary() { return summary; }
    public void setSummary(Map<String, Integer> summary) { this.summary = summary; }
}