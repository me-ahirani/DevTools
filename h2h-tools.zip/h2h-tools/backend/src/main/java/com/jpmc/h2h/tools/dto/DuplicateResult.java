package com.jpmc.h2h.tools.dto;

import java.util.List;
import java.util.Map;

public class DuplicateResult {
    private String field;
    private String value;
    private int count;
    private List<Map<String, String>> records;

    public DuplicateResult() {}

    public String getField() { return field; }
    public void setField(String field) { this.field = field; }

    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }

    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }

    public List<Map<String, String>> getRecords() { return records; }
    public void setRecords(List<Map<String, String>> records) { this.records = records; }
}