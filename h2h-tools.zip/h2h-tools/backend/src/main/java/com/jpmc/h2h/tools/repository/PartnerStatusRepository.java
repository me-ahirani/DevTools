package com.jpmc.h2h.tools.repository;

import com.jpmc.h2h.tools.model.PartnerStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PartnerStatusRepository extends JpaRepository<PartnerStatus, Long> {
    Optional<PartnerStatus> findByPartnerId(String partnerId);
}