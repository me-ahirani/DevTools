package com.jpmc.h2h.tools.dto;

public class EnvironmentComparisonRequest {
    private String env1Name;
    private String env2Name;
    private String env1Data;
    private String env2Data;

    public EnvironmentComparisonRequest() {}

    public String getEnv1Name() { return env1Name; }
    public void setEnv1Name(String env1Name) { this.env1Name = env1Name; }

    public String getEnv2Name() { return env2Name; }
    public void setEnv2Name(String env2Name) { this.env2Name = env2Name; }

    public String getEnv1Data() { return env1Data; }
    public void setEnv1Data(String env1Data) { this.env1Data = env1Data; }

    public String getEnv2Data() { return env2Data; }
    public void setEnv2Data(String env2Data) { this.env2Data = env2Data; }
}