package com.jpmc.h2h.tools.dto;

import java.util.List;

public class DuplicateCheckResponse {
    private List<DuplicateResult> duplicates;
    private int totalDuplicates;
    private String checkType;

    public DuplicateCheckResponse() {}

    public List<DuplicateResult> getDuplicates() { return duplicates; }
    public void setDuplicates(List<DuplicateResult> duplicates) { this.duplicates = duplicates; }

    public int getTotalDuplicates() { return totalDuplicates; }
    public void setTotalDuplicates(int totalDuplicates) { this.totalDuplicates = totalDuplicates; }

    public String getCheckType() { return checkType; }
    public void setCheckType(String checkType) { this.checkType = checkType; }
}