package com.jpmc.h2h.tools.dto;

import java.util.List;

public class JsonGeneratorRequest {
    private List<JsonField> fields;
    private int recordCount;

    public JsonGeneratorRequest() {}

    public List<JsonField> getFields() { return fields; }
    public void setFields(List<JsonField> fields) { this.fields = fields; }

    public int getRecordCount() { return recordCount; }
    public void setRecordCount(int recordCount) { this.recordCount = recordCount; }
}