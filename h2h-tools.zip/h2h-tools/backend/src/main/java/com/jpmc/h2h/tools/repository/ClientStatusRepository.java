package com.jpmc.h2h.tools.repository;

import com.jpmc.h2h.tools.model.ClientStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClientStatusRepository extends JpaRepository<ClientStatus, Long> {
    Optional<ClientStatus> findByClientId(String clientId);
}