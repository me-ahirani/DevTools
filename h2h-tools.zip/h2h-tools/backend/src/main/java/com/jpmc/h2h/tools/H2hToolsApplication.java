package com.jpmc.h2h.tools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2hToolsApplication {
    public static void main(String[] args) {
        SpringApplication.run(H2hToolsApplication.class, args);
    }
}