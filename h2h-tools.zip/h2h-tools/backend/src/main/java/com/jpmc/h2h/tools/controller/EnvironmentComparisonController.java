package com.jpmc.h2h.tools.controller;

import com.jpmc.h2h.tools.dto.EnvironmentComparisonRequest;
import com.jpmc.h2h.tools.dto.EnvironmentComparisonResponse;
import com.jpmc.h2h.tools.service.EnvironmentComparisonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/environment-comparison")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000"})
public class EnvironmentComparisonController {

    @Autowired
    private EnvironmentComparisonService environmentComparisonService;

    @PostMapping
    public ResponseEntity<EnvironmentComparisonResponse> compareEnvironments(
            @RequestBody EnvironmentComparisonRequest request) {
        EnvironmentComparisonResponse response = environmentComparisonService.compareEnvironments(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/config")
    public ResponseEntity<EnvironmentComparisonResponse> compareConfigurations(
            @RequestBody EnvironmentComparisonRequest request) {
        EnvironmentComparisonResponse response = environmentComparisonService.compareConfigurations(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/properties")
    public ResponseEntity<EnvironmentComparisonResponse> compareProperties(
            @RequestBody EnvironmentComparisonRequest request) {
        EnvironmentComparisonResponse response = environmentComparisonService.compareProperties(request);
        return ResponseEntity.ok(response);
    }
}