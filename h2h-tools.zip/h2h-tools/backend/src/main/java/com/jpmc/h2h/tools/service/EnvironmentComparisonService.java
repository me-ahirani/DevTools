package com.jpmc.h2h.tools.service;

import com.jpmc.h2h.tools.dto.EnvironmentComparisonRequest;
import com.jpmc.h2h.tools.dto.EnvironmentComparisonResponse;
import com.jpmc.h2h.tools.dto.ComparisonResult;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class EnvironmentComparisonService {

    public EnvironmentComparisonResponse compareEnvironments(EnvironmentComparisonRequest request) {
        Map<String, String> env1Config = parseEnvironmentData(request.getEnv1Data());
        Map<String, String> env2Config = parseEnvironmentData(request.getEnv2Data());

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(env1Config.keySet());
        allKeys.addAll(env2Config.keySet());

        List<ComparisonResult> results = allKeys.stream()
                .map(key -> createComparisonResult(key, env1Config, env2Config))
                .sorted(Comparator.comparing(ComparisonResult::getKey))
                .collect(Collectors.toList());

        EnvironmentComparisonResponse response = new EnvironmentComparisonResponse();
        response.setResults(results);
        response.setEnv1Name(request.getEnv1Name());
        response.setEnv2Name(request.getEnv2Name());
        response.setSummary(createSummary(results));

        return response;
    }

    public EnvironmentComparisonResponse compareConfigurations(EnvironmentComparisonRequest request) {
        return compareEnvironments(request);
    }

    public EnvironmentComparisonResponse compareProperties(EnvironmentComparisonRequest request) {
        return compareEnvironments(request);
    }

    private Map<String, String> parseEnvironmentData(String data) {
        Map<String, String> config = new HashMap<>();
        String[] lines = data.split("\n");

        for (String line : lines) {
            line = line.trim();
            if (!line.isEmpty() && !line.startsWith("#")) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    config.put(parts[0].trim(), parts[1].trim());
                }
            }
        }

        return config;
    }

    private ComparisonResult createComparisonResult(String key, Map<String, String> env1, Map<String, String> env2) {
        ComparisonResult result = new ComparisonResult();
        result.setKey(key);
        
        String env1Value = env1.getOrDefault(key, "(not set)");
        String env2Value = env2.getOrDefault(key, "(not set)");
        
        result.setEnv1Value(env1Value);
        result.setEnv2Value(env2Value);

        if (env1Value.equals("(not set)") || env2Value.equals("(not set)")) {
            result.setStatus("missing");
        } else if (env1Value.equals(env2Value)) {
            result.setStatus("match");
        } else {
            result.setStatus("different");
        }

        return result;
    }

    private Map<String, Integer> createSummary(List<ComparisonResult> results) {
        Map<String, Integer> summary = new HashMap<>();
        summary.put("match", 0);
        summary.put("different", 0);
        summary.put("missing", 0);

        for (ComparisonResult result : results) {
            summary.put(result.getStatus(), summary.get(result.getStatus()) + 1);
        }

        return summary;
    }
}