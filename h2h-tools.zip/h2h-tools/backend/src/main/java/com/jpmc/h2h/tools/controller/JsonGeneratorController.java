package com.jpmc.h2h.tools.controller;

import com.jpmc.h2h.tools.dto.JsonGeneratorRequest;
import com.jpmc.h2h.tools.service.JsonGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/json-generator")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:3000"})
public class JsonGeneratorController {

    @Autowired
    private JsonGeneratorService jsonGeneratorService;

    @PostMapping
    public ResponseEntity<List<Map<String, Object>>> generateJson(@RequestBody JsonGeneratorRequest request) {
        List<Map<String, Object>> response = jsonGeneratorService.generateJson(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/mock-data")
    public ResponseEntity<List<Map<String, Object>>> generateMockData(@RequestBody JsonGeneratorRequest request) {
        List<Map<String, Object>> response = jsonGeneratorService.generateMockData(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/template")
    public ResponseEntity<Map<String, Object>> generateFromTemplate(@RequestBody JsonGeneratorRequest request) {
        Map<String, Object> response = jsonGeneratorService.generateFromTemplate(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/templates")
    public ResponseEntity<List<Map<String, Object>>> getAvailableTemplates() {
        List<Map<String, Object>> templates = jsonGeneratorService.getAvailableTemplates();
        return ResponseEntity.ok(templates);
    }
}