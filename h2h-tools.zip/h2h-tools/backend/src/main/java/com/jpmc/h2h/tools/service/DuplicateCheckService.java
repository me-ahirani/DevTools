package com.jpmc.h2h.tools.service;

import com.jpmc.h2h.tools.dto.DuplicateCheckRequest;
import com.jpmc.h2h.tools.dto.DuplicateCheckResponse;
import com.jpmc.h2h.tools.dto.DuplicateResult;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DuplicateCheckService {

    public DuplicateCheckResponse checkDuplicates(DuplicateCheckRequest request) {
        List<String> data = Arrays.asList(request.getData().split("\n"))
                .stream()
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());

        Map<String, Long> counts = data.stream()
                .collect(Collectors.groupingBy(s -> s, Collectors.counting()));

        List<DuplicateResult> duplicates = counts.entrySet().stream()
                .filter(entry -> entry.getValue() > 1)
                .map(entry -> createDuplicateResult(entry.getKey(), entry.getValue().intValue(), request.getCheckType()))
                .collect(Collectors.toList());

        DuplicateCheckResponse response = new DuplicateCheckResponse();
        response.setDuplicates(duplicates);
        response.setTotalDuplicates(duplicates.size());
        response.setCheckType(request.getCheckType());
        
        return response;
    }

    public DuplicateCheckResponse checkEmailDuplicates(DuplicateCheckRequest request) {
        request.setCheckType("email");
        return checkDuplicates(request);
    }

    public DuplicateCheckResponse checkPhoneDuplicates(DuplicateCheckRequest request) {
        request.setCheckType("phone");
        return checkDuplicates(request);
    }

    public DuplicateCheckResponse checkIdDuplicates(DuplicateCheckRequest request) {
        request.setCheckType("id");
        return checkDuplicates(request);
    }

    private DuplicateResult createDuplicateResult(String value, int count, String checkType) {
        DuplicateResult result = new DuplicateResult();
        result.setField(checkType);
        result.setValue(value);
        result.setCount(count);
        
        List<Map<String, String>> records = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Map<String, String> record = new HashMap<>();
            record.put("id", "REC-" + UUID.randomUUID().toString().substring(0, 8));
            record.put("source", i == 0 ? "Primary Database" : "Import Batch " + i);
            record.put("lastUpdated", "2024-01-" + (10 + i));
            records.add(record);
        }
        result.setRecords(records);
        
        return result;
    }
}