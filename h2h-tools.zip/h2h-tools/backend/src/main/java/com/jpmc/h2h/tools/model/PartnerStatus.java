package com.jpmc.h2h.tools.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Map;

@Entity
@Table(name = "partner_status")
public class PartnerStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String partnerId;
    
    private String status;
    private LocalDateTime lastSync;
    private String connectionHealth;
    private String apiVersion;
    
    @ElementCollection
    @CollectionTable(name = "partner_endpoints", joinColumns = @JoinColumn(name = "partner_id"))
    @MapKeyColumn(name = "endpoint_name")
    @Column(name = "endpoint_status")
    private Map<String, String> endpoints;
    
    @ElementCollection
    @CollectionTable(name = "partner_metrics", joinColumns = @JoinColumn(name = "partner_id"))
    @MapKeyColumn(name = "metric_name")
    @Column(name = "metric_value")
    private Map<String, String> metrics;

    // Constructors
    public PartnerStatus() {}

    public PartnerStatus(String partnerId, String status, String connectionHealth, String apiVersion) {
        this.partnerId = partnerId;
        this.status = status;
        this.connectionHealth = connectionHealth;
        this.apiVersion = apiVersion;
        this.lastSync = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPartnerId() { return partnerId; }
    public void setPartnerId(String partnerId) { this.partnerId = partnerId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getLastSync() { return lastSync; }
    public void setLastSync(LocalDateTime lastSync) { this.lastSync = lastSync; }

    public String getConnectionHealth() { return connectionHealth; }
    public void setConnectionHealth(String connectionHealth) { this.connectionHealth = connectionHealth; }

    public String getApiVersion() { return apiVersion; }
    public void setApiVersion(String apiVersion) { this.apiVersion = apiVersion; }

    public Map<String, String> getEndpoints() { return endpoints; }
    public void setEndpoints(Map<String, String> endpoints) { this.endpoints = endpoints; }

    public Map<String, String> getMetrics() { return metrics; }
    public void setMetrics(Map<String, String> metrics) { this.metrics = metrics; }
}