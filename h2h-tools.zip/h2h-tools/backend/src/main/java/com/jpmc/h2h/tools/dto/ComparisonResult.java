package com.jpmc.h2h.tools.dto;

public class ComparisonResult {
    private String key;
    private String env1Value;
    private String env2Value;
    private String status;

    public ComparisonResult() {}

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public String getEnv1Value() { return env1Value; }
    public void setEnv1Value(String env1Value) { this.env1Value = env1Value; }

    public String getEnv2Value() { return env2Value; }
    public void setEnv2Value(String env2Value) { this.env2Value = env2Value; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}