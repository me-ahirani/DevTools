# WPI H2H Tools

A comprehensive suite of tools for partner and client management, data validation, and environment comparison.

## Project Structure

```
wpi_tools/
├── frontend/          # React frontend application
├── backend/           # Spring Boot REST API
└── README.md
```

## Components

### Frontend (React + TypeScript)
- Modern React application with TypeScript
- Tailwind CSS for styling
- Vite for fast development
- Five main tool components

### Backend (Spring Boot)
- REST API with comprehensive endpoints
- JPA entities for data persistence
- H2 database for development
- CORS configuration for frontend integration

## Tools Available

1. **Partner Status Checker** - Monitor partner API connections, health metrics, and endpoint status
2. **Client Status Checker** - View client account information, service status, and usage statistics
3. **Duplicate Data Checker** - Find and analyze duplicate entries in datasets
4. **Environment Comparison** - Compare configuration files between different environments
5. **JSON Data Generator** - Create mock JSON data with customizable fields and templates

## Quick Start

### Backend
```bash
cd wpi_tools/backend
./mvnw spring-boot:run
```
API available at: `http://localhost:8080`

### Frontend
```bash
cd wpi_tools/frontend
npm install
npm run dev
```
Application available at: `http://localhost:5173`

## API Integration

The frontend can be configured to use the backend API by updating the API endpoints in the React components to point to `http://localhost:8080/api/`.

## Development

- Backend: Java 17, Spring Boot 3.2.0, Maven
- Frontend: Node.js, React 18, TypeScript, Vite
- Database: H2 (development), configurable for production
- Styling: Tailwind CSS