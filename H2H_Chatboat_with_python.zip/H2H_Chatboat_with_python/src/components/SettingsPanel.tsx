import React, { useState } from 'react';
import { 
  X, 
  Save, 
  ExternalLink, 
  Key, 
  Globe, 
  Shield, 
  AlertCircle,
  CheckCircle,
  Settings
} from 'lucide-react';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ConfigSettings {
  confluenceUrl: string;
  confluenceToken: string;
  jiraUrl: string;
  jiraToken: string;
  searchScope: string;
  maxResults: number;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<ConfigSettings>({
    confluenceUrl: 'https://company.atlassian.net/wiki',
    confluenceToken: '',
    jiraUrl: 'https://company.atlassian.net',
    jiraToken: '',
    searchScope: 'all',
    maxResults: 10
  });

  const [activeTab, setActiveTab] = useState('confluence');
  const [testResults, setTestResults] = useState<{
    confluence: 'idle' | 'testing' | 'success' | 'error';
    jira: 'idle' | 'testing' | 'success' | 'error';
  }>({
    confluence: 'idle',
    jira: 'idle'
  });

  const handleSave = () => {
    // In a real implementation, this would save to backend/localStorage
    console.log('Saving settings:', settings);
    onClose();
  };

  const testConnection = async (service: 'confluence' | 'jira') => {
    setTestResults(prev => ({ ...prev, [service]: 'testing' }));
    
    try {
      const response = await fetch('http://localhost:5000/api/test-connections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          confluenceUrl: settings.confluenceUrl,
          confluenceToken: settings.confluenceToken,
          jiraUrl: settings.jiraUrl,
          jiraToken: settings.jiraToken
        }),
      });

      const data = await response.json();
      const success = data[service]?.status === 'success';
      
      setTestResults(prev => ({ 
        ...prev, 
        [service]: success ? 'success' : 'error' 
      }));
    } catch (error) {
      console.error(`Error testing ${service} connection:`, error);
      setTestResults(prev => ({ 
        ...prev, 
        [service]: 'error' 
      }));
    }
  };

  const getConnectionStatus = (status: string) => {
    switch (status) {
      case 'testing':
        return { icon: <AlertCircle className="w-4 h-4 animate-pulse text-yellow-400" />, text: 'Testing...' };
      case 'success':
        return { icon: <CheckCircle className="w-4 h-4 text-green-400" />, text: 'Connected' };
      case 'error':
        return { icon: <AlertCircle className="w-4 h-4 text-red-400" />, text: 'Failed' };
      default:
        return { icon: <Globe className="w-4 h-4 text-slate-400" />, text: 'Not tested' };
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-white">H2H Configuration</h2>
              <p className="text-sm text-slate-400">Configure your Confluence and Jira connections</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-700">
          {['confluence', 'jira', 'general'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 px-6 py-3 text-sm font-medium capitalize transition-colors duration-200 ${
                activeTab === tab
                  ? 'text-blue-400 border-b-2 border-blue-400 bg-slate-700/50'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700/30'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {activeTab === 'confluence' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Confluence URL
                </label>
                <div className="relative">
                  <input
                    type="url"
                    value={settings.confluenceUrl}
                    onChange={(e) => setSettings(prev => ({ ...prev, confluenceUrl: e.target.value }))}
                    placeholder="https://yourcompany.atlassian.net/wiki"
                    className="w-full px-4 py-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  API Token
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={settings.confluenceToken}
                    onChange={(e) => setSettings(prev => ({ ...prev, confluenceToken: e.target.value }))}
                    placeholder="Enter your Confluence API token"
                    className="w-full px-4 py-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  <a 
                    href="https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:text-blue-300 flex items-center space-x-1"
                  >
                    <span>How to create an API token</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </p>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <div className="flex items-center space-x-2">
                  {getConnectionStatus(testResults.confluence).icon}
                  <span className="text-sm text-white">
                    Connection Status: {getConnectionStatus(testResults.confluence).text}
                  </span>
                </div>
                <button
                  onClick={() => testConnection('confluence')}
                  disabled={testResults.confluence === 'testing'}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white text-sm rounded-lg transition-colors duration-200"
                >
                  Test Connection
                </button>
              </div>
            </div>
          )}

          {activeTab === 'jira' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Jira URL
                </label>
                <div className="relative">
                  <input
                    type="url"
                    value={settings.jiraUrl}
                    onChange={(e) => setSettings(prev => ({ ...prev, jiraUrl: e.target.value }))}
                    placeholder="https://yourcompany.atlassian.net"
                    className="w-full px-4 py-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  API Token
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={settings.jiraToken}
                    onChange={(e) => setSettings(prev => ({ ...prev, jiraToken: e.target.value }))}
                    placeholder="Enter your Jira API token"
                    className="w-full px-4 py-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <div className="flex items-center space-x-2">
                  {getConnectionStatus(testResults.jira).icon}
                  <span className="text-sm text-white">
                    Connection Status: {getConnectionStatus(testResults.jira).text}
                  </span>
                </div>
                <button
                  onClick={() => testConnection('jira')}
                  disabled={testResults.jira === 'testing'}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white text-sm rounded-lg transition-colors duration-200"
                >
                  Test Connection
                </button>
              </div>
            </div>
          )}

          {activeTab === 'general' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Search Scope
                </label>
                <select
                  value={settings.searchScope}
                  onChange={(e) => setSettings(prev => ({ ...prev, searchScope: e.target.value }))}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Spaces/Projects</option>
                  <option value="recent">Recently Accessed</option>
                  <option value="favorites">Favorites Only</option>
                  <option value="custom">Custom Selection</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Maximum Search Results
                </label>
                <input
                  type="number"
                  min="5"
                  max="50"
                  value={settings.maxResults}
                  onChange={(e) => setSettings(prev => ({ ...prev, maxResults: parseInt(e.target.value) }))}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Number of results to display per search (5-50)
                </p>
              </div>

              <div className="p-4 bg-blue-600/10 border border-blue-600/20 rounded-lg">
                <div className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-blue-400 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-white mb-1">Security Notice</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Your API tokens are stored securely and encrypted. They are only used to authenticate 
                      requests to your configured Confluence and Jira instances. We recommend using tokens 
                      with minimal required permissions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-slate-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-slate-400 hover:text-white transition-colors duration-200"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center space-x-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200"
          >
            <Save className="w-4 h-4" />
            <span>Save Changes</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;