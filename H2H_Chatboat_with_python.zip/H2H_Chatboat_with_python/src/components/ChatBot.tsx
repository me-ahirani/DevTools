import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  MessageCircle, 
  Loader2, 
  ExternalLink, 
  Search,
  FileText,
  AlertCircle
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  sources?: Array<{
    title: string;
    url: string;
    type: 'confluence' | 'jira';
    snippet: string;
  }>;
}

interface ChatBotProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChatBot: React.FC<ChatBotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your H2H AI assistant. I can help you search for information in Confluence and Jira. What would you like to know?',
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Call the backend API
      const response = await fetch('http://localhost:5000/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: inputValue }),
      });

      const data = await response.json();

      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: data.success ? data.answer : 'Sorry, I encountered an error processing your request.',
        sender: 'bot',
        timestamp: new Date(),
        sources: data.success ? data.sources : []
      };

      setMessages(prev => [...prev, botResponse]);
    } catch (error) {
      console.error('Error calling backend:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: 'Sorry, I\'m having trouble connecting to the knowledge base. Please make sure the backend server is running.',
        sender: 'bot',
        timestamp: new Date(),
        sources: []
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateBotResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('api') || lowerQuery.includes('endpoint')) {
      return 'I found several API-related documents in your Confluence space. The main API documentation covers REST endpoints, authentication methods, and rate limiting. There are also related Jira tickets discussing API improvements and bug fixes.';
    } else if (lowerQuery.includes('deployment') || lowerQuery.includes('deploy')) {
      return 'Here\'s what I found about deployment processes: Your Confluence has detailed deployment guides for staging and production environments. There are also several Jira tickets tracking deployment issues and improvements to the CI/CD pipeline.';
    } else if (lowerQuery.includes('bug') || lowerQuery.includes('issue')) {
      return 'I\'ve located relevant bug reports and issues in Jira. The most recent tickets show resolved issues with the authentication system and ongoing work on performance optimization. Related Confluence pages document troubleshooting procedures.';
    } else {
      return `I searched through your configured Confluence and Jira instances for information related to "${query}". I found several relevant documents and tickets that might help you. Please check the sources below for detailed information.`;
    }
  };

  const generateMockSources = (query: string) => {
    return [
      {
        title: `${query} - Technical Documentation`,
        url: 'https://confluence.company.com/display/DOCS/api-guide',
        type: 'confluence' as const,
        snippet: 'This document covers the implementation details and best practices for...'
      },
      {
        title: `[TICKET-123] ${query} Implementation`,
        url: 'https://jira.company.com/browse/TICKET-123',
        type: 'jira' as const,
        snippet: 'Status: In Progress - Working on implementing the requested feature...'
      },
      {
        title: `${query} Troubleshooting Guide`,
        url: 'https://confluence.company.com/display/HELP/troubleshooting',
        type: 'confluence' as const,
        snippet: 'Common issues and their solutions related to this topic...'
      }
    ];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-t-2xl shadow-2xl w-full max-w-md h-[600px] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-600 rounded-lg">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Ask H2H</h3>
              <p className="text-sm text-slate-400">AI Assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(message => (
            <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] ${message.sender === 'user' ? 'bg-blue-600' : 'bg-slate-700'} rounded-2xl p-3`}>
                <p className="text-white text-sm leading-relaxed">{message.content}</p>
                
                {message.sources && (
                  <div className="mt-3 space-y-2">
                    <p className="text-xs text-slate-300 font-medium">Sources:</p>
                    {message.sources.map((source, index) => (
                      <div key={index} className="bg-slate-600/50 rounded-lg p-2 text-xs">
                        <div className="flex items-center space-x-2 mb-1">
                          {source.type === 'confluence' ? (
                            <FileText className="w-3 h-3 text-blue-400" />
                          ) : (
                            <AlertCircle className="w-3 h-3 text-orange-400" />
                          )}
                          <span className="text-slate-300 font-medium capitalize">{source.type}</span>
                        </div>
                        <a
                          href={source.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300 font-medium flex items-center space-x-1"
                        >
                          <span>{source.title}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                        <p className="text-slate-400 mt-1">{source.snippet}</p>
                      </div>
                    ))}
                  </div>
                )}
                
                <p className="text-xs text-slate-400 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-700 rounded-2xl p-3 flex items-center space-x-2">
                <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                <span className="text-white text-sm">Searching...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about Confluence docs or Jira tickets..."
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={isLoading}
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors duration-200"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Press Enter to send, Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatBot;