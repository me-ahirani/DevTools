import React, { useState } from 'react';
import { 
  Search, 
  Settings, 
  MessageCircle, 
  Code, 
  Database, 
  GitBranch, 
  Bug, 
  FileText, 
  Users, 
  BarChart3,
  Zap,
  Shield,
  Cloud,
  Wrench,
  X,
  Send,
  ExternalLink,
  ChevronRight,
  CreditCard,
  FileSpreadsheet,
  Network
} from 'lucide-react';
import ChatBot from './ChatBot';
import SettingsPanel from './SettingsPanel';

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  url: string;
  status: 'active' | 'beta' | 'maintenance';
}

const Dashboard: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const tools: Tool[] = [
    {
      id: 'wpi-dev-tool',
      name: 'WPI Dev Tool',
      description: 'Comprehensive development toolkit for WPI (Web Payment Interface) integration and testing.',
      icon: <CreditCard className="w-6 h-6" />,
      category: 'Development',
      url: '#',
      status: 'active'
    },
    {
      id: 'payment-files-analyser',
      name: 'Payment Files Analyser',
      description: 'Advanced analysis tool for payment transaction files, fraud detection, and compliance reporting.',
      icon: <FileSpreadsheet className="w-6 h-6" />,
      category: 'Analytics',
      url: '#',
      status: 'active'
    },
    {
      id: 'h2h-dev-tools',
      name: 'H2H Dev Tools',
      description: 'Specialized development tools for Host-to-Host communication protocols and API testing.',
      icon: <Network className="w-6 h-6" />,
      category: 'Development',
      url: '#',
      status: 'active'
    },
    {
      id: 'code-gen',
      name: 'Code Generator',
      description: 'Generate high-quality code snippets and templates using AI-powered assistance.',
      icon: <Code className="w-6 h-6" />,
      category: 'Development',
      url: '#',
      status: 'active'
    },
    {
      id: 'data-analyzer',
      name: 'Data Analyzer',
      description: 'Analyze complex datasets and generate insights with machine learning algorithms.',
      icon: <Database className="w-6 h-6" />,
      category: 'Analytics',
      url: '#',
      status: 'active'
    },
    {
      id: 'git-assistant',
      name: 'Git Assistant',
      description: 'Intelligent Git workflow management and conflict resolution assistance.',
      icon: <GitBranch className="w-6 h-6" />,
      category: 'Development',
      url: '#',
      status: 'beta'
    },
    {
      id: 'bug-tracker',
      name: 'Bug Tracker Pro',
      description: 'Advanced bug detection and tracking with AI-powered root cause analysis.',
      icon: <Bug className="w-6 h-6" />,
      category: 'Testing',
      url: '#',
      status: 'active'
    },
    {
      id: 'doc-generator',
      name: 'Documentation Generator',
      description: 'Automatically generate comprehensive documentation from your codebase.',
      icon: <FileText className="w-6 h-6" />,
      category: 'Documentation',
      url: '#',
      status: 'active'
    },
    {
      id: 'team-insights',
      name: 'Team Insights',
      description: 'Get detailed analytics on team performance and collaboration patterns.',
      icon: <Users className="w-6 h-6" />,
      category: 'Analytics',
      url: '#',
      status: 'active'
    },
    {
      id: 'performance-monitor',
      name: 'Performance Monitor',
      description: 'Real-time application performance monitoring and optimization suggestions.',
      icon: <BarChart3 className="w-6 h-6" />,
      category: 'Monitoring',
      url: '#',
      status: 'beta'
    },
    {
      id: 'ai-optimizer',
      name: 'AI Code Optimizer',
      description: 'Optimize your code for better performance and maintainability using AI.',
      icon: <Zap className="w-6 h-6" />,
      category: 'Development',
      url: '#',
      status: 'active'
    },
    {
      id: 'security-scanner',
      name: 'Security Scanner',
      description: 'Comprehensive security vulnerability scanning and remediation guidance.',
      icon: <Shield className="w-6 h-6" />,
      category: 'Security',
      url: '#',
      status: 'active'
    },
    {
      id: 'cloud-manager',
      name: 'Cloud Manager',
      description: 'Intelligent cloud resource management and cost optimization.',
      icon: <Cloud className="w-6 h-6" />,
      category: 'Infrastructure',
      url: '#',
      status: 'maintenance'
    }
  ];

  const categories = ['All', ...Array.from(new Set(tools.map(tool => tool.category)))];

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'beta': return 'bg-yellow-500';
      case 'maintenance': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'beta': return 'Beta';
      case 'maintenance': return 'Maintenance';
      default: return 'Unknown';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Wrench className="w-8 h-8 text-blue-400" />
                <h1 className="text-2xl font-bold text-white">H2H AI Dashboard</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsChatOpen(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Ask H2H</span>
              </button>
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors duration-200"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Host-to-Host AI Intelligence Platform
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Discover and access powerful AI tools to accelerate your development workflow. 
            Get instant help through our intelligent assistant.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search tools and services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTools.map(tool => (
            <div
              key={tool.id}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-blue-500/50 hover:bg-slate-800/70 transition-all duration-300 group cursor-pointer"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-600/20 rounded-lg text-blue-400 group-hover:bg-blue-600/30 transition-colors duration-200">
                    {tool.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{tool.name}</h3>
                    <span className="text-sm text-slate-400">{tool.category}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(tool.status)}`}></div>
                  <span className="text-xs text-slate-400">{getStatusText(tool.status)}</span>
                </div>
              </div>
              
              <p className="text-slate-300 text-sm mb-4 leading-relaxed">
                {tool.description}
              </p>
              
              <div className="flex items-center justify-between">
                <button className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 font-medium text-sm transition-colors duration-200">
                  <span>Launch Tool</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors duration-200" />
              </div>
            </div>
          ))}
        </div>

        {filteredTools.length === 0 && (
          <div className="text-center py-12">
            <div className="text-slate-400 mb-4">
              <Search className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No tools found</h3>
            <p className="text-slate-400">Try adjusting your search or filter criteria.</p>
          </div>
        )}
      </main>

      {/* Chat Bot */}
      <ChatBot isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      {/* Settings Panel */}
      <SettingsPanel isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
};

export default Dashboard;