# H2H Backend - Host-to-Host AI Intelligence System

This backend system provides AI-powered search and question-answering capabilities by learning from Confluence and Jira content.

## Features

- **Confluence Integration**: Connects to Confluence spaces and learns from configured pages
- **Jira Integration**: Connects to Jira projects and learns from issues and comments
- **AI-Powered Search**: Uses sentence transformers for semantic search and similarity matching
- **Knowledge Base**: Builds and maintains a local knowledge base with vector embeddings
- **RESTful API**: Provides endpoints for chat, search, and configuration management
- **Real-time Learning**: Can update knowledge base with new content

## Setup

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment

Copy `.env.example` to `.env` and update with your credentials:

```bash
cp .env.example .env
```

Edit `.env` with your Confluence and Jira details:

```env
# Confluence Configuration
CONFLUENCE_URL=https://yourcompany.atlassian.net/wiki
CONFLUENCE_USERNAME=your-email@company.com
CONFLUENCE_API_TOKEN=your-confluence-api-token

# Jira Configuration
JIRA_URL=https://yourcompany.atlassian.net
JIRA_USERNAME=your-email@company.com
JIRA_API_TOKEN=your-jira-api-token
```

### 3. Generate API Tokens

#### Confluence/Jira API Token:
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a label and copy the token
4. Use your email as username and the token as password

### 4. Configure Learning Sources

Edit `config.py` to specify which pages and projects to learn from:

```python
CONFLUENCE_PAGES = [
    'H2H',  # Host-to-Host documentation
    'AFS',  # Application File System
    'Opstool',  # Operations Tool
    'WPI',  # Web Payment Interface
    # Add more page titles
]

JIRA_PROJECTS = [
    'H2H',  # Host-to-Host project
    'PAY',  # Payment project
    'OPS',  # Operations project
    # Add more project keys
]
```

## Running the System

### Option 1: Basic Run
```bash
python app.py
```

### Option 2: Run with Initial Learning
```bash
python run.py --learn
```

### Option 3: Using the Runner Script
```bash
python run.py
```

## API Endpoints

### Health Check
```
GET /api/health
```

### Test Connections
```
POST /api/test-connections
```

### Trigger Learning
```
POST /api/learn
```

### Chat (Ask Questions)
```
POST /api/chat
Content-Type: application/json

{
  "message": "What is AFS?"
}
```

### Search
```
POST /api/search
Content-Type: application/json

{
  "query": "payment processing"
}
```

### Knowledge Base Stats
```
GET /api/knowledge-stats
```

## How It Works

### 1. Learning Phase
- Connects to Confluence and retrieves configured pages
- Connects to Jira and retrieves issues from configured projects
- Processes and chunks the content for better retrieval
- Generates vector embeddings using sentence transformers
- Stores everything in a local knowledge base

### 2. Question Answering
- Receives user questions through the chat API
- Converts questions to vector embeddings
- Finds most similar content using cosine similarity
- Generates answers based on relevant content
- Returns answers with source citations

### 3. Live Search
- For low-confidence answers, performs live search
- Searches both Confluence and Jira in real-time
- Combines knowledge base results with live results

## Example Usage

### Learning from Configured Sources
The system will automatically learn from pages titled:
- "H2H" (Host-to-Host documentation)
- "AFS" (Application File System)
- "Opstool" (Operations Tool)
- "WPI" (Web Payment Interface)

### Sample Questions
- "What is AFS?"
- "How does H2H work?"
- "What are the Opstool features?"
- "WPI integration steps"
- "Payment processing workflow"

### Sample Response
```json
{
  "success": true,
  "answer": "AFS (Application File System) is a distributed file system that provides secure and scalable file storage for payment applications. It supports high-availability configurations and integrates with H2H protocols for seamless data exchange.",
  "sources": [
    {
      "title": "AFS Documentation",
      "url": "https://confluence.company.com/display/DOCS/AFS",
      "type": "confluence",
      "snippet": "AFS provides secure file storage...",
      "similarity": 0.85
    }
  ],
  "confidence": 0.85
}
```

## Architecture

```
├── connectors/
│   ├── confluence_connector.py  # Confluence API integration
│   └── jira_connector.py       # Jira API integration
├── knowledge_base/
│   └── knowledge_manager.py    # Vector database and search
├── services/
│   └── learning_service.py     # Main learning and QA logic
├── app.py                      # Flask API server
├── config.py                   # Configuration management
└── run.py                      # System runner
```

## Troubleshooting

### Connection Issues
- Verify API tokens are correct
- Check if URLs are accessible
- Ensure proper permissions on Confluence/Jira

### Learning Issues
- Check if configured pages/projects exist
- Verify page titles match exactly
- Look at logs for specific error messages

### Performance
- Adjust chunk sizes in `knowledge_manager.py`
- Modify similarity thresholds
- Limit the number of pages/issues to learn from

## Security Notes

- API tokens are stored in environment variables
- All connections use HTTPS
- Local knowledge base is stored securely
- No sensitive data is logged