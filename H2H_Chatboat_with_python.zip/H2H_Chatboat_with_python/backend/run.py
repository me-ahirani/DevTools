#!/usr/bin/env python3
"""
H2H Backend Runner
This script initializes and runs the H2H backend service
"""

import os
import sys
import logging
from app import app
from services.learning_service import LearningService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def initialize_system():
    """Initialize the H2H system"""
    try:
        logger.info("Initializing H2H Backend System...")
        
        # Create learning service instance
        learning_service = LearningService()
        
        # Check connections
        logger.info("Testing connections...")
        confluence_ok = learning_service.confluence_connector.test_connection()
        jira_ok = learning_service.jira_connector.test_connection()
        
        if confluence_ok:
            logger.info("✓ Confluence connection successful")
        else:
            logger.warning("✗ Confluence connection failed")
        
        if jira_ok:
            logger.info("✓ Jira connection successful")
        else:
            logger.warning("✗ Jira connection failed")
        
        # Optionally trigger initial learning
        if len(sys.argv) > 1 and sys.argv[1] == '--learn':
            logger.info("Triggering initial learning process...")
            results = learning_service.full_learning_cycle()
            logger.info(f"Learning completed: {results}")
        
        logger.info("H2H Backend System initialized successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize system: {str(e)}")
        return False

if __name__ == '__main__':
    # Initialize system
    if initialize_system():
        # Run the Flask app
        logger.info("Starting H2H Backend Server...")
        app.run(host='0.0.0.0', port=5000, debug=True)
    else:
        logger.error("System initialization failed. Exiting.")
        sys.exit(1)