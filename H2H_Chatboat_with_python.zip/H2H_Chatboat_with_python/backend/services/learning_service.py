import logging
from typing import List, Dict
from connectors.confluence_connector import ConfluenceConnector
from connectors.jira_connector import JiraConnector
from knowledge_base.knowledge_manager import KnowledgeManager
from config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LearningService:
    def __init__(self):
        self.confluence_connector = ConfluenceConnector()
        self.jira_connector = JiraConnector()
        self.knowledge_manager = KnowledgeManager()
    
    def learn_from_confluence(self) -> bool:
        """Learn from configured Confluence pages"""
        try:
            logger.info("Starting to learn from Confluence pages...")
            
            # Test connection first
            if not self.confluence_connector.test_connection():
                logger.error("Cannot connect to Confluence")
                return False
            
            # Get pages by configured titles
            pages = self.confluence_connector.get_pages_by_title(Config.CONFLUENCE_PAGES)
            
            logger.info(f"Found {len(pages)} Confluence pages to learn from")
            
            # Add each page to knowledge base
            for page in pages:
                self.knowledge_manager.add_document(page)
            
            return True
        except Exception as e:
            logger.error(f"Error learning from Confluence: {str(e)}")
            return False
    
    def learn_from_jira(self) -> bool:
        """Learn from configured Jira projects"""
        try:
            logger.info("Starting to learn from Jira projects...")
            
            # Test connection first
            if not self.jira_connector.test_connection():
                logger.error("Cannot connect to Jira")
                return False
            
            all_issues = []
            
            # Get issues from configured projects
            for project in Config.JIRA_PROJECTS:
                issues = self.jira_connector.get_project_issues(project, limit=20)
                all_issues.extend(issues)
            
            logger.info(f"Found {len(all_issues)} Jira issues to learn from")
            
            # Convert Jira issues to document format
            for issue in all_issues:
                document = {
                    'id': issue['key'],
                    'title': issue['title'],
                    'content': f"{issue['title']} {issue['description']} " + 
                              " ".join([comment['body'] for comment in issue.get('comments', [])]),
                    'type': 'jira',
                    'url': issue['url'],
                    'project': issue['project'],
                    'last_modified': issue['updated']
                }
                self.knowledge_manager.add_document(document)
            
            return True
        except Exception as e:
            logger.error(f"Error learning from Jira: {str(e)}")
            return False
    
    def full_learning_cycle(self) -> Dict:
        """Perform a complete learning cycle from both Confluence and Jira"""
        results = {
            'confluence_success': False,
            'jira_success': False,
            'total_documents': 0,
            'embeddings_built': False
        }
        
        try:
            # Clear existing knowledge base
            self.knowledge_manager.clear_knowledge_base()
            
            # Learn from Confluence
            results['confluence_success'] = self.learn_from_confluence()
            
            # Learn from Jira
            results['jira_success'] = self.learn_from_jira()
            
            # Build embeddings
            if results['confluence_success'] or results['jira_success']:
                self.knowledge_manager.build_embeddings()
                results['embeddings_built'] = True
                results['total_documents'] = len(self.knowledge_manager.documents)
                logger.info(f"Learning cycle completed. Total documents: {results['total_documents']}")
            
            return results
        except Exception as e:
            logger.error(f"Error in full learning cycle: {str(e)}")
            return results
    
    def search_and_answer(self, question: str) -> Dict:
        """Search knowledge base and provide an answer"""
        try:
            # First try to get answer from knowledge base
            kb_result = self.knowledge_manager.get_answer(question)
            
            # If knowledge base doesn't have good answer, search live
            if kb_result['confidence'] < 0.5:
                live_results = self.search_live(question)
                if live_results:
                    kb_result['sources'].extend(live_results)
            
            return kb_result
        except Exception as e:
            logger.error(f"Error in search and answer: {str(e)}")
            return {
                'answer': "An error occurred while processing your question.",
                'sources': [],
                'confidence': 0.0
            }
    
    def search_live(self, query: str) -> List[Dict]:
        """Search live in Confluence and Jira"""
        results = []
        
        try:
            # Search Confluence
            confluence_results = self.confluence_connector.search_pages(query, limit=3)
            for result in confluence_results:
                results.append({
                    'title': result['title'],
                    'url': result['url'],
                    'type': result['type'],
                    'snippet': f"Found in {result['space']} space"
                })
            
            # Search Jira
            jira_results = self.jira_connector.search_issues(query, limit=3)
            for result in jira_results:
                results.append({
                    'title': result['title'],
                    'url': result['url'],
                    'type': result['type'],
                    'snippet': f"{result['status']} - {result['description'][:100]}..."
                })
        except Exception as e:
            logger.error(f"Error in live search: {str(e)}")
        
        return results
    
    def get_knowledge_stats(self) -> Dict:
        """Get statistics about the knowledge base"""
        return {
            'total_documents': len(self.knowledge_manager.documents),
            'has_embeddings': self.knowledge_manager.embeddings is not None,
            'confluence_connected': self.confluence_connector.test_connection(),
            'jira_connected': self.jira_connector.test_connection()
        }