import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Confluence settings
    CONFLUENCE_URL = os.getenv('CONFLUENCE_URL')
    CONFLUENCE_USERNAME = os.getenv('CONFLUENCE_USERNAME')
    CONFLUENCE_API_TOKEN = os.getenv('CONFLUENCE_API_TOKEN')
    
    # Jira settings
    JIRA_URL = os.getenv('JIRA_URL')
    JIRA_USERNAME = os.getenv('JIRA_USERNAME')
    JIRA_API_TOKEN = os.getenv('JIRA_API_TOKEN')
    
    # OpenAI settings
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    
    # Flask settings
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    FLASK_DEBUG = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    # Knowledge base settings
    KNOWLEDGE_BASE_PATH = 'knowledge_base'
    VECTOR_DB_PATH = 'vector_db'
    
    # Configured pages to learn from
    CONFLUENCE_PAGES = [
        'H2H',  # Host-to-Host documentation
        'AFS',  # Application File System
        'Opstool',  # Operations Tool
        'WPI',  # Web Payment Interface
        'Payment Processing',
        'API Documentation',
        'Troubleshooting Guide'
    ]
    
    JIRA_PROJECTS = [
        'H2H',  # Host-to-Host project
        'PAY',  # Payment project
        'OPS',  # Operations project
        'DEV'   # Development project
    ]