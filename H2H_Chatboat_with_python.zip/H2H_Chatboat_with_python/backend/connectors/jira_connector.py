from atlassian import Jira
import logging
from typing import List, Dict, Optional
from config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class JiraConnector:
    def __init__(self):
        self.jira = Jira(
            url=Config.JIRA_URL,
            username=Config.JIRA_USERNAME,
            password=Config.JIRA_API_TOKEN,
            cloud=True
        )
    
    def test_connection(self) -> bool:
        """Test connection to Jira"""
        try:
            projects = self.jira.projects(limit=1)
            logger.info("Successfully connected to Jira")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Jira: {str(e)}")
            return False
    
    def search_issues(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for issues in Jira"""
        try:
            jql = f'text ~ "{query}" ORDER BY updated DESC'
            issues = self.jira.jql(jql, limit=limit)
            
            issue_list = []
            for issue in issues.get('issues', []):
                issue_data = {
                    'key': issue['key'],
                    'title': issue['fields']['summary'],
                    'description': issue['fields'].get('description', ''),
                    'status': issue['fields']['status']['name'],
                    'priority': issue['fields']['priority']['name'] if issue['fields']['priority'] else 'None',
                    'project': issue['fields']['project']['name'],
                    'url': f"{Config.JIRA_URL}/browse/{issue['key']}",
                    'type': 'jira',
                    'issue_type': issue['fields']['issuetype']['name']
                }
                issue_list.append(issue_data)
            
            return issue_list
        except Exception as e:
            logger.error(f"Error searching Jira issues: {str(e)}")
            return []
    
    def get_issue_details(self, issue_key: str) -> Optional[Dict]:
        """Get detailed information about a specific issue"""
        try:
            issue = self.jira.issue(issue_key)
            
            # Extract comments
            comments = []
            if 'comment' in issue['fields'] and issue['fields']['comment']['comments']:
                for comment in issue['fields']['comment']['comments']:
                    comments.append({
                        'author': comment['author']['displayName'],
                        'body': comment['body'],
                        'created': comment['created']
                    })
            
            return {
                'key': issue['key'],
                'title': issue['fields']['summary'],
                'description': issue['fields'].get('description', ''),
                'status': issue['fields']['status']['name'],
                'priority': issue['fields']['priority']['name'] if issue['fields']['priority'] else 'None',
                'project': issue['fields']['project']['name'],
                'assignee': issue['fields']['assignee']['displayName'] if issue['fields']['assignee'] else 'Unassigned',
                'reporter': issue['fields']['reporter']['displayName'],
                'created': issue['fields']['created'],
                'updated': issue['fields']['updated'],
                'url': f"{Config.JIRA_URL}/browse/{issue['key']}",
                'comments': comments,
                'type': 'jira',
                'issue_type': issue['fields']['issuetype']['name']
            }
        except Exception as e:
            logger.error(f"Error getting issue details for {issue_key}: {str(e)}")
            return None
    
    def get_project_issues(self, project_key: str, limit: int = 50) -> List[Dict]:
        """Get issues from a specific project"""
        try:
            jql = f'project = "{project_key}" ORDER BY updated DESC'
            issues = self.jira.jql(jql, limit=limit)
            
            issue_list = []
            for issue in issues.get('issues', []):
                issue_details = self.get_issue_details(issue['key'])
                if issue_details:
                    issue_list.append(issue_details)
            
            return issue_list
        except Exception as e:
            logger.error(f"Error getting issues from project {project_key}: {str(e)}")
            return []
    
    def search_by_labels(self, labels: List[str], limit: int = 20) -> List[Dict]:
        """Search issues by labels"""
        try:
            label_query = ' OR '.join([f'labels = "{label}"' for label in labels])
            jql = f'({label_query}) ORDER BY updated DESC'
            
            issues = self.jira.jql(jql, limit=limit)
            
            issue_list = []
            for issue in issues.get('issues', []):
                issue_details = self.get_issue_details(issue['key'])
                if issue_details:
                    issue_list.append(issue_details)
            
            return issue_list
        except Exception as e:
            logger.error(f"Error searching issues by labels: {str(e)}")
            return []