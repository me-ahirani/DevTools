import requests
from atlassian import Confluence
from bs4 import BeautifulSoup
import logging
from typing import List, Dict, Optional
from config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConfluenceConnector:
    def __init__(self):
        self.confluence = Confluence(
            url=Config.CONFLUENCE_URL,
            username=Config.CONFLUENCE_USERNAME,
            password=Config.CONFLUENCE_API_TOKEN,
            cloud=True
        )
        
    def test_connection(self) -> bool:
        """Test connection to Confluence"""
        try:
            spaces = self.confluence.get_all_spaces(limit=1)
            logger.info("Successfully connected to Confluence")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Confluence: {str(e)}")
            return False
    
    def search_pages(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for pages in Confluence"""
        try:
            results = self.confluence.cql(
                f'text ~ "{query}" AND type = "page"',
                limit=limit
            )
            
            pages = []
            for result in results.get('results', []):
                page_data = {
                    'id': result['content']['id'],
                    'title': result['content']['title'],
                    'url': f"{Config.CONFLUENCE_URL}/pages/viewpage.action?pageId={result['content']['id']}",
                    'space': result['content']['space']['name'],
                    'type': 'confluence'
                }
                pages.append(page_data)
            
            return pages
        except Exception as e:
            logger.error(f"Error searching Confluence pages: {str(e)}")
            return []
    
    def get_page_content(self, page_id: str) -> Optional[Dict]:
        """Get detailed content of a specific page"""
        try:
            page = self.confluence.get_page_by_id(
                page_id, 
                expand='body.storage,space,version'
            )
            
            # Parse HTML content
            soup = BeautifulSoup(page['body']['storage']['value'], 'html.parser')
            text_content = soup.get_text(separator=' ', strip=True)
            
            return {
                'id': page['id'],
                'title': page['title'],
                'content': text_content,
                'html_content': page['body']['storage']['value'],
                'space': page['space']['name'],
                'url': f"{Config.CONFLUENCE_URL}/pages/viewpage.action?pageId={page['id']}",
                'last_modified': page['version']['when'],
                'type': 'confluence'
            }
        except Exception as e:
            logger.error(f"Error getting page content for {page_id}: {str(e)}")
            return None
    
    def get_pages_by_title(self, titles: List[str]) -> List[Dict]:
        """Get pages by their titles"""
        pages = []
        for title in titles:
            try:
                results = self.confluence.cql(
                    f'title = "{title}" AND type = "page"',
                    limit=5
                )
                
                for result in results.get('results', []):
                    page_content = self.get_page_content(result['content']['id'])
                    if page_content:
                        pages.append(page_content)
                        
            except Exception as e:
                logger.error(f"Error getting page by title '{title}': {str(e)}")
                continue
        
        return pages
    
    def get_space_pages(self, space_key: str, limit: int = 50) -> List[Dict]:
        """Get all pages from a specific space"""
        try:
            pages = self.confluence.get_all_pages_from_space(
                space_key, 
                start=0, 
                limit=limit,
                expand='body.storage,version'
            )
            
            page_contents = []
            for page in pages:
                soup = BeautifulSoup(page['body']['storage']['value'], 'html.parser')
                text_content = soup.get_text(separator=' ', strip=True)
                
                page_data = {
                    'id': page['id'],
                    'title': page['title'],
                    'content': text_content,
                    'html_content': page['body']['storage']['value'],
                    'space': space_key,
                    'url': f"{Config.CONFLUENCE_URL}/pages/viewpage.action?pageId={page['id']}",
                    'last_modified': page['version']['when'],
                    'type': 'confluence'
                }
                page_contents.append(page_data)
            
            return page_contents
        except Exception as e:
            logger.error(f"Error getting pages from space {space_key}: {str(e)}")
            return []