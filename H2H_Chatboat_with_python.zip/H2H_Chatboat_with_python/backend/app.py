from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
from services.learning_service import LearningService
from config import Config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Initialize services
learning_service = LearningService()

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'message': 'H2H Backend is running'})

@app.route('/api/test-connections', methods=['POST'])
def test_connections():
    """Test connections to Confluence and Jira"""
    try:
        confluence_status = learning_service.confluence_connector.test_connection()
        jira_status = learning_service.jira_connector.test_connection()
        
        return jsonify({
            'confluence': {
                'status': 'success' if confluence_status else 'error',
                'connected': confluence_status
            },
            'jira': {
                'status': 'success' if jira_status else 'error',
                'connected': jira_status
            }
        })
    except Exception as e:
        logger.error(f"Error testing connections: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/learn', methods=['POST'])
def trigger_learning():
    """Trigger the learning process"""
    try:
        logger.info("Starting learning process...")
        results = learning_service.full_learning_cycle()
        
        return jsonify({
            'success': True,
            'message': 'Learning process completed',
            'results': results
        })
    except Exception as e:
        logger.error(f"Error in learning process: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages and provide answers"""
    try:
        data = request.get_json()
        question = data.get('message', '')
        
        if not question:
            return jsonify({'error': 'No message provided'}), 400
        
        logger.info(f"Processing question: {question}")
        
        # Get answer from learning service
        result = learning_service.search_and_answer(question)
        
        return jsonify({
            'success': True,
            'answer': result['answer'],
            'sources': result['sources'],
            'confidence': result['confidence']
        })
    except Exception as e:
        logger.error(f"Error processing chat message: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search', methods=['POST'])
def search():
    """Search in Confluence and Jira"""
    try:
        data = request.get_json()
        query = data.get('query', '')
        
        if not query:
            return jsonify({'error': 'No query provided'}), 400
        
        # Search live in both systems
        results = learning_service.search_live(query)
        
        return jsonify({
            'success': True,
            'results': results
        })
    except Exception as e:
        logger.error(f"Error in search: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/knowledge-stats', methods=['GET'])
def knowledge_stats():
    """Get knowledge base statistics"""
    try:
        stats = learning_service.get_knowledge_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting knowledge stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/update-config', methods=['POST'])
def update_config():
    """Update configuration settings"""
    try:
        data = request.get_json()
        
        # In a real implementation, you would update the configuration
        # For now, just return success
        return jsonify({
            'success': True,
            'message': 'Configuration updated successfully'
        })
    except Exception as e:
        logger.error(f"Error updating config: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=Config.FLASK_DEBUG
    )