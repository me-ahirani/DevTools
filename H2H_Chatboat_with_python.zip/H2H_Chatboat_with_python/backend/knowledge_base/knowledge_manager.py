import os
import json
import pickle
from typing import List, Dict, Optional
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import logging
from config import Config

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class KnowledgeManager:
    def __init__(self):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.knowledge_base_path = Config.KNOWLEDGE_BASE_PATH
        self.vector_db_path = Config.VECTOR_DB_PATH
        self.documents = []
        self.embeddings = None
        self.stop_words = set(stopwords.words('english'))
        
        # Create directories if they don't exist
        os.makedirs(self.knowledge_base_path, exist_ok=True)
        os.makedirs(self.vector_db_path, exist_ok=True)
        
        # Load existing knowledge base
        self.load_knowledge_base()
    
    def preprocess_text(self, text: str) -> str:
        """Preprocess text for better embedding"""
        # Tokenize and remove stopwords
        words = word_tokenize(text.lower())
        filtered_words = [word for word in words if word.isalnum() and word not in self.stop_words]
        return ' '.join(filtered_words)
    
    def chunk_text(self, text: str, max_chunk_size: int = 500) -> List[str]:
        """Split text into smaller chunks for better retrieval"""
        sentences = sent_tokenize(text)
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            if len(current_chunk) + len(sentence) <= max_chunk_size:
                current_chunk += " " + sentence
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def add_document(self, document: Dict):
        """Add a document to the knowledge base"""
        try:
            # Create chunks from the document content
            chunks = self.chunk_text(document['content'])
            
            for i, chunk in enumerate(chunks):
                doc_chunk = {
                    'id': f"{document['id']}_chunk_{i}",
                    'original_id': document['id'],
                    'title': document['title'],
                    'content': chunk,
                    'source_type': document['type'],
                    'url': document['url'],
                    'metadata': {
                        'space': document.get('space', ''),
                        'project': document.get('project', ''),
                        'last_modified': document.get('last_modified', ''),
                        'chunk_index': i,
                        'total_chunks': len(chunks)
                    }
                }
                self.documents.append(doc_chunk)
            
            logger.info(f"Added document '{document['title']}' with {len(chunks)} chunks")
        except Exception as e:
            logger.error(f"Error adding document: {str(e)}")
    
    def build_embeddings(self):
        """Build embeddings for all documents"""
        try:
            if not self.documents:
                logger.warning("No documents to build embeddings for")
                return
            
            logger.info(f"Building embeddings for {len(self.documents)} document chunks...")
            
            # Extract text content for embedding
            texts = [doc['content'] for doc in self.documents]
            
            # Generate embeddings
            self.embeddings = self.model.encode(texts, show_progress_bar=True)
            
            logger.info("Embeddings built successfully")
            self.save_knowledge_base()
        except Exception as e:
            logger.error(f"Error building embeddings: {str(e)}")
    
    def search_similar(self, query: str, top_k: int = 5) -> List[Dict]:
        """Search for similar documents based on query"""
        try:
            if self.embeddings is None or len(self.documents) == 0:
                logger.warning("No embeddings available for search")
                return []
            
            # Generate query embedding
            query_embedding = self.model.encode([query])
            
            # Calculate similarities
            similarities = cosine_similarity(query_embedding, self.embeddings)[0]
            
            # Get top-k most similar documents
            top_indices = np.argsort(similarities)[::-1][:top_k]
            
            results = []
            for idx in top_indices:
                if similarities[idx] > 0.3:  # Minimum similarity threshold
                    doc = self.documents[idx].copy()
                    doc['similarity_score'] = float(similarities[idx])
                    results.append(doc)
            
            return results
        except Exception as e:
            logger.error(f"Error searching similar documents: {str(e)}")
            return []
    
    def get_answer(self, question: str) -> Dict:
        """Get an answer to a question based on the knowledge base"""
        try:
            # Search for relevant documents
            relevant_docs = self.search_similar(question, top_k=3)
            
            if not relevant_docs:
                return {
                    'answer': "I couldn't find relevant information in the knowledge base for your question.",
                    'sources': [],
                    'confidence': 0.0
                }
            
            # Combine relevant content
            combined_content = []
            sources = []
            
            for doc in relevant_docs:
                combined_content.append(doc['content'])
                sources.append({
                    'title': doc['title'],
                    'url': doc['url'],
                    'type': doc['source_type'],
                    'snippet': doc['content'][:200] + "..." if len(doc['content']) > 200 else doc['content'],
                    'similarity': doc['similarity_score']
                })
            
            # Generate answer based on relevant content
            answer = self.generate_answer(question, combined_content)
            
            return {
                'answer': answer,
                'sources': sources,
                'confidence': relevant_docs[0]['similarity_score'] if relevant_docs else 0.0
            }
        except Exception as e:
            logger.error(f"Error getting answer: {str(e)}")
            return {
                'answer': "An error occurred while processing your question.",
                'sources': [],
                'confidence': 0.0
            }
    
    def generate_answer(self, question: str, contexts: List[str]) -> str:
        """Generate an answer based on question and context"""
        # Simple extractive approach - find the most relevant sentences
        question_lower = question.lower()
        
        # Keywords from the question
        question_words = set(word_tokenize(question_lower)) - self.stop_words
        
        best_sentences = []
        for context in contexts:
            sentences = sent_tokenize(context)
            for sentence in sentences:
                sentence_words = set(word_tokenize(sentence.lower())) - self.stop_words
                overlap = len(question_words.intersection(sentence_words))
                if overlap > 0:
                    best_sentences.append((sentence, overlap))
        
        # Sort by overlap and take top sentences
        best_sentences.sort(key=lambda x: x[1], reverse=True)
        
        if best_sentences:
            # Combine top sentences into an answer
            answer_sentences = [sent[0] for sent in best_sentences[:3]]
            return ' '.join(answer_sentences)
        else:
            # Fallback to first context
            return contexts[0][:500] + "..." if len(contexts[0]) > 500 else contexts[0]
    
    def save_knowledge_base(self):
        """Save knowledge base to disk"""
        try:
            # Save documents
            with open(os.path.join(self.knowledge_base_path, 'documents.json'), 'w') as f:
                json.dump(self.documents, f, indent=2)
            
            # Save embeddings
            if self.embeddings is not None:
                with open(os.path.join(self.vector_db_path, 'embeddings.pkl'), 'wb') as f:
                    pickle.dump(self.embeddings, f)
            
            logger.info("Knowledge base saved successfully")
        except Exception as e:
            logger.error(f"Error saving knowledge base: {str(e)}")
    
    def load_knowledge_base(self):
        """Load knowledge base from disk"""
        try:
            # Load documents
            docs_path = os.path.join(self.knowledge_base_path, 'documents.json')
            if os.path.exists(docs_path):
                with open(docs_path, 'r') as f:
                    self.documents = json.load(f)
                logger.info(f"Loaded {len(self.documents)} documents")
            
            # Load embeddings
            embeddings_path = os.path.join(self.vector_db_path, 'embeddings.pkl')
            if os.path.exists(embeddings_path):
                with open(embeddings_path, 'rb') as f:
                    self.embeddings = pickle.load(f)
                logger.info("Loaded embeddings")
        except Exception as e:
            logger.error(f"Error loading knowledge base: {str(e)}")
    
    def clear_knowledge_base(self):
        """Clear the entire knowledge base"""
        self.documents = []
        self.embeddings = None
        logger.info("Knowledge base cleared")