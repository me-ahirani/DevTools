"""
File Manager utility for handling file operations.
Manages generated files, downloads, and ZIP archive creation.
"""

import os
import shutil
import zipfile
import tempfile
import uuid
from typing import Dict, List, Optional
from pathlib import Path
import logging

class FileManager:
    """Manages file operations for generated test files."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.generated_dir = "generated"
        self.temp_dir = "temp"
        self.file_registry = {}  # Maps file IDs to file paths
        
        # Ensure directories exist
        os.makedirs(self.generated_dir, exist_ok=True)
        os.makedirs(self.temp_dir, exist_ok=True)
    
    def register_file(self, file_path: str, file_info: Dict) -> str:
        """
        Register a generated file and return its ID.
        
        Args:
            file_path: Path to the generated file
            file_info: Dictionary containing file metadata
            
        Returns:
            Unique file ID
        """
        file_id = str(uuid.uuid4())
        self.file_registry[file_id] = {
            "path": file_path,
            "info": file_info
        }
        return file_id
    
    def get_file_path(self, file_id: str) -> Optional[str]:
        """
        Get the file path for a given file ID.
        
        Args:
            file_id: Unique file identifier
            
        Returns:
            File path if found, None otherwise
        """
        if file_id in self.file_registry:
            return self.file_registry[file_id]["path"]
        
        # Fallback: try to find file by matching filename pattern
        try:
            for filename in os.listdir(self.generated_dir):
                file_path = os.path.join(self.generated_dir, filename)
                if os.path.isfile(file_path):
                    return file_path
        except Exception as e:
            self.logger.error(f"Error searching for file {file_id}: {e}")
        
        return None
    
    def get_file_info(self, file_id: str) -> Optional[Dict]:
        """
        Get file information for a given file ID.
        
        Args:
            file_id: Unique file identifier
            
        Returns:
            File information dictionary if found, None otherwise
        """
        if file_id in self.file_registry:
            return self.file_registry[file_id]["info"]
        return None
    
    def create_zip_archive(self) -> Optional[str]:
        """
        Create a ZIP archive containing all generated files.
        
        Returns:
            Path to the created ZIP file, None if no files to archive
        """
        try:
            # Check if there are files to archive
            files_to_archive = []
            
            for filename in os.listdir(self.generated_dir):
                file_path = os.path.join(self.generated_dir, filename)
                if os.path.isfile(file_path):
                    files_to_archive.append((file_path, filename))
            
            if not files_to_archive:
                self.logger.warning("No files found to create ZIP archive")
                return None
            
            # Create ZIP file
            zip_path = os.path.join(self.temp_dir, f"generated_files_{uuid.uuid4().hex[:8]}.zip")
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file_path, filename in files_to_archive:
                    zipf.write(file_path, filename)
            
            self.logger.info(f"Created ZIP archive with {len(files_to_archive)} files: {zip_path}")
            return zip_path
            
        except Exception as e:
            self.logger.error(f"Failed to create ZIP archive: {e}")
            return None
    
    def cleanup_temp_files(self, max_age_hours: int = 24):
        """
        Clean up temporary files older than specified age.
        
        Args:
            max_age_hours: Maximum age in hours before files are deleted
        """
        try:
            import time
            current_time = time.time()
            max_age_seconds = max_age_hours * 3600
            
            for filename in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, filename)
                if os.path.isfile(file_path):
                    file_age = current_time - os.path.getmtime(file_path)
                    if file_age > max_age_seconds:
                        os.remove(file_path)
                        self.logger.info(f"Cleaned up old temp file: {filename}")
                        
        except Exception as e:
            self.logger.error(f"Error during temp file cleanup: {e}")
    
    def get_file_stats(self) -> Dict[str, int]:
        """
        Get statistics about managed files.
        
        Returns:
            Dictionary containing file statistics
        """
        stats = {
            "registered_files": len(self.file_registry),
            "generated_files": 0,
            "temp_files": 0,
            "total_size": 0
        }
        
        try:
            # Count generated files
            for filename in os.listdir(self.generated_dir):
                file_path = os.path.join(self.generated_dir, filename)
                if os.path.isfile(file_path):
                    stats["generated_files"] += 1
                    stats["total_size"] += os.path.getsize(file_path)
            
            # Count temp files
            for filename in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, filename)
                if os.path.isfile(file_path):
                    stats["temp_files"] += 1
                    
        except Exception as e:
            self.logger.error(f"Error getting file stats: {e}")
        
        return stats
    
    def clear_all_files(self):
        """Clear all generated and temporary files."""
        try:
            # Clear generated files
            for filename in os.listdir(self.generated_dir):
                file_path = os.path.join(self.generated_dir, filename)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            
            # Clear temp files
            for filename in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, filename)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            
            # Clear registry
            self.file_registry.clear()
            
            self.logger.info("Cleared all generated and temporary files")
            
        except Exception as e:
            self.logger.error(f"Error clearing files: {e}")
    
    def save_uploaded_file(self, file_content: bytes, filename: str) -> str:
        """
        Save uploaded file content to temporary directory.
        
        Args:
            file_content: Raw file content
            filename: Original filename
            
        Returns:
            Path to saved file
        """
        try:
            # Generate unique filename to avoid conflicts
            base_name, ext = os.path.splitext(filename)
            unique_filename = f"{base_name}_{uuid.uuid4().hex[:8]}{ext}"
            file_path = os.path.join(self.temp_dir, unique_filename)
            
            with open(file_path, 'wb') as f:
                f.write(file_content)
            
            self.logger.info(f"Saved uploaded file: {unique_filename}")
            return file_path
            
        except Exception as e:
            self.logger.error(f"Failed to save uploaded file {filename}: {e}")
            raise
    
    def get_directory_size(self, directory: str) -> int:
        """
        Calculate total size of files in a directory.
        
        Args:
            directory: Directory path
            
        Returns:
            Total size in bytes
        """
        total_size = 0
        try:
            for filename in os.listdir(directory):
                file_path = os.path.join(directory, filename)
                if os.path.isfile(file_path):
                    total_size += os.path.getsize(file_path)
        except Exception as e:
            self.logger.error(f"Error calculating directory size for {directory}: {e}")
        
        return total_size