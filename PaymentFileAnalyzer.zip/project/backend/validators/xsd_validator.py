"""
XSD Validator module for validating XML files against XSD schemas.
Uses xmlschema library for robust validation with detailed error reporting.
"""

import os
import logging
from datetime import datetime
from typing import Dict, List, Any
import xmlschema
from lxml import etree

class XSDValidator:
    """Handles XML validation against XSD schemas."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def validate_xml_against_xsd(self, xml_path: str, xsd_path: str) -> Dict[str, Any]:
        """
        Validate an XML file against an XSD schema.
        
        Args:
            xml_path: Path to the XML file to validate
            xsd_path: Path to the XSD schema file
            
        Returns:
            Dictionary containing validation results
        """
        try:
            # Load the XSD schema
            schema = xmlschema.XMLSchema(xsd_path)
            
            # Validate the XML
            errors = []
            warnings = []
            is_valid = True
            
            try:
                # Perform validation
                schema.validate(xml_path)
                self.logger.info(f"XML file {xml_path} is valid against schema {xsd_path}")
                
            except xmlschema.XMLSchemaException as e:
                is_valid = False
                errors.append(str(e))
                self.logger.error(f"Validation error: {e}")
                
            except Exception as e:
                is_valid = False
                errors.append(f"Validation failed: {str(e)}")
                self.logger.error(f"Unexpected validation error: {e}")
            
            # Additional checks for warnings
            try:
                # Parse XML to check for potential issues
                tree = etree.parse(xml_path)
                root = tree.getroot()
                
                # Check for empty elements that might be optional
                empty_elements = root.xpath("//*[not(node())]")
                if empty_elements:
                    warnings.append(f"Found {len(empty_elements)} empty elements")
                
                # Check for namespace issues
                if not root.nsmap:
                    warnings.append("No namespace declarations found")
                    
            except Exception as e:
                warnings.append(f"Warning during additional checks: {str(e)}")
            
            return {
                "isValid": is_valid,
                "errors": errors,
                "warnings": warnings,
                "timestamp": datetime.now().isoformat()
            }
            
        except FileNotFoundError as e:
            return {
                "isValid": False,
                "errors": [f"File not found: {str(e)}"],
                "warnings": [],
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "isValid": False,
                "errors": [f"Validation process failed: {str(e)}"],
                "warnings": [],
                "timestamp": datetime.now().isoformat()
            }
    
    def get_schema_info(self, xsd_path: str) -> Dict[str, Any]:
        """
        Extract information about the XSD schema.
        
        Args:
            xsd_path: Path to the XSD schema file
            
        Returns:
            Dictionary containing schema information
        """
        try:
            schema = xmlschema.XMLSchema(xsd_path)
            
            return {
                "target_namespace": schema.target_namespace,
                "root_elements": list(schema.elements.keys()),
                "complex_types": list(schema.types.keys()),
                "simple_types": list(schema.simple_types.keys()) if hasattr(schema, 'simple_types') else [],
                "attributes": list(schema.attributes.keys()) if hasattr(schema, 'attributes') else []
            }
            
        except Exception as e:
            self.logger.error(f"Failed to extract schema info: {e}")
            return {"error": str(e)}
    
    def validate_multiple_files(self, xml_files: List[str], xsd_path: str) -> List[Dict[str, Any]]:
        """
        Validate multiple XML files against the same XSD schema.
        
        Args:
            xml_files: List of paths to XML files
            xsd_path: Path to the XSD schema file
            
        Returns:
            List of validation results for each file
        """
        results = []
        
        for xml_file in xml_files:
            result = self.validate_xml_against_xsd(xml_file, xsd_path)
            result["filename"] = os.path.basename(xml_file)
            results.append(result)
            
        return results