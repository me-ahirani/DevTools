# Payment File Analyzer - Backend Setup

This backend is built with FastAPI and serves as the core for file upload, validation, test data generation, and job execution.

## Prerequisites
- Python 3.8+
- pip (Python package manager)

## Installation & Setup

1. **Navigate to the backend directory:**
   ```powershell
   cd backend
   ```

2. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

3. **Ensure the following directories exist:**
   - `temp`
   - `generated`
   - `Test_Suite`
   - (These are auto-created on server start, but you can create them manually if needed.)

4. **Ensure the frontend build exists:**
   - The backend serves static files from the `../dist` directory. Make sure you have built the frontend and the `dist` folder exists at the project root.

## Running the Backend

From the `backend` directory, run:

```powershell
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

- The API will be available at: http://127.0.0.1:8000
- Health check endpoint: http://127.0.0.1:8000/api/ping

## Common Issues

- **ModuleNotFoundError**: If you see errors about missing modules (e.g., `uvicorn`, `fastapi`, `xmlschema`, `lxml`, `scikit-learn`), make sure you have installed all dependencies with `pip install -r requirements.txt`.
- **Static files error**: If you see `RuntimeError: Directory '../dist' does not exist`, ensure you have built the frontend and the `dist` folder is present at the project root.

## Useful Endpoints
- `POST /api/validate` - Validate XML against XSD
- `POST /api/analyze-xsd` - Analyze XSD schema
- `POST /api/generate` - Generate test files
- `POST /api/jobs/execute` - Execute jobs
- `POST /api/jobs/stop` - Stop jobs
- `GET /api/jobs/status` - Get job status
- `GET /api/download/{file_id}` - Download a generated file
- `GET /api/download-all` - Download all files as ZIP
- `GET /api/ping` - Health check

---

For any issues, check the error logs and ensure all dependencies are installed and the required folders exist.
