#!/usr/bin/env python3
"""
Main FastAPI application for Payment File Analyzer.
Handles file upload, validation, test data generation, and job execution.
"""

import os
import sys
import uvicorn
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import json
import tempfile
import shutil
from pathlib import Path

# Add backend directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from validators.xsd_validator import XSDValidator
from generators.test_data_generator import TestDataGenerator
from analyzers.xsd_analyzer import XSDAnalyzer
from utils.file_manager import FileManager
from jobs.job_manager import JobManager

app = FastAPI(title="Payment File Analyzer", version="1.0.0")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
file_manager = FileManager()
validator = XSDValidator()
generator = TestDataGenerator()
analyzer = XSDAnalyzer()
job_manager = JobManager()

@app.post("/api/validate")
async def validate_file(
    payment_file: UploadFile = File(...),
    xsd_file: UploadFile = File(...)
):
    """Validate a payment XML file against XSD schema."""
    try:
        # Save uploaded files temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xml') as xml_temp:
            xml_content = await payment_file.read()
            xml_temp.write(xml_content)
            xml_path = xml_temp.name

        with tempfile.NamedTemporaryFile(delete=False, suffix='.xsd') as xsd_temp:
            xsd_content = await xsd_file.read()
            xsd_temp.write(xsd_content)
            xsd_path = xsd_temp.name

        # Perform validation
        result = validator.validate_xml_against_xsd(xml_path, xsd_path)
        
        # Cleanup temporary files
        os.unlink(xml_path)
        os.unlink(xsd_path)
        
        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@app.post("/api/analyze-xsd")
async def analyze_xsd(xsd_file: UploadFile = File(...)):
    """Analyze XSD schema to find multiple occurrence tags."""
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xsd') as xsd_temp:
            xsd_content = await xsd_file.read()
            xsd_temp.write(xsd_content)
            xsd_path = xsd_temp.name

        # Analyze XSD schema
        analysis_result = analyzer.analyze_schema(xsd_path)
        
        # Cleanup temporary file
        os.unlink(xsd_path)
        
        return analysis_result

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"XSD analysis failed: {str(e)}")

@app.post("/api/generate")
async def generate_files(
    xsd_file: UploadFile = File(...),
    criteria: str = Form(...)
):
    """Generate test files based on criteria."""
    try:
        # Parse criteria
        criteria_data = json.loads(criteria)
        
        # Save XSD file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xsd') as xsd_temp:
            xsd_content = await xsd_file.read()
            xsd_temp.write(xsd_content)
            xsd_path = xsd_temp.name

        # Generate files and stream progress
        def generate_stream():
            try:
                for progress_data in generator.generate_test_files(xsd_path, criteria_data):
                    yield f"{json.dumps(progress_data)}\n"
            finally:
                # Cleanup temporary file
                os.unlink(xsd_path)

        return StreamingResponse(
            generate_stream(),
            media_type="application/x-ndjson",
            headers={"Cache-Control": "no-cache"}
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File generation failed: {str(e)}")

@app.post("/api/jobs/execute")
async def execute_jobs(request_data: dict):
    """Execute jobs based on configuration."""
    try:
        configuration = request_data.get('configuration', {})
        enabled_jobs = request_data.get('enabledJobs', [])
        
        # Stream job execution progress
        async def job_stream():
            async for update in job_manager.execute_jobs(configuration, enabled_jobs):
                yield f"{json.dumps(update)}\n"
        
        return StreamingResponse(
            job_stream(),
            media_type="application/x-ndjson",
            headers={"Cache-Control": "no-cache"}
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Job execution failed: {str(e)}")

@app.post("/api/jobs/stop")
async def stop_jobs():
    """Stop job execution."""
    try:
        job_manager.stop_execution()
        return {"status": "stopped"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to stop jobs: {str(e)}")

@app.get("/api/jobs/status")
async def get_job_status():
    """Get current job execution status."""
    try:
        return job_manager.get_all_job_statuses()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get job status: {str(e)}")

@app.get("/api/download/{file_id}")
async def download_file(file_id: str):
    """Download a specific generated file."""
    try:
        file_path = file_manager.get_file_path(file_id)
        if not file_path or not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File not found")
        
        return FileResponse(
            file_path,
            media_type='application/xml',
            filename=os.path.basename(file_path)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")

@app.get("/api/download-all")
async def download_all_files():
    """Download all generated files as a ZIP archive."""
    try:
        zip_path = file_manager.create_zip_archive()
        if not zip_path or not os.path.exists(zip_path):
            raise HTTPException(status_code=404, detail="No files to download")
        
        return FileResponse(
            zip_path,
            media_type='application/zip',
            filename='generated_payment_files.zip'
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"ZIP creation failed: {str(e)}")

@app.get("/api/ping")
def ping():
    """Health check endpoint."""
    return {"status": "ok"}

# Serve static files for the frontend
app.mount("/", StaticFiles(directory="../dist", html=True), name="static")

if __name__ == "__main__":
    # Ensure required directories exist
    os.makedirs("temp", exist_ok=True)
    os.makedirs("generated", exist_ok=True)
    os.makedirs("Test_Suite", exist_ok=True)
    
    # Run the server
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
        log_level="info"
    )