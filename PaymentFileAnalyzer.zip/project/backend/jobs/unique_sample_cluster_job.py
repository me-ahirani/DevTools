"""
Unique Sample Cluster Job - Creates a cluster with unique sample files.
Picks one representative file from each cluster set based on uniqueness criteria.
"""

import os
import random
from collections import defaultdict
from typing import Dict, List, Any
from .base_job import BaseJob

class UniqueSampleClusterJob(BaseJob):
    """Job to create unique sample clusters from existing clusters."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute unique sample clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting unique sample cluster job")
        
        try:
            # Find the schema-based output folder (dependency)
            schema_name = self.get_schema_name_from_xsd()
            schema_folder_name = self.get_today_folder_name(schema_name)
            schema_folder = os.path.join(self.output_path, schema_folder_name)
            
            if not os.path.exists(schema_folder):
                raise ValueError(f"Schema cluster folder not found: {schema_folder}")
            
            # Find existing cluster folders
            cluster_folders = []
            for item in os.listdir(schema_folder):
                item_path = os.path.join(schema_folder, item)
                if os.path.isdir(item_path) and not item.startswith('.'):
                    cluster_folders.append(item_path)
            
            self.logger.info(f"Found {len(cluster_folders)} cluster folders to sample from")
            
            if not cluster_folders:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': schema_folder,
                    'clusterDetails': {}
                }
            
            # Create unique test set folder
            unique_folder = os.path.join(schema_folder, "unique_test_set")
            os.makedirs(unique_folder, exist_ok=True)
            
            selected_files = []
            cluster_details = {}
            
            for i, cluster_folder in enumerate(cluster_folders):
                try:
                    # Update progress
                    progress = int((i / len(cluster_folders)) * 100)
                    self.update_progress(progress)
                    
                    # Get XML files from cluster
                    xml_files = self.get_xml_files(cluster_folder)
                    
                    if xml_files:
                        # Select representative file based on uniqueness criteria
                        representative_file = self.select_representative_file(xml_files)
                        
                        if representative_file:
                            # Copy to unique test set with cluster name prefix
                            cluster_name = os.path.basename(cluster_folder)
                            filename = os.path.basename(representative_file)
                            new_filename = f"{cluster_name}_{filename}"
                            
                            destination_path = os.path.join(unique_folder, new_filename)
                            
                            import shutil
                            shutil.copy2(representative_file, destination_path)
                            
                            selected_files.append(representative_file)
                            cluster_details[cluster_name] = 1
                
                except Exception as e:
                    self.logger.error(f"Error processing cluster {cluster_folder}: {e}")
            
            # Also sample from root schema folder (unclustered files)
            root_xml_files = [f for f in self.get_xml_files(schema_folder) 
                             if os.path.dirname(f) == schema_folder]
            
            if root_xml_files:
                # Select a few representative files from root
                sample_size = min(3, len(root_xml_files))
                sampled_root_files = random.sample(root_xml_files, sample_size)
                
                for file_path in sampled_root_files:
                    filename = os.path.basename(file_path)
                    new_filename = f"unclustered_{filename}"
                    destination_path = os.path.join(unique_folder, new_filename)
                    
                    import shutil
                    shutil.copy2(file_path, destination_path)
                    selected_files.append(file_path)
                
                cluster_details["unclustered_samples"] = len(sampled_root_files)
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': sum(len(self.get_xml_files(folder)) for folder in cluster_folders),
                'clustersCreated': 1,  # One unique test set folder
                'anomaliesFound': 0,
                'outputPath': unique_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Unique sample cluster job failed: {e}")
            raise
    
    def select_representative_file(self, xml_files: List[str]) -> str:
        """Select the most representative file from a list based on uniqueness criteria."""
        if len(xml_files) == 1:
            return xml_files[0]
        
        # Strategy 1: Select file with median size
        file_sizes = []
        for file_path in xml_files:
            try:
                size = os.path.getsize(file_path)
                file_sizes.append((file_path, size))
            except Exception:
                continue
        
        if file_sizes:
            # Sort by size and pick median
            file_sizes.sort(key=lambda x: x[1])
            median_index = len(file_sizes) // 2
            return file_sizes[median_index][0]
        
        # Fallback: random selection
        return random.choice(xml_files)
    
    def calculate_file_complexity(self, file_path: str) -> float:
        """Calculate complexity score for a file."""
        try:
            root = self.parse_xml_file(file_path)
            if root is None:
                return 0.0
            
            # Count elements, attributes, and depth
            element_count = len(list(root.iter()))
            attribute_count = sum(len(elem.attrib) for elem in root.iter())
            max_depth = self.get_xml_depth(root)
            
            # Simple complexity score
            complexity = element_count + (attribute_count * 0.5) + (max_depth * 2)
            return complexity
            
        except Exception:
            return 0.0
    
    def get_xml_depth(self, element, depth=0) -> int:
        """Get maximum depth of XML element."""
        if not list(element):
            return depth
        
        return max(self.get_xml_depth(child, depth + 1) for child in element)
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0