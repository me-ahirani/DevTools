"""
Schema Cluster Job - Creates clusters based on schema validation.
This is the foundational job that validates files against XSD schema.
"""

import os
import xmlschema
from typing import Dict, List, Any
from .base_job import BaseJob

class SchemaClusterJob(BaseJob):
    """Job to create schema-based clusters of payment files."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute schema clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting schema cluster job")
        
        try:
            # Load XSD schema
            if not self.xsd_path or not os.path.exists(self.xsd_path):
                raise ValueError(f"XSD schema file not found: {self.xsd_path}")
            
            schema = xmlschema.XMLSchema(self.xsd_path)
            schema_name = self.get_schema_name_from_xsd()
            
            # Create output folder with schema name and date
            output_folder_name = self.get_today_folder_name(schema_name)
            output_folder = self.create_output_folder(output_folder_name)
            
            # Get all XML files from test suite
            xml_files = self.get_xml_files(self.test_suite_path)
            self.logger.info(f"Found {len(xml_files)} XML files to process")
            
            if not xml_files:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': output_folder,
                    'clusterDetails': {}
                }
            
            # Process files
            valid_files = []
            invalid_files = []
            
            for i, xml_file in enumerate(xml_files):
                try:
                    # Update progress
                    progress = int((i / len(xml_files)) * 100)
                    self.update_progress(progress)
                    
                    # Validate against schema
                    schema.validate(xml_file)
                    valid_files.append(xml_file)
                    
                    # Copy valid file to output folder
                    self.copy_file_to_folder(xml_file, output_folder)
                    
                except xmlschema.XMLSchemaException as e:
                    self.logger.warning(f"Schema validation failed for {xml_file}: {e}")
                    invalid_files.append(xml_file)
                except Exception as e:
                    self.logger.error(f"Error processing {xml_file}: {e}")
                    invalid_files.append(xml_file)
            
            # Create invalid files folder if needed
            cluster_details = {
                'valid_files': len(valid_files)
            }
            
            if invalid_files:
                invalid_folder = os.path.join(output_folder, 'invalid_files')
                os.makedirs(invalid_folder, exist_ok=True)
                
                for invalid_file in invalid_files:
                    self.copy_file_to_folder(invalid_file, invalid_folder)
                
                cluster_details['invalid_files'] = len(invalid_files)
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': len(xml_files),
                'clustersCreated': 1 + (1 if invalid_files else 0),
                'anomaliesFound': len(invalid_files),
                'outputPath': output_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Schema cluster job failed: {e}")
            raise
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0