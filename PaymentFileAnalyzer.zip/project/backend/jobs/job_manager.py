"""
Job Manager for orchestrating and executing payment file analysis jobs.
Handles job scheduling, execution, and progress tracking.
"""

import asyncio
import logging
import os
import json
from datetime import datetime
from typing import Dict, List, Any, AsyncGenerator
from concurrent.futures import ThreadPoolExecutor
import threading

from .schema_cluster_job import SchemaClusterJob
from .tag_match_cluster_job import TagMatchClusterJob
from .tag_data_cluster_job import TagDataClusterJob
from .anomaly_cluster_job import AnomalyClusterJob
from .unique_sample_cluster_job import UniqueSampleClusterJob
from .tag_specific_cluster_job import TagSpecificClusterJob

class JobManager:
    """Manages job execution and orchestration."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.jobs = {}
        self.job_executions = {}
        self.is_running = False
        self.stop_event = threading.Event()
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        # Initialize job classes
        self.job_classes = {
            'schema-cluster': SchemaClusterJob,
            'tag-match-cluster': TagMatchClusterJob,
            'tag-data-cluster': TagDataClusterJob,
            'anomaly-cluster': AnomalyClusterJob,
            'unique-sample-cluster': UniqueSampleClusterJob,
            'tag-specific-cluster': TagSpecificClusterJob,
        }
    
    async def execute_jobs(self, configuration: Dict[str, Any], enabled_jobs: List[str]) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Execute enabled jobs with the given configuration.
        
        Args:
            configuration: Job configuration parameters
            enabled_jobs: List of job IDs to execute
            
        Yields:
            Job execution updates
        """
        self.is_running = True
        self.stop_event.clear()
        
        try:
            # Sort jobs by priority and dependencies
            sorted_jobs = self._sort_jobs_by_dependencies(enabled_jobs)
            
            for job_id in sorted_jobs:
                if self.stop_event.is_set():
                    break
                
                # Initialize job execution
                execution = {
                    'jobId': job_id,
                    'status': 'running',
                    'progress': 0,
                    'startTime': datetime.now().isoformat(),
                    'endTime': None,
                    'error': None,
                    'results': None
                }
                
                self.job_executions[job_id] = execution
                
                yield {
                    'type': 'job_update',
                    'jobId': job_id,
                    'execution': execution
                }
                
                try:
                    # Execute job
                    job_class = self.job_classes.get(job_id)
                    if not job_class:
                        raise ValueError(f"Unknown job: {job_id}")
                    
                    job_instance = job_class(configuration)
                    
                    # Execute job with progress updates
                    async for progress_update in self._execute_job_with_progress(job_instance, job_id):
                        if self.stop_event.is_set():
                            break
                        yield progress_update
                    
                    if not self.stop_event.is_set():
                        # Job completed successfully
                        execution['status'] = 'completed'
                        execution['endTime'] = datetime.now().isoformat()
                        execution['progress'] = 100
                        
                        yield {
                            'type': 'job_update',
                            'jobId': job_id,
                            'execution': execution
                        }
                
                except Exception as e:
                    self.logger.error(f"Job {job_id} failed: {e}")
                    execution['status'] = 'failed'
                    execution['error'] = str(e)
                    execution['endTime'] = datetime.now().isoformat()
                    
                    yield {
                        'type': 'job_update',
                        'jobId': job_id,
                        'execution': execution
                    }
        
        finally:
            self.is_running = False
    
    async def _execute_job_with_progress(self, job_instance, job_id: str) -> AsyncGenerator[Dict[str, Any], None]:
        """Execute a job and yield progress updates."""
        loop = asyncio.get_event_loop()
        
        # Run job in thread pool to avoid blocking
        future = loop.run_in_executor(
            self.executor,
            self._run_job_sync,
            job_instance,
            job_id
        )
        
        # Monitor progress
        while not future.done():
            if self.stop_event.is_set():
                future.cancel()
                break
            
            # Get current progress from job instance
            progress = getattr(job_instance, 'progress', 0)
            
            execution = self.job_executions[job_id]
            execution['progress'] = progress
            
            yield {
                'type': 'job_update',
                'jobId': job_id,
                'execution': execution
            }
            
            await asyncio.sleep(1)  # Update every second
        
        if not future.cancelled():
            try:
                results = await future
                execution = self.job_executions[job_id]
                execution['results'] = results
                
                yield {
                    'type': 'job_update',
                    'jobId': job_id,
                    'execution': execution
                }
            except Exception as e:
                raise e
    
    def _run_job_sync(self, job_instance, job_id: str) -> Dict[str, Any]:
        """Run job synchronously in thread pool."""
        return job_instance.execute()
    
    def _sort_jobs_by_dependencies(self, enabled_jobs: List[str]) -> List[str]:
        """Sort jobs by their dependencies and priority."""
        job_dependencies = {
            'schema-cluster': [],
            'tag-match-cluster': ['schema-cluster'],
            'tag-data-cluster': ['schema-cluster'],
            'anomaly-cluster': ['schema-cluster'],
            'unique-sample-cluster': ['tag-match-cluster', 'tag-data-cluster'],
            'tag-specific-cluster': ['schema-cluster'],
        }
        
        job_priorities = {
            'schema-cluster': 1,
            'tag-match-cluster': 2,
            'tag-data-cluster': 3,
            'anomaly-cluster': 4,
            'unique-sample-cluster': 5,
            'tag-specific-cluster': 6,
        }
        
        # Filter enabled jobs
        enabled_jobs = [job for job in enabled_jobs if job in job_dependencies]
        
        # Topological sort considering dependencies
        sorted_jobs = []
        remaining_jobs = set(enabled_jobs)
        
        while remaining_jobs:
            # Find jobs with no unresolved dependencies
            ready_jobs = []
            for job in remaining_jobs:
                dependencies = job_dependencies.get(job, [])
                if all(dep in sorted_jobs or dep not in enabled_jobs for dep in dependencies):
                    ready_jobs.append(job)
            
            if not ready_jobs:
                # Circular dependency or missing dependency
                self.logger.warning("Circular dependency detected, adding remaining jobs by priority")
                ready_jobs = list(remaining_jobs)
            
            # Sort ready jobs by priority
            ready_jobs.sort(key=lambda x: job_priorities.get(x, 999))
            
            # Add the highest priority job
            next_job = ready_jobs[0]
            sorted_jobs.append(next_job)
            remaining_jobs.remove(next_job)
        
        return sorted_jobs
    
    def stop_execution(self):
        """Stop job execution."""
        self.stop_event.set()
        self.is_running = False
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get current status of a job."""
        return self.job_executions.get(job_id, {
            'status': 'pending',
            'progress': 0
        })
    
    def get_all_job_statuses(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all jobs."""
        return self.job_executions.copy()