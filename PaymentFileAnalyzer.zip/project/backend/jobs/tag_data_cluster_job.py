"""
Tag Data Cluster Job - Creates clusters based on both XML tag structure and content matching.
Groups files that have the same XML structure AND similar content.
"""

import os
from collections import defaultdict
from typing import Dict, List, Any
from sklearn.feature_extraction import DictVectorizer
from sklearn.cluster import DBSCAN
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from .base_job import BaseJob

class TagDataClusterJob(BaseJob):
    """Job to create clusters based on XML tag structure and content matching."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute tag and data clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting tag and data cluster job")
        
        try:
            # Find the schema-based output folder (dependency)
            schema_name = self.get_schema_name_from_xsd()
            schema_folder_name = self.get_today_folder_name(schema_name)
            schema_folder = os.path.join(self.output_path, schema_folder_name)
            
            if not os.path.exists(schema_folder):
                raise ValueError(f"Schema cluster folder not found: {schema_folder}")
            
            # Get XML files from schema folder (only valid files)
            xml_files = self.get_xml_files(schema_folder)
            # Exclude files from subfolders created by other jobs
            xml_files = [f for f in xml_files if os.path.dirname(f) == schema_folder]
            
            self.logger.info(f"Found {len(xml_files)} XML files to process")
            
            if not xml_files:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': schema_folder,
                    'clusterDetails': {}
                }
            
            # Extract features from all files
            file_features = {}
            file_transaction_counts = {}
            
            for i, xml_file in enumerate(xml_files):
                try:
                    # Update progress
                    progress = int((i / len(xml_files)) * 40)  # First 40% for feature extraction
                    self.update_progress(progress)
                    
                    # Parse XML and extract content
                    root = self.parse_xml_file(xml_file)
                    if root is not None:
                        content = self.extract_xml_content(root)
                        file_features[xml_file] = content
                        
                        # Count transactions (look for repeating transaction elements)
                        transaction_count = self.count_transactions(root)
                        file_transaction_counts[xml_file] = transaction_count
                    
                except Exception as e:
                    self.logger.error(f"Error processing {xml_file}: {e}")
            
            # Vectorize features using DictVectorizer
            self.update_progress(45)
            vectorizer = DictVectorizer(sparse=False)
            feature_matrix = vectorizer.fit_transform(list(file_features.values()))
            
            # Calculate cosine similarity matrix
            self.update_progress(50)
            similarity_matrix = cosine_similarity(feature_matrix)
            
            # Convert similarity to distance for DBSCAN
            distance_matrix = 1 - similarity_matrix
            
            # Apply DBSCAN clustering
            self.update_progress(60)
            eps = 1 - self.uniqueness_threshold  # Convert similarity threshold to distance
            dbscan = DBSCAN(eps=eps, min_samples=2, metric='precomputed')
            cluster_labels = dbscan.fit_predict(distance_matrix)
            
            # Group files by clusters
            clusters = defaultdict(list)
            file_list = list(file_features.keys())
            
            for i, label in enumerate(cluster_labels):
                clusters[label].append(file_list[i])
            
            # Create cluster folders
            cluster_details = {}
            clusters_created = 0
            
            for label, files in clusters.items():
                if label == -1:  # Noise/outliers
                    if len(files) > 0:
                        outlier_folder = os.path.join(schema_folder, "Content_Outliers")
                        os.makedirs(outlier_folder, exist_ok=True)
                        
                        for file_path in files:
                            self.copy_file_to_folder(file_path, outlier_folder)
                        
                        cluster_details["Content_Outliers"] = len(files)
                        clusters_created += 1
                else:
                    # Group by transaction count within cluster
                    transaction_groups = defaultdict(list)
                    for file_path in files:
                        tx_count = file_transaction_counts.get(file_path, 1)
                        transaction_groups[tx_count].append(file_path)
                    
                    for tx_count, tx_files in transaction_groups.items():
                        cluster_name = f"All_Tag_Data_Matched_{tx_count}_tx"
                        cluster_folder = os.path.join(schema_folder, cluster_name)
                        os.makedirs(cluster_folder, exist_ok=True)
                        
                        for file_path in tx_files:
                            self.copy_file_to_folder(file_path, cluster_folder)
                        
                        cluster_details[cluster_name] = len(tx_files)
                        clusters_created += 1
                
                # Update progress
                progress = 60 + int((clusters_created / len(clusters)) * 40)
                self.update_progress(min(progress, 100))
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': len(xml_files),
                'clustersCreated': clusters_created,
                'anomaliesFound': len(clusters.get(-1, [])),  # Outliers as anomalies
                'outputPath': schema_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Tag and data cluster job failed: {e}")
            raise
    
    def count_transactions(self, root) -> int:
        """Count the number of transactions in the XML."""
        # Look for common transaction element names
        transaction_elements = [
            'DrctDbtTxInf',  # Direct Debit Transaction Information
            'CdtTrfTxInf',   # Credit Transfer Transaction Information
            'TxInf',         # Transaction Information
            'Transaction',   # Generic transaction
            'Payment',       # Payment
        ]
        
        max_count = 1
        for tx_element in transaction_elements:
            # Count elements with this name (case-insensitive)
            count = len([elem for elem in root.iter() if tx_element.lower() in elem.tag.lower()])
            max_count = max(max_count, count)
        
        return max_count
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0