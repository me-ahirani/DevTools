"""
Anomaly Cluster Job - Creates clusters based on payment anomalies.
Detects files with non-English characters, incorrect data types, and other anomalies.
"""

import os
import re
from collections import defaultdict
from typing import Dict, List, Any
from .base_job import BaseJob

class AnomalyClusterJob(BaseJob):
    """Job to create clusters based on payment anomalies."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute anomaly clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting anomaly cluster job")
        
        try:
            # Find the schema-based output folder (dependency)
            schema_name = self.get_schema_name_from_xsd()
            schema_folder_name = self.get_today_folder_name(schema_name)
            schema_folder = os.path.join(self.output_path, schema_folder_name)
            
            if not os.path.exists(schema_folder):
                raise ValueError(f"Schema cluster folder not found: {schema_folder}")
            
            # Get XML files from schema folder (only valid files)
            xml_files = self.get_xml_files(schema_folder)
            # Exclude files from subfolders created by other jobs
            xml_files = [f for f in xml_files if os.path.dirname(f) == schema_folder]
            
            self.logger.info(f"Found {len(xml_files)} XML files to process")
            
            if not xml_files:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': schema_folder,
                    'clusterDetails': {}
                }
            
            # Analyze files for anomalies
            anomaly_clusters = defaultdict(list)
            total_anomalies = 0
            
            for i, xml_file in enumerate(xml_files):
                try:
                    # Update progress
                    progress = int((i / len(xml_files)) * 100)
                    self.update_progress(progress)
                    
                    # Parse XML and extract content
                    root = self.parse_xml_file(xml_file)
                    if root is not None:
                        content = self.extract_xml_content(root)
                        anomalies = self.detect_comprehensive_anomalies(content, xml_file)
                        
                        if anomalies:
                            total_anomalies += len(anomalies)
                            # Categorize anomalies
                            for anomaly_type in anomalies:
                                anomaly_clusters[anomaly_type].append(xml_file)
                    
                except Exception as e:
                    self.logger.error(f"Error processing {xml_file}: {e}")
                    anomaly_clusters['processing_errors'].append(xml_file)
            
            # Create anomaly cluster folders
            cluster_details = {}
            clusters_created = 0
            
            for anomaly_type, files in anomaly_clusters.items():
                if files:
                    cluster_name = f"Anomaly_{anomaly_type}"
                    cluster_folder = os.path.join(schema_folder, cluster_name)
                    os.makedirs(cluster_folder, exist_ok=True)
                    
                    # Remove duplicates (file might have multiple anomaly types)
                    unique_files = list(set(files))
                    
                    for file_path in unique_files:
                        self.copy_file_to_folder(file_path, cluster_folder)
                    
                    cluster_details[cluster_name] = len(unique_files)
                    clusters_created += 1
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': len(xml_files),
                'clustersCreated': clusters_created,
                'anomaliesFound': total_anomalies,
                'outputPath': schema_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Anomaly cluster job failed: {e}")
            raise
    
    def detect_comprehensive_anomalies(self, content: Dict[str, Any], file_path: str) -> List[str]:
        """Detect comprehensive anomalies in XML content."""
        anomalies = []
        
        for path, value in content.items():
            if isinstance(value, str):
                # Check for non-English characters
                if self.has_non_english_characters(value):
                    anomalies.append('non_english_characters')
                
                # Check for specific character sets
                if self.has_chinese_characters(value):
                    anomalies.append('chinese_characters')
                
                if self.has_european_characters(value):
                    anomalies.append('european_characters')
                
                # Check for data type mismatches
                if self.is_amount_field(path):
                    if not self.is_valid_amount(value):
                        anomalies.append('invalid_amount_format')
                
                if self.is_date_field(path):
                    if not self.is_valid_date(value):
                        anomalies.append('invalid_date_format')
                
                if self.is_numeric_field(path):
                    if not self.is_valid_number(value):
                        anomalies.append('invalid_numeric_format')
                
                # Check for suspicious patterns
                if self.has_suspicious_patterns(value):
                    anomalies.append('suspicious_patterns')
                
                # Check for encoding issues
                if self.has_encoding_issues(value):
                    anomalies.append('encoding_issues')
        
        # Remove duplicates
        return list(set(anomalies))
    
    def has_non_english_characters(self, text: str) -> bool:
        """Check if text contains non-English characters."""
        return any(ord(char) > 127 for char in text)
    
    def has_chinese_characters(self, text: str) -> bool:
        """Check if text contains Chinese characters."""
        chinese_pattern = re.compile(r'[\u4e00-\u9fff]')
        return bool(chinese_pattern.search(text))
    
    def has_european_characters(self, text: str) -> bool:
        """Check if text contains European characters (accented, etc.)."""
        european_pattern = re.compile(r'[àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ]', re.IGNORECASE)
        return bool(european_pattern.search(text))
    
    def is_amount_field(self, path: str) -> bool:
        """Check if field is an amount field."""
        amount_keywords = ['amount', 'sum', 'total', 'balance', 'value', 'price', 'cost']
        return any(keyword in path.lower() for keyword in amount_keywords)
    
    def is_date_field(self, path: str) -> bool:
        """Check if field is a date field."""
        date_keywords = ['date', 'time', 'timestamp', 'created', 'modified', 'due']
        return any(keyword in path.lower() for keyword in date_keywords)
    
    def is_numeric_field(self, path: str) -> bool:
        """Check if field should be numeric."""
        numeric_keywords = ['id', 'number', 'count', 'sequence', 'index', 'code']
        return any(keyword in path.lower() for keyword in numeric_keywords)
    
    def is_valid_amount(self, value: str) -> bool:
        """Check if value is a valid amount."""
        try:
            # Remove common currency symbols and separators
            cleaned = re.sub(r'[€$£¥,\s]', '', value)
            float(cleaned)
            return True
        except ValueError:
            return False
    
    def is_valid_date(self, value: str) -> bool:
        """Check if value is a valid date."""
        date_patterns = [
            r'\d{4}-\d{2}-\d{2}',  # YYYY-MM-DD
            r'\d{2}/\d{2}/\d{4}',  # MM/DD/YYYY
            r'\d{2}\.\d{2}\.\d{4}', # DD.MM.YYYY
            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}',  # ISO datetime
        ]
        return any(re.match(pattern, value) for pattern in date_patterns)
    
    def is_valid_number(self, value: str) -> bool:
        """Check if value is a valid number."""
        try:
            int(value)
            return True
        except ValueError:
            return False
    
    def has_suspicious_patterns(self, value: str) -> bool:
        """Check for suspicious patterns in text."""
        suspicious_patterns = [
            r'<script',  # Script injection
            r'javascript:',  # JavaScript injection
            r'[\'\"]\s*or\s*[\'\"]\s*=\s*[\'\"]\s*[\'\"]\s*',  # SQL injection
            r'\.\./',  # Path traversal
            r'[^\x20-\x7E]',  # Non-printable characters
        ]
        return any(re.search(pattern, value, re.IGNORECASE) for pattern in suspicious_patterns)
    
    def has_encoding_issues(self, value: str) -> bool:
        """Check for encoding issues."""
        # Look for common encoding issue patterns
        encoding_issues = [
            '�',  # Replacement character
            '\ufffd',  # Unicode replacement character
            '\x00',  # Null character
        ]
        return any(issue in value for issue in encoding_issues)
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0