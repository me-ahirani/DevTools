"""
Tag Specific Cluster Job - Creates clusters based on specific tag values.
Groups files based on specific tag names like country, currency, etc.
"""

import os
from collections import defaultdict
from typing import Dict, List, Any
from .base_job import BaseJob

class TagSpecificClusterJob(BaseJob):
    """Job to create clusters based on specific tag values."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute tag-specific clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting tag-specific cluster job")
        
        try:
            # Find the schema-based output folder (dependency)
            schema_name = self.get_schema_name_from_xsd()
            schema_folder_name = self.get_today_folder_name(schema_name)
            schema_folder = os.path.join(self.output_path, schema_folder_name)
            
            if not os.path.exists(schema_folder):
                raise ValueError(f"Schema cluster folder not found: {schema_folder}")
            
            # Get XML files from schema folder (only valid files)
            xml_files = self.get_xml_files(schema_folder)
            # Exclude files from subfolders created by other jobs
            xml_files = [f for f in xml_files if os.path.dirname(f) == schema_folder]
            
            self.logger.info(f"Found {len(xml_files)} XML files to process")
            
            if not xml_files:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': schema_folder,
                    'clusterDetails': {}
                }
            
            # Define target tags to cluster by
            target_tags = {
                'country': ['Ctry', 'Country', 'CountryCode'],
                'currency': ['Ccy', 'Currency', 'CurrencyCode'],
                'amount': ['InstdAmt', 'Amount', 'Sum', 'CtrlSum'],
                'payment_method': ['PmtMtd', 'PaymentMethod'],
                'sequence_type': ['SeqTp', 'SequenceType'],
                'service_level': ['SvcLvl', 'ServiceLevel'],
            }
            
            # Extract tag values from all files
            tag_clusters = defaultdict(lambda: defaultdict(list))
            
            for i, xml_file in enumerate(xml_files):
                try:
                    # Update progress
                    progress = int((i / len(xml_files)) * 70)  # First 70% for analysis
                    self.update_progress(progress)
                    
                    # Parse XML and extract specific tag values
                    root = self.parse_xml_file(xml_file)
                    if root is not None:
                        tag_values = self.extract_specific_tag_values(root, target_tags)
                        
                        # Group files by tag values
                        for tag_category, value in tag_values.items():
                            if value:  # Only if value is found
                                tag_clusters[tag_category][value].append(xml_file)
                    
                except Exception as e:
                    self.logger.error(f"Error processing {xml_file}: {e}")
            
            # Create cluster folders
            cluster_details = {}
            clusters_created = 0
            
            for tag_category, value_groups in tag_clusters.items():
                for value, files in value_groups.items():
                    if len(files) > 1:  # Only create clusters for multiple files
                        # Clean value for folder name
                        clean_value = self.clean_folder_name(value)
                        cluster_name = f"Tag_{tag_category}_{clean_value}"
                        cluster_folder = os.path.join(schema_folder, cluster_name)
                        os.makedirs(cluster_folder, exist_ok=True)
                        
                        # Copy files to cluster
                        for file_path in files:
                            self.copy_file_to_folder(file_path, cluster_folder)
                        
                        cluster_details[cluster_name] = len(files)
                        clusters_created += 1
                        
                        # Update progress
                        progress = 70 + int((clusters_created / len(tag_clusters)) * 30)
                        self.update_progress(min(progress, 100))
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': len(xml_files),
                'clustersCreated': clusters_created,
                'anomaliesFound': 0,
                'outputPath': schema_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Tag-specific cluster job failed: {e}")
            raise
    
    def extract_specific_tag_values(self, root, target_tags: Dict[str, List[str]]) -> Dict[str, str]:
        """Extract values for specific tags from XML."""
        tag_values = {}
        
        for category, tag_names in target_tags.items():
            value = None
            
            # Search for any of the tag names in this category
            for tag_name in tag_names:
                elements = self.find_elements_by_tag(root, tag_name)
                if elements:
                    # Get the first non-empty value
                    for element in elements:
                        if element.text and element.text.strip():
                            value = element.text.strip()
                            break
                        # Check attributes
                        for attr_value in element.attrib.values():
                            if attr_value and attr_value.strip():
                                value = attr_value.strip()
                                break
                        if value:
                            break
                    if value:
                        break
            
            if value:
                tag_values[category] = value
        
        return tag_values
    
    def find_elements_by_tag(self, root, tag_name: str) -> List:
        """Find all elements with a specific tag name (case-insensitive)."""
        elements = []
        
        for element in root.iter():
            # Remove namespace prefix for comparison
            element_tag = element.tag.split('}')[-1] if '}' in element.tag else element.tag
            if element_tag.lower() == tag_name.lower():
                elements.append(element)
        
        return elements
    
    def clean_folder_name(self, value: str) -> str:
        """Clean value to be safe for folder name."""
        import re
        # Remove or replace unsafe characters
        clean_value = re.sub(r'[<>:"/\\|?*]', '_', value)
        # Limit length
        clean_value = clean_value[:50]
        # Remove leading/trailing spaces and dots
        clean_value = clean_value.strip('. ')
        return clean_value or 'unknown'
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0