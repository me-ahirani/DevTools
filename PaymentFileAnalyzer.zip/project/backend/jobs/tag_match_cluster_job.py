"""
Tag Match Cluster Job - Creates clusters based on XML tag structure matching.
Groups files that have the same XML structure (tags) regardless of content.
"""

import os
from collections import defaultdict
from typing import Dict, List, Any
from .base_job import BaseJob

class TagMatchClusterJob(BaseJob):
    """Job to create clusters based on XML tag structure matching."""
    
    def execute(self) -> Dict[str, Any]:
        """Execute tag match clustering job."""
        self.start_time = self.get_current_time()
        self.logger.info("Starting tag match cluster job")
        
        try:
            # Find the schema-based output folder (dependency)
            schema_name = self.get_schema_name_from_xsd()
            schema_folder_name = self.get_today_folder_name(schema_name)
            schema_folder = os.path.join(self.output_path, schema_folder_name)
            
            if not os.path.exists(schema_folder):
                raise ValueError(f"Schema cluster folder not found: {schema_folder}")
            
            # Get XML files from schema folder (only valid files)
            xml_files = self.get_xml_files(schema_folder)
            # Exclude files from invalid_files subfolder
            xml_files = [f for f in xml_files if 'invalid_files' not in f]
            
            self.logger.info(f"Found {len(xml_files)} valid XML files to process")
            
            if not xml_files:
                return {
                    'filesProcessed': 0,
                    'clustersCreated': 0,
                    'anomaliesFound': 0,
                    'outputPath': schema_folder,
                    'clusterDetails': {}
                }
            
            # Extract tag structures from all files
            file_tag_structures = {}
            tag_structure_groups = defaultdict(list)
            
            for i, xml_file in enumerate(xml_files):
                try:
                    # Update progress
                    progress = int((i / len(xml_files)) * 50)  # First 50% for analysis
                    self.update_progress(progress)
                    
                    # Parse XML and extract tags
                    root = self.parse_xml_file(xml_file)
                    if root is not None:
                        tags = self.extract_xml_tags(root)
                        # Create a signature from sorted unique tags
                        tag_signature = tuple(sorted(set(tags)))
                        file_tag_structures[xml_file] = tag_signature
                        tag_structure_groups[tag_signature].append(xml_file)
                    
                except Exception as e:
                    self.logger.error(f"Error processing {xml_file}: {e}")
            
            # Create clusters for matched tag structures
            cluster_details = {}
            clusters_created = 0
            
            for tag_signature, files in tag_structure_groups.items():
                if len(files) > 1:  # Only create clusters for multiple files
                    # Create cluster folder
                    cluster_name = f"All_Tag_Matched_{len(files)}_files"
                    cluster_folder = os.path.join(schema_folder, cluster_name)
                    os.makedirs(cluster_folder, exist_ok=True)
                    
                    # Copy files to cluster
                    for file_path in files:
                        self.copy_file_to_folder(file_path, cluster_folder)
                    
                    cluster_details[cluster_name] = len(files)
                    clusters_created += 1
                    
                    # Update progress
                    progress = 50 + int((clusters_created / len(tag_structure_groups)) * 50)
                    self.update_progress(progress)
            
            # Handle single files (unique structures)
            single_files = [files[0] for files in tag_structure_groups.values() if len(files) == 1]
            if single_files:
                unique_folder = os.path.join(schema_folder, "Unique_Tag_Structures")
                os.makedirs(unique_folder, exist_ok=True)
                
                for file_path in single_files:
                    self.copy_file_to_folder(file_path, unique_folder)
                
                cluster_details["Unique_Tag_Structures"] = len(single_files)
                clusters_created += 1
            
            self.update_progress(100)
            self.end_time = self.get_current_time()
            
            return {
                'filesProcessed': len(xml_files),
                'clustersCreated': clusters_created,
                'anomaliesFound': 0,
                'outputPath': schema_folder,
                'clusterDetails': cluster_details,
                'processingTime': self.get_processing_time()
            }
            
        except Exception as e:
            self.logger.error(f"Tag match cluster job failed: {e}")
            raise
    
    def get_current_time(self):
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now()
    
    def get_processing_time(self):
        """Get processing time in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0