"""
Base Job class for payment file analysis jobs.
Provides common functionality and interface for all job types.
"""

import os
import logging
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime
import shutil

class BaseJob(ABC):
    """Base class for all payment file analysis jobs."""
    
    def __init__(self, configuration: Dict[str, Any]):
        self.configuration = configuration
        self.logger = logging.getLogger(self.__class__.__name__)
        self.progress = 0
        self.start_time = None
        self.end_time = None
        
        # Extract common configuration
        self.test_suite_path = configuration.get('testSuitePath', './Test_Suite')
        self.xsd_path = configuration.get('xsdPath', '')
        self.output_path = configuration.get('outputPath', './Test_Suite/output')
        self.uniqueness_threshold = configuration.get('uniquenessThreshold', 0.8)
        
        # Ensure output directory exists
        os.makedirs(self.output_path, exist_ok=True)
    
    @abstractmethod
    def execute(self) -> Dict[str, Any]:
        """
        Execute the job and return results.
        
        Returns:
            Dictionary containing job results
        """
        pass
    
    def update_progress(self, progress: int):
        """Update job progress (0-100)."""
        self.progress = min(100, max(0, progress))
        self.logger.info(f"Progress: {self.progress}%")
    
    def get_xml_files(self, directory: str) -> List[str]:
        """Get all XML files from a directory."""
        xml_files = []
        if os.path.exists(directory):
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if file.lower().endswith('.xml'):
                        xml_files.append(os.path.join(root, file))
        return xml_files
    
    def parse_xml_file(self, file_path: str) -> Optional[ET.Element]:
        """Parse XML file and return root element."""
        try:
            tree = ET.parse(file_path)
            return tree.getroot()
        except Exception as e:
            self.logger.error(f"Failed to parse XML file {file_path}: {e}")
            return None
    
    def extract_xml_tags(self, root: ET.Element) -> List[str]:
        """Extract all tag names from XML element."""
        tags = []
        
        def extract_tags_recursive(element):
            # Remove namespace prefix for comparison
            tag_name = element.tag.split('}')[-1] if '}' in element.tag else element.tag
            tags.append(tag_name)
            
            for child in element:
                extract_tags_recursive(child)
        
        extract_tags_recursive(root)
        return tags
    
    def extract_xml_content(self, root: ET.Element) -> Dict[str, Any]:
        """Extract content from XML element."""
        content = {}
        
        def extract_content_recursive(element, path=""):
            # Remove namespace prefix
            tag_name = element.tag.split('}')[-1] if '}' in element.tag else element.tag
            current_path = f"{path}/{tag_name}" if path else tag_name
            
            # Store text content if present
            if element.text and element.text.strip():
                content[current_path] = element.text.strip()
            
            # Store attributes
            for attr_name, attr_value in element.attrib.items():
                attr_path = f"{current_path}@{attr_name}"
                content[attr_path] = attr_value
            
            # Process children
            for child in element:
                extract_content_recursive(child, current_path)
        
        extract_content_recursive(root)
        return content
    
    def create_output_folder(self, folder_name: str) -> str:
        """Create output folder and return path."""
        folder_path = os.path.join(self.output_path, folder_name)
        os.makedirs(folder_path, exist_ok=True)
        return folder_path
    
    def copy_file_to_folder(self, source_file: str, destination_folder: str) -> bool:
        """Copy file to destination folder."""
        try:
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder, exist_ok=True)
            
            filename = os.path.basename(source_file)
            destination_path = os.path.join(destination_folder, filename)
            shutil.copy2(source_file, destination_path)
            return True
        except Exception as e:
            self.logger.error(f"Failed to copy file {source_file} to {destination_folder}: {e}")
            return False
    
    def get_schema_name_from_xsd(self) -> str:
        """Extract schema name from XSD file."""
        if not self.xsd_path or not os.path.exists(self.xsd_path):
            return "unknown_schema"
        
        try:
            tree = ET.parse(self.xsd_path)
            root = tree.getroot()
            
            # Try to get target namespace or schema name
            target_namespace = root.get('targetNamespace', '')
            if target_namespace:
                # Extract meaningful name from namespace
                parts = target_namespace.split('/')
                for part in reversed(parts):
                    if part and not part.startswith('http'):
                        return part.replace(':', '_').replace('.', '_')
            
            # Fallback to filename
            return os.path.splitext(os.path.basename(self.xsd_path))[0]
        except Exception as e:
            self.logger.error(f"Failed to extract schema name: {e}")
            return "unknown_schema"
    
    def detect_anomalies(self, content: Dict[str, Any]) -> List[str]:
        """Detect anomalies in XML content."""
        anomalies = []
        
        for path, value in content.items():
            if isinstance(value, str):
                # Check for non-English characters
                if any(ord(char) > 127 for char in value):
                    anomalies.append(f"Non-English characters in {path}: {value}")
                
                # Check for potential data type mismatches
                if 'amount' in path.lower() or 'sum' in path.lower():
                    try:
                        float(value.replace(',', ''))
                    except ValueError:
                        anomalies.append(f"Invalid amount format in {path}: {value}")
                
                if 'date' in path.lower():
                    # Basic date format check
                    if not any(sep in value for sep in ['-', '/', '.']):
                        anomalies.append(f"Invalid date format in {path}: {value}")
        
        return anomalies
    
    def calculate_similarity(self, tags1: List[str], tags2: List[str]) -> float:
        """Calculate cosine similarity between two tag lists."""
        from collections import Counter
        import math
        
        # Convert to counters for frequency analysis
        counter1 = Counter(tags1)
        counter2 = Counter(tags2)
        
        # Get all unique tags
        all_tags = set(counter1.keys()) | set(counter2.keys())
        
        # Create vectors
        vector1 = [counter1.get(tag, 0) for tag in all_tags]
        vector2 = [counter2.get(tag, 0) for tag in all_tags]
        
        # Calculate cosine similarity
        dot_product = sum(a * b for a, b in zip(vector1, vector2))
        magnitude1 = math.sqrt(sum(a * a for a in vector1))
        magnitude2 = math.sqrt(sum(b * b for b in vector2))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def get_today_folder_name(self, prefix: str) -> str:
        """Get folder name with today's date."""
        today = datetime.now().strftime("%Y%m%d")
        return f"{prefix}_{today}"