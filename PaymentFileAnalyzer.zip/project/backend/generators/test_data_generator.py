"""
Test Data Generator module for creating XML files based on XSD schemas.
Generates files with various criteria including random data, mandatory fields only, 
multiple occurrences, and anomalies.
"""

import os
import random
import string
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any, Generator
import xmlschema
from lxml import etree
import logging

class TestDataGenerator:
    """Generates test XML files based on XSD schema with various criteria."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.generated_files = []
        self.output_dir = "generated"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def generate_test_files(self, xsd_path: str, criteria: Dict[str, Any]) -> Generator[Dict[str, Any], None, None]:
        """
        Generate test files based on the provided criteria.
        
        Args:
            xsd_path: Path to the XSD schema file
            criteria: Dictionary containing generation criteria
            
        Yields:
            Progress updates and file information
        """
        try:
            # Clear previous generated files
            self.generated_files = []
            self._cleanup_generated_files()
            
            # Load schema
            schema = xmlschema.XMLSchema(xsd_path)
            
            # Calculate total files to generate
            total_files = (
                criteria.get('randomData', 0) +
                criteria.get('mandatoryOnly', 0) +
                criteria.get('multipleOccurrence', 0) +
                criteria.get('anomalies', 0)
            )
            
            # Default to 25 random data files if no criteria specified
            if total_files == 0:
                criteria['randomData'] = 25
                total_files = 25
            
            generated_count = 0
            
            # Generate random data files
            for i in range(criteria.get('randomData', 0)):
                file_info = self._generate_random_file(schema, i + 1)
                self.generated_files.append(file_info)
                generated_count += 1
                
                yield {
                    "type": "progress",
                    "progress": (generated_count / total_files) * 100
                }
                yield {
                    "type": "file",
                    "file": file_info
                }
            
            # Generate mandatory only files
            for i in range(criteria.get('mandatoryOnly', 0)):
                file_info = self._generate_mandatory_only_file(schema, i + 1)
                self.generated_files.append(file_info)
                generated_count += 1
                
                yield {
                    "type": "progress",
                    "progress": (generated_count / total_files) * 100
                }
                yield {
                    "type": "file",
                    "file": file_info
                }
            
            # Generate multiple occurrence files
            for i in range(criteria.get('multipleOccurrence', 0)):
                file_info = self._generate_multiple_occurrence_file(
                    schema, i + 1, criteria.get('selectedTags', [])
                )
                self.generated_files.append(file_info)
                generated_count += 1
                
                yield {
                    "type": "progress",
                    "progress": (generated_count / total_files) * 100
                }
                yield {
                    "type": "file",
                    "file": file_info
                }
            
            # Generate anomaly files
            for i in range(criteria.get('anomalies', 0)):
                file_info = self._generate_anomaly_file(schema, i + 1)
                self.generated_files.append(file_info)
                generated_count += 1
                
                yield {
                    "type": "progress",
                    "progress": (generated_count / total_files) * 100
                }
                yield {
                    "type": "file",
                    "file": file_info
                }
                
        except Exception as e:
            self.logger.error(f"File generation failed: {e}")
            yield {
                "type": "error",
                "error": str(e)
            }
    
    def _generate_random_file(self, schema: xmlschema.XMLSchema, file_number: int) -> Dict[str, Any]:
        """Generate a file with random data based on schema."""
        try:
            # Get root element
            root_element = next(iter(schema.elements.values()))
            
            # Create XML with random data
            xml_data = self._create_random_element(root_element)
            
            # Create file
            file_info = self._save_xml_file(xml_data, f"random_data_{file_number:03d}.xml", "Random Data")
            return file_info
            
        except Exception as e:
            self.logger.error(f"Failed to generate random file {file_number}: {e}")
            raise
    
    def _generate_mandatory_only_file(self, schema: xmlschema.XMLSchema, file_number: int) -> Dict[str, Any]:
        """Generate a file with only mandatory fields."""
        try:
            # Get root element
            root_element = next(iter(schema.elements.values()))
            
            # Create XML with only mandatory elements
            xml_data = self._create_mandatory_element(root_element)
            
            # Create file
            file_info = self._save_xml_file(xml_data, f"mandatory_only_{file_number:03d}.xml", "Mandatory Only")
            return file_info
            
        except Exception as e:
            self.logger.error(f"Failed to generate mandatory file {file_number}: {e}")
            raise
    
    def _generate_multiple_occurrence_file(self, schema: xmlschema.XMLSchema, file_number: int, selected_tags: List[str]) -> Dict[str, Any]:
        """Generate a file with multiple occurrences of specified tags."""
        try:
            # Get root element
            root_element = next(iter(schema.elements.values()))
            
            # Create XML with multiple occurrences
            xml_data = self._create_multiple_occurrence_element(root_element, selected_tags)
            
            # Create file
            file_info = self._save_xml_file(xml_data, f"multiple_occurrence_{file_number:03d}.xml", "Multiple Occurrence")
            return file_info
            
        except Exception as e:
            self.logger.error(f"Failed to generate multiple occurrence file {file_number}: {e}")
            raise
    
    def _generate_anomaly_file(self, schema: xmlschema.XMLSchema, file_number: int) -> Dict[str, Any]:
        """Generate a file with intentional anomalies."""
        try:
            # Get root element
            root_element = next(iter(schema.elements.values()))
            
            # Create XML with anomalies
            xml_data = self._create_anomaly_element(root_element)
            
            # Create file
            file_info = self._save_xml_file(xml_data, f"anomaly_{file_number:03d}.xml", "Anomaly")
            return file_info
            
        except Exception as e:
            self.logger.error(f"Failed to generate anomaly file {file_number}: {e}")
            raise
    
    def _create_random_element(self, element) -> etree.Element:
        """Create an XML element with random data."""
        elem = etree.Element(element.local_name)
        
        if hasattr(element, 'type') and element.type:
            if hasattr(element.type, 'content_type'):
                # Complex type with child elements
                if hasattr(element.type.content_type, 'iter_elements'):
                    for child_element in element.type.content_type.iter_elements():
                        if hasattr(child_element, 'local_name'):
                            child_elem = self._create_random_element(child_element)
                            elem.append(child_elem)
            else:
                # Simple type with text content
                elem.text = self._generate_random_value(element.type)
        
        return elem
    
    def _create_mandatory_element(self, element) -> etree.Element:
        """Create an XML element with only mandatory fields."""
        elem = etree.Element(element.local_name)
        
        if hasattr(element, 'type') and element.type:
            if hasattr(element.type, 'content_type'):
                # Complex type with child elements
                if hasattr(element.type.content_type, 'iter_elements'):
                    for child_element in element.type.content_type.iter_elements():
                        # Only include if min_occurs > 0 (mandatory)
                        if getattr(child_element, 'min_occurs', 0) > 0:
                            child_elem = self._create_mandatory_element(child_element)
                            elem.append(child_elem)
            else:
                # Simple type with text content
                elem.text = self._generate_random_value(element.type)
        
        return elem
    
    def _create_multiple_occurrence_element(self, element, selected_tags: List[str]) -> etree.Element:
        """Create an XML element with multiple occurrences of selected tags."""
        elem = etree.Element(element.local_name)
        
        if hasattr(element, 'type') and element.type:
            if hasattr(element.type, 'content_type'):
                # Complex type with child elements
                if hasattr(element.type.content_type, 'iter_elements'):
                    for child_element in element.type.content_type.iter_elements():
                        if hasattr(child_element, 'local_name'):
                            # Check if this element should have multiple occurrences
                            max_occurs = getattr(child_element, 'max_occurs', 1)
                            if (child_element.local_name in selected_tags and 
                                max_occurs and max_occurs != 1):
                                # Generate multiple occurrences
                                count = random.randint(2, min(5, max_occurs if max_occurs != 'unbounded' else 5))
                                for _ in range(count):
                                    child_elem = self._create_random_element(child_element)
                                    elem.append(child_elem)
                            else:
                                child_elem = self._create_random_element(child_element)
                                elem.append(child_elem)
            else:
                # Simple type with text content
                elem.text = self._generate_random_value(element.type)
        
        return elem
    
    def _create_anomaly_element(self, element) -> etree.Element:
        """Create an XML element with intentional anomalies."""
        elem = etree.Element(element.local_name)
        
        if hasattr(element, 'type') and element.type:
            if hasattr(element.type, 'content_type'):
                # Complex type with child elements
                if hasattr(element.type.content_type, 'iter_elements'):
                    for child_element in element.type.content_type.iter_elements():
                        if hasattr(child_element, 'local_name'):
                            child_elem = self._create_anomaly_element(child_element)
                            elem.append(child_elem)
            else:
                # Simple type with anomalous text content
                elem.text = self._generate_anomaly_value(element.type)
        
        return elem
    
    def _generate_random_value(self, type_obj) -> str:
        """Generate a random value based on the XSD type."""
        if hasattr(type_obj, 'python_type'):
            if type_obj.python_type == str:
                return self._generate_random_string()
            elif type_obj.python_type == int:
                return str(random.randint(1, 999999))
            elif type_obj.python_type == float:
                return f"{random.uniform(0.01, 999999.99):.2f}"
            elif type_obj.python_type == bool:
                return random.choice(['true', 'false'])
        
        # Default to random string
        return self._generate_random_string()
    
    def _generate_anomaly_value(self, type_obj) -> str:
        """Generate an anomalous value that might cause validation issues."""
        anomaly_types = [
            # Non-English characters
            lambda: '测试数据' + self._generate_random_string(5),
            # Special characters
            lambda: '@#$%^&*()' + self._generate_random_string(5),
            # Very long strings
            lambda: self._generate_random_string(1000),
            # Empty string where not allowed
            lambda: '',
            # Invalid number formats
            lambda: 'not_a_number_123',
            # Invalid dates
            lambda: '2024-13-45T25:70:80',
        ]
        
        return random.choice(anomaly_types)()
    
    def _generate_random_string(self, length: int = None) -> str:
        """Generate a random string of specified length."""
        if length is None:
            length = random.randint(5, 20)
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    
    def _save_xml_file(self, xml_element: etree.Element, filename: str, file_type: str) -> Dict[str, Any]:
        """Save XML element to file and return file information."""
        file_id = str(uuid.uuid4())
        file_path = os.path.join(self.output_dir, filename)
        
        # Create XML tree and save
        tree = etree.ElementTree(xml_element)
        tree.write(file_path, pretty_print=True, xml_declaration=True, encoding='utf-8')
        
        # Get file size
        file_size = os.path.getsize(file_path)
        
        return {
            "id": file_id,
            "name": filename,
            "type": file_type,
            "size": file_size,
            "downloadUrl": f"/api/download/{file_id}",
            "created": datetime.now().isoformat(),
            "path": file_path
        }
    
    def _cleanup_generated_files(self):
        """Remove previously generated files."""
        try:
            for file_path in os.listdir(self.output_dir):
                full_path = os.path.join(self.output_dir, file_path)
                if os.path.isfile(full_path):
                    os.remove(full_path)
        except Exception as e:
            self.logger.warning(f"Failed to cleanup generated files: {e}")
    
    def get_generated_files(self) -> List[Dict[str, Any]]:
        """Get list of all generated files."""
        return self.generated_files