"""
XSD Analyzer module for analyzing XSD schema files.
Complete line-by-line parsing to extract all elements, types, and occurrence patterns.
"""

import logging
from typing import Dict, List, Any, Optional, Set, Tuple
import xml.etree.ElementTree as ET
from lxml import etree
import re

class XSDElement:
    """Represents an XSD element with all its properties."""
    
    def __init__(self, name: str, element_type: str = "string"):
        self.name = name
        self.element_type = element_type
        self.min_occurs = 1
        self.max_occurs = 1
        self.is_complex = False
        self.is_simple = True
        self.is_mandatory = True
        self.is_optional = False
        self.can_be_multiple = False
        self.path = ""
        self.parent = None
        self.children = []
        self.attributes = []
        self.restrictions = {}
        self.documentation = ""
        self.namespace = ""
        self.line_number = 0

class XSDAnalyzer:
    """Analyzes XSD schema files to extract complete structural information."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.elements = {}  # All elements found
        self.complex_types = {}  # Complex type definitions
        self.simple_types = {}  # Simple type definitions
        self.namespaces = {}  # Namespace mappings
        self.target_namespace = ""
        self.root_elements = []
        self.multiple_occurrence_elements = []
        self.mandatory_elements = []
        self.optional_elements = []
        
    def analyze_schema(self, xsd_path: str) -> Dict[str, Any]:
        """
        Analyze an XSD schema file completely.
        
        Args:
            xsd_path: Path to the XSD schema file
            
        Returns:
            Dictionary containing complete schema analysis results
        """
        try:
            self.logger.info(f"Starting comprehensive XSD analysis of: {xsd_path}")
            
            # Reset all collections
            self._reset_analysis_data()
            
            # Parse the XSD file line by line
            self._parse_xsd_file(xsd_path)
            
            # Build element relationships and hierarchy
            self._build_element_hierarchy()
            
            # Analyze occurrence patterns
            self._analyze_occurrence_patterns()
            
            # Generate comprehensive results
            results = self._generate_analysis_results()
            
            self.logger.info(f"Analysis complete. Found {len(self.elements)} elements, "
                           f"{len(self.multiple_occurrence_elements)} with multiple occurrences")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Schema analysis failed: {e}", exc_info=True)
            return {
                "error": str(e),
                "multipleOccurrenceTags": [],
                "statistics": {},
                "hierarchy": {},
                "allElements": [],
                "mandatoryElements": [],
                "optionalElements": []
            }
    
    def _reset_analysis_data(self):
        """Reset all analysis data structures."""
        self.elements = {}
        self.complex_types = {}
        self.simple_types = {}
        self.namespaces = {}
        self.target_namespace = ""
        self.root_elements = []
        self.multiple_occurrence_elements = []
        self.mandatory_elements = []
        self.optional_elements = []
    
    def _parse_xsd_file(self, xsd_path: str):
        """Parse XSD file line by line to extract all information."""
        try:
            # Parse with lxml for better namespace handling
            tree = etree.parse(xsd_path)
            root = tree.getroot()
            
            # Extract namespaces
            self.namespaces = dict(root.nsmap) if root.nsmap else {}
            self.target_namespace = root.get('targetNamespace', '')
            
            self.logger.info(f"Target namespace: {self.target_namespace}")
            self.logger.info(f"Namespaces found: {self.namespaces}")
            
            # Process the entire schema recursively
            self._process_schema_element(root, "", 0)
            
        except Exception as e:
            self.logger.error(f"Failed to parse XSD file: {e}")
            raise
    
    def _process_schema_element(self, element, current_path: str, depth: int):
        """Recursively process each element in the schema."""
        if depth > 50:  # Prevent infinite recursion
            return
        
        tag_name = self._get_local_name(element.tag)
        
        # Process different types of schema elements
        if tag_name == 'schema':
            self._process_schema_root(element, current_path, depth)
        elif tag_name == 'element':
            self._process_element_definition(element, current_path, depth)
        elif tag_name == 'complexType':
            self._process_complex_type(element, current_path, depth)
        elif tag_name == 'simpleType':
            self._process_simple_type(element, current_path, depth)
        elif tag_name in ['sequence', 'choice', 'all']:
            self._process_container(element, current_path, depth)
        elif tag_name == 'group':
            self._process_group(element, current_path, depth)
        elif tag_name == 'attribute':
            self._process_attribute(element, current_path, depth)
        
        # Process all child elements
        for child in element:
            self._process_schema_element(child, current_path, depth + 1)
    
    def _process_schema_root(self, element, current_path: str, depth: int):
        """Process the root schema element."""
        self.target_namespace = element.get('targetNamespace', self.target_namespace)
        
        # Find direct child elements (root elements)
        for child in element:
            if self._get_local_name(child.tag) == 'element':
                element_name = child.get('name')
                if element_name:
                    self.root_elements.append(element_name)
                    self.logger.debug(f"Found root element: {element_name}")
    
    def _process_element_definition(self, element, current_path: str, depth: int):
        """Process an element definition."""
        element_name = element.get('name')
        if not element_name:
            return
        
        # Create XSD element object
        xsd_element = XSDElement(element_name)
        xsd_element.path = f"{current_path}/{element_name}" if current_path else element_name
        xsd_element.line_number = getattr(element, 'sourceline', 0)
        
        # Parse occurrence attributes
        min_occurs = element.get('minOccurs', '1')
        max_occurs = element.get('maxOccurs', '1')
        
        try:
            xsd_element.min_occurs = int(min_occurs) if min_occurs.isdigit() else 0
        except:
            xsd_element.min_occurs = 1
        
        if max_occurs == 'unbounded':
            xsd_element.max_occurs = 'unbounded'
            xsd_element.can_be_multiple = True
        else:
            try:
                max_val = int(max_occurs) if max_occurs.isdigit() else 1
                xsd_element.max_occurs = max_val
                xsd_element.can_be_multiple = max_val > 1
            except:
                xsd_element.max_occurs = 1
        
        # Determine if mandatory or optional
        xsd_element.is_mandatory = xsd_element.min_occurs > 0
        xsd_element.is_optional = xsd_element.min_occurs == 0
        
        # Get element type
        element_type = element.get('type', 'xs:string')
        xsd_element.element_type = element_type
        
        # Check if element has inline type definition
        inline_complex = element.find('.//{http://www.w3.org/2001/XMLSchema}complexType')
        inline_simple = element.find('.//{http://www.w3.org/2001/XMLSchema}simpleType')
        
        if inline_complex is not None:
            xsd_element.is_complex = True
            xsd_element.is_simple = False
        elif inline_simple is not None:
            xsd_element.is_simple = True
            xsd_element.is_complex = False
        else:
            # Determine based on type name
            xsd_element.is_simple = self._is_simple_type(element_type)
            xsd_element.is_complex = not xsd_element.is_simple
        
        # Extract documentation
        doc_element = element.find('.//{http://www.w3.org/2001/XMLSchema}documentation')
        if doc_element is not None and doc_element.text:
            xsd_element.documentation = doc_element.text.strip()
        
        # Store element
        self.elements[element_name] = xsd_element
        
        # Categorize elements
        if xsd_element.can_be_multiple:
            self.multiple_occurrence_elements.append(xsd_element)
        
        if xsd_element.is_mandatory:
            self.mandatory_elements.append(xsd_element)
        
        if xsd_element.is_optional:
            self.optional_elements.append(xsd_element)
        
        self.logger.debug(f"Processed element: {element_name} "
                         f"(min: {xsd_element.min_occurs}, max: {xsd_element.max_occurs}, "
                         f"type: {element_type}, complex: {xsd_element.is_complex})")
    
    def _process_complex_type(self, element, current_path: str, depth: int):
        """Process a complex type definition."""
        type_name = element.get('name')
        if type_name:
            self.complex_types[type_name] = {
                'name': type_name,
                'path': current_path,
                'elements': [],
                'attributes': []
            }
            self.logger.debug(f"Found complex type: {type_name}")
    
    def _process_simple_type(self, element, current_path: str, depth: int):
        """Process a simple type definition."""
        type_name = element.get('name')
        if type_name:
            # Extract restrictions
            restrictions = {}
            restriction = element.find('.//{http://www.w3.org/2001/XMLSchema}restriction')
            if restriction is not None:
                base_type = restriction.get('base', 'xs:string')
                restrictions['base'] = base_type
                
                # Extract enumeration values
                enums = restriction.findall('.//{http://www.w3.org/2001/XMLSchema}enumeration')
                if enums:
                    restrictions['enumerations'] = [enum.get('value') for enum in enums]
                
                # Extract pattern
                pattern = restriction.find('.//{http://www.w3.org/2001/XMLSchema}pattern')
                if pattern is not None:
                    restrictions['pattern'] = pattern.get('value')
                
                # Extract length restrictions
                min_length = restriction.find('.//{http://www.w3.org/2001/XMLSchema}minLength')
                if min_length is not None:
                    restrictions['minLength'] = int(min_length.get('value', '0'))
                
                max_length = restriction.find('.//{http://www.w3.org/2001/XMLSchema}maxLength')
                if max_length is not None:
                    restrictions['maxLength'] = int(max_length.get('value', '100'))
            
            self.simple_types[type_name] = {
                'name': type_name,
                'path': current_path,
                'restrictions': restrictions
            }
            self.logger.debug(f"Found simple type: {type_name} with restrictions: {restrictions}")
    
    def _process_container(self, element, current_path: str, depth: int):
        """Process sequence, choice, or all containers."""
        container_type = self._get_local_name(element.tag)
        
        # Check if container itself has multiple occurrences
        min_occurs = element.get('minOccurs', '1')
        max_occurs = element.get('maxOccurs', '1')
        
        container_multiple = False
        if max_occurs == 'unbounded' or (max_occurs.isdigit() and int(max_occurs) > 1):
            container_multiple = True
        
        if container_multiple:
            self.logger.debug(f"Found {container_type} container with multiple occurrences: "
                            f"min={min_occurs}, max={max_occurs}")
            
            # All child elements in this container effectively have multiple occurrences
            child_elements = element.findall('.//{http://www.w3.org/2001/XMLSchema}element[@name]')
            for child_elem in child_elements:
                child_name = child_elem.get('name')
                if child_name and child_name not in self.elements:
                    # Create element with inherited multiple occurrence
                    xsd_element = XSDElement(child_name)
                    xsd_element.path = f"{current_path}/{child_name}" if current_path else child_name
                    xsd_element.min_occurs = int(min_occurs) if min_occurs.isdigit() else 1
                    xsd_element.max_occurs = max_occurs
                    xsd_element.can_be_multiple = True
                    xsd_element.is_mandatory = xsd_element.min_occurs > 0
                    xsd_element.is_optional = xsd_element.min_occurs == 0
                    
                    self.elements[child_name] = xsd_element
                    self.multiple_occurrence_elements.append(xsd_element)
                    
                    self.logger.debug(f"Added child element with inherited multiple occurrence: {child_name}")
    
    def _process_group(self, element, current_path: str, depth: int):
        """Process group definitions."""
        group_name = element.get('name') or element.get('ref')
        if group_name:
            self.logger.debug(f"Found group: {group_name}")
    
    def _process_attribute(self, element, current_path: str, depth: int):
        """Process attribute definitions."""
        attr_name = element.get('name')
        if attr_name:
            use = element.get('use', 'optional')
            attr_type = element.get('type', 'xs:string')
            self.logger.debug(f"Found attribute: {attr_name} (use: {use}, type: {attr_type})")
    
    def _build_element_hierarchy(self):
        """Build parent-child relationships between elements."""
        # This would require more complex parsing to track element nesting
        # For now, we'll use the path information
        for element_name, element_obj in self.elements.items():
            path_parts = element_obj.path.split('/')
            if len(path_parts) > 1:
                parent_name = path_parts[-2]
                if parent_name in self.elements:
                    element_obj.parent = parent_name
                    if element_name not in self.elements[parent_name].children:
                        self.elements[parent_name].children.append(element_name)
    
    def _analyze_occurrence_patterns(self):
        """Analyze and categorize occurrence patterns."""
        # Additional analysis can be added here
        # For example, detecting common patterns, validating constraints, etc.
        
        # Log summary
        self.logger.info(f"Occurrence analysis complete:")
        self.logger.info(f"  - Total elements: {len(self.elements)}")
        self.logger.info(f"  - Multiple occurrence elements: {len(self.multiple_occurrence_elements)}")
        self.logger.info(f"  - Mandatory elements: {len(self.mandatory_elements)}")
        self.logger.info(f"  - Optional elements: {len(self.optional_elements)}")
        self.logger.info(f"  - Complex types: {len(self.complex_types)}")
        self.logger.info(f"  - Simple types: {len(self.simple_types)}")
    
    def _generate_analysis_results(self) -> Dict[str, Any]:
        """Generate comprehensive analysis results."""
        
        # Prepare multiple occurrence tags
        multiple_occurrence_tags = []
        for element in self.multiple_occurrence_elements:
            multiple_occurrence_tags.append({
                "name": element.name,
                "path": element.path,
                "minOccurs": element.min_occurs,
                "maxOccurs": element.max_occurs,
                "type": element.element_type,
                "isComplex": element.is_complex,
                "isSimple": element.is_simple,
                "isMandatory": element.is_mandatory,
                "documentation": element.documentation
            })
        
        # Prepare all elements
        all_elements = []
        for element_name, element in self.elements.items():
            all_elements.append({
                "name": element.name,
                "path": element.path,
                "type": element.element_type,
                "minOccurs": element.min_occurs,
                "maxOccurs": element.max_occurs,
                "isComplex": element.is_complex,
                "isSimple": element.is_simple,
                "isMandatory": element.is_mandatory,
                "isOptional": element.is_optional,
                "canBeMultiple": element.can_be_multiple,
                "children": element.children,
                "parent": element.parent,
                "documentation": element.documentation
            })
        
        # Prepare mandatory elements
        mandatory_elements = []
        for element in self.mandatory_elements:
            mandatory_elements.append({
                "name": element.name,
                "path": element.path,
                "type": element.element_type,
                "minOccurs": element.min_occurs,
                "maxOccurs": element.max_occurs
            })
        
        # Prepare optional elements
        optional_elements = []
        for element in self.optional_elements:
            optional_elements.append({
                "name": element.name,
                "path": element.path,
                "type": element.element_type,
                "minOccurs": element.min_occurs,
                "maxOccurs": element.max_occurs
            })
        
        # Generate statistics
        statistics = {
            "totalElements": len(self.elements),
            "totalTypes": len(self.complex_types) + len(self.simple_types),
            "complexTypes": len(self.complex_types),
            "simpleTypes": len(self.simple_types),
            "multipleOccurrenceElements": len(self.multiple_occurrence_elements),
            "mandatoryElements": len(self.mandatory_elements),
            "optionalElements": len(self.optional_elements),
            "rootElements": len(self.root_elements)
        }
        
        # Generate hierarchy
        hierarchy = {}
        for root_element in self.root_elements:
            if root_element in self.elements:
                hierarchy[root_element] = self._build_element_tree(root_element)
        
        return {
            "multipleOccurrenceTags": multiple_occurrence_tags,
            "allElements": all_elements,
            "mandatoryElements": mandatory_elements,
            "optionalElements": optional_elements,
            "statistics": statistics,
            "hierarchy": hierarchy,
            "targetNamespace": self.target_namespace,
            "rootElements": self.root_elements,
            "complexTypes": list(self.complex_types.keys()),
            "simpleTypes": list(self.simple_types.keys()),
            "namespaces": self.namespaces
        }
    
    def _build_element_tree(self, element_name: str, visited: Set[str] = None) -> Dict[str, Any]:
        """Build hierarchical tree for an element."""
        if visited is None:
            visited = set()
        
        if element_name in visited or element_name not in self.elements:
            return {"name": element_name, "circular": True}
        
        visited.add(element_name)
        element = self.elements[element_name]
        
        tree = {
            "name": element.name,
            "type": element.element_type,
            "minOccurs": element.min_occurs,
            "maxOccurs": element.max_occurs,
            "isComplex": element.is_complex,
            "isSimple": element.is_simple,
            "isMandatory": element.is_mandatory,
            "canBeMultiple": element.can_be_multiple,
            "children": []
        }
        
        for child_name in element.children:
            if child_name not in visited:
                child_tree = self._build_element_tree(child_name, visited.copy())
                tree["children"].append(child_tree)
        
        return tree
    
    def _get_local_name(self, tag: str) -> str:
        """Extract local name from namespaced tag."""
        if '}' in tag:
            return tag.split('}')[1]
        return tag.split(':')[-1] if ':' in tag else tag
    
    def _is_simple_type(self, type_name: str) -> bool:
        """Check if a type is a simple type."""
        simple_types = {
            'xs:string', 'xs:int', 'xs:integer', 'xs:decimal', 'xs:double', 'xs:float',
            'xs:boolean', 'xs:date', 'xs:dateTime', 'xs:time', 'xs:duration',
            'xs:base64Binary', 'xs:hexBinary', 'xs:anyURI', 'xs:QName',
            'string', 'int', 'integer', 'decimal', 'double', 'float',
            'boolean', 'date', 'dateTime', 'time', 'duration',
            'base64Binary', 'hexBinary', 'anyURI', 'QName'
        }
        
        clean_type = type_name.replace('xs:', '').replace('xsd:', '')
        return type_name in simple_types or clean_type in simple_types or type_name in self.simple_types
    
    def validate_schema(self, xsd_path: str) -> Dict[str, Any]:
        """
        Validate the XSD schema itself for correctness.
        
        Args:
            xsd_path: Path to the XSD schema file
            
        Returns:
            Dictionary containing validation results
        """
        try:
            # Try to parse the schema
            tree = etree.parse(xsd_path)
            root = tree.getroot()
            
            errors = []
            warnings = []
            
            # Basic validation checks
            if not root.tag.endswith('schema'):
                errors.append("Root element is not a schema element")
            
            # Check for required namespaces
            if 'http://www.w3.org/2001/XMLSchema' not in str(root.nsmap.values()):
                warnings.append("XML Schema namespace not found")
            
            return {
                "isValid": len(errors) == 0,
                "errors": errors,
                "warnings": warnings,
                "schemaVersion": "1.0"
            }
            
        except Exception as e:
            return {
                "isValid": False,
                "errors": [f"Schema validation failed: {str(e)}"],
                "warnings": []
            }
    
    def extract_namespaces(self, xsd_path: str) -> Dict[str, str]:
        """
        Extract namespace information from the XSD schema.
        
        Args:
            xsd_path: Path to the XSD schema file
            
        Returns:
            Dictionary mapping namespace prefixes to URIs
        """
        try:
            tree = etree.parse(xsd_path)
            root = tree.getroot()
            
            namespaces = {}
            for prefix, uri in root.nsmap.items():
                if prefix is not None:
                    namespaces[prefix] = uri
                else:
                    namespaces['default'] = uri
            
            return namespaces
            
        except Exception as e:
            self.logger.error(f"Failed to extract namespaces: {e}")
            return {}