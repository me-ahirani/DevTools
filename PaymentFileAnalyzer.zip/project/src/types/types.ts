export interface GenerationCriteria {
  randomData: number;
  mandatoryOnly: number;
  multipleOccurrence: number;
  anomalies: number;
  selectedTags: string[];
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
  timestamp: string;
}

export interface GeneratedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  downloadUrl: string;
  created: string;
  content?: string; // Add content field for storing actual XML content
}

export interface MultipleOccurrenceTag {
  name: string;
  path: string;
  minOccurs: number;
  maxOccurs: number | 'unbounded';
}

export interface XmlAnalysisResult {
  isValid: boolean;
  rootElement?: string;
  namespace?: string;
  elementCount?: number;
  uniqueTags?: string[];
  maxDepth?: number;
  attributes?: Record<string, number>;
  textNodes?: number;
  fileSize?: number;
  hasNamespace?: boolean;
  complexity?: number;
  error?: string;
}