export interface Job {
  id: string;
  name: string;
  description: string;
  type: 'clustering' | 'anomaly-detection' | 'sampling';
  status: 'ready' | 'running' | 'completed' | 'failed';
  priority: number;
  estimatedDuration: number; // in seconds
  dependencies: string[];
}

export interface JobConfiguration {
  testSuitePath: string;
  xsdPath: string;
  outputPath: string;
  uniquenessThreshold: number;
  enabledJobs: string[];
}

export interface JobExecution {
  jobId: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'warning';
  progress: number;
  startTime?: string;
  endTime?: string;
  error?: string;
  results?: JobResults;
}

export interface JobResults {
  filesProcessed: number;
  clustersCreated: number;
  anomaliesFound: number;
  outputPath: string;
  clusterDetails?: Record<string, number>;
  processingTime?: number;
  warnings?: string[];
}