import { ClusterPoint, kMeansClustering, detectAnomalies } from './clustering';
import { analyzeXmlStructure, AnalysisResult } from './xmlAnalyzer';

export interface JobConfig {
  id: string;
  name: string;
  type: 'schema_cluster' | 'tag_match_cluster' | 'tag_data_cluster' | 'anomaly_cluster' | 'unique_sample_cluster' | 'tag_specific_cluster';
  parameters: Record<string, any>;
}

export interface JobResult {
  id: string;
  status: 'running' | 'completed' | 'failed';
  progress: number;
  result?: any;
  error?: string;
  startTime: Date;
  endTime?: Date;
}

class JobManager {
  private jobs: Map<string, JobResult> = new Map();
  private xmlFiles: Map<string, string> = new Map();

  async executeJob(config: JobConfig, xmlFiles: File[]): Promise<string> {
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const jobResult: JobResult = {
      id: jobId,
      status: 'running',
      progress: 0,
      startTime: new Date()
    };
    
    this.jobs.set(jobId, jobResult);

    try {
      // Load XML files
      const xmlContents: string[] = [];
      for (const file of xmlFiles) {
        const content = await this.readFileAsText(file);
        xmlContents.push(content);
        this.xmlFiles.set(file.name, content);
      }

      jobResult.progress = 20;
      this.jobs.set(jobId, { ...jobResult });

      // Execute job based on type
      let result: any;
      switch (config.type) {
        case 'schema_cluster':
          result = await this.executeSchemaClusterJob(xmlContents, config.parameters);
          break;
        case 'tag_match_cluster':
          result = await this.executeTagMatchClusterJob(xmlContents, config.parameters);
          break;
        case 'tag_data_cluster':
          result = await this.executeTagDataClusterJob(xmlContents, config.parameters);
          break;
        case 'anomaly_cluster':
          result = await this.executeAnomalyClusterJob(xmlContents, config.parameters);
          break;
        case 'unique_sample_cluster':
          result = await this.executeUniqueSampleClusterJob(xmlContents, config.parameters);
          break;
        case 'tag_specific_cluster':
          result = await this.executeTagSpecificClusterJob(xmlContents, config.parameters);
          break;
        default:
          throw new Error(`Unknown job type: ${config.type}`);
      }

      jobResult.status = 'completed';
      jobResult.progress = 100;
      jobResult.result = result;
      jobResult.endTime = new Date();
      
    } catch (error) {
      jobResult.status = 'failed';
      jobResult.error = error instanceof Error ? error.message : 'Unknown error';
      jobResult.endTime = new Date();
    }

    this.jobs.set(jobId, jobResult);
    return jobId;
  }

  getJobStatus(jobId: string): JobResult | undefined {
    return this.jobs.get(jobId);
  }

  private async readFileAsText(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  }

  private async executeSchemaClusterJob(xmlContents: string[], params: any) {
    const analyses = xmlContents.map(xml => analyzeXmlStructure(xml));
    
    // Create feature vectors based on schema characteristics
    const points: ClusterPoint[] = analyses.map((analysis, index) => ({
      id: `file_${index}`,
      features: [
        analysis.elementCount,
        analysis.uniqueTags.length,
        analysis.maxDepth,
        Object.keys(analysis.attributeStats).length
      ]
    }));

    const clusterCount = Math.min(params.clusters || 3, points.length);
    const clustering = kMeansClustering(points, clusterCount);
    
    return {
      clusters: clustering.clusters.map((cluster, index) => ({
        id: index,
        files: cluster.map(p => p.id),
        characteristics: this.calculateClusterCharacteristics(cluster, analyses)
      })),
      summary: {
        totalFiles: xmlContents.length,
        clustersFound: clustering.clusters.length,
        avgFilesPerCluster: clustering.clusters.reduce((sum, c) => sum + c.length, 0) / clustering.clusters.length
      }
    };
  }

  private async executeTagMatchClusterJob(xmlContents: string[], params: any) {
    const analyses = xmlContents.map(xml => analyzeXmlStructure(xml));
    const allTags = new Set<string>();
    
    analyses.forEach(analysis => {
      analysis.uniqueTags.forEach(tag => allTags.add(tag));
    });

    const tagArray = Array.from(allTags);
    
    // Create binary feature vectors for tag presence
    const points: ClusterPoint[] = analyses.map((analysis, index) => ({
      id: `file_${index}`,
      features: tagArray.map(tag => analysis.uniqueTags.includes(tag) ? 1 : 0)
    }));

    const clusterCount = Math.min(params.clusters || 3, points.length);
    const clustering = kMeansClustering(points, clusterCount);
    
    return {
      clusters: clustering.clusters.map((cluster, index) => ({
        id: index,
        files: cluster.map(p => p.id),
        commonTags: this.findCommonTags(cluster, tagArray, analyses),
        uniqueTags: this.findUniqueTagsForCluster(cluster, tagArray, analyses, clustering.clusters)
      })),
      tagDistribution: tagArray.map(tag => ({
        tag,
        frequency: analyses.filter(a => a.uniqueTags.includes(tag)).length
      }))
    };
  }

  private async executeTagDataClusterJob(xmlContents: string[], params: any) {
    // Similar to tag match but considers data content
    return this.executeTagMatchClusterJob(xmlContents, params);
  }

  private async executeAnomalyClusterJob(xmlContents: string[], params: any) {
    const analyses = xmlContents.map(xml => analyzeXmlStructure(xml));
    
    // Detect anomalies in various metrics
    const elementCounts = analyses.map(a => a.elementCount);
    const tagCounts = analyses.map(a => a.uniqueTags.length);
    const depths = analyses.map(a => a.maxDepth);
    
    const elementAnomalies = detectAnomalies(elementCounts);
    const tagAnomalies = detectAnomalies(tagCounts);
    const depthAnomalies = detectAnomalies(depths);
    
    const anomalousFiles = new Set([
      ...elementAnomalies,
      ...tagAnomalies,
      ...depthAnomalies
    ]);

    return {
      anomalies: Array.from(anomalousFiles).map(index => ({
        fileIndex: index,
        reasons: [
          ...(elementAnomalies.includes(index) ? ['Unusual element count'] : []),
          ...(tagAnomalies.includes(index) ? ['Unusual tag variety'] : []),
          ...(depthAnomalies.includes(index) ? ['Unusual nesting depth'] : [])
        ],
        metrics: {
          elementCount: elementCounts[index],
          tagCount: tagCounts[index],
          depth: depths[index]
        }
      })),
      summary: {
        totalFiles: xmlContents.length,
        anomalousFiles: anomalousFiles.size,
        anomalyRate: (anomalousFiles.size / xmlContents.length) * 100
      }
    };
  }

  private async executeUniqueSampleClusterJob(xmlContents: string[], params: any) {
    const analyses = xmlContents.map(xml => analyzeXmlStructure(xml));
    
    // Find unique structural patterns
    const structureSignatures = analyses.map((analysis, index) => ({
      index,
      signature: this.createStructureSignature(analysis),
      analysis
    }));

    const uniqueSignatures = new Map<string, number[]>();
    structureSignatures.forEach(({ signature, index }) => {
      if (!uniqueSignatures.has(signature)) {
        uniqueSignatures.set(signature, []);
      }
      uniqueSignatures.get(signature)!.push(index);
    });

    return {
      uniquePatterns: Array.from(uniqueSignatures.entries()).map(([signature, fileIndices]) => ({
        signature,
        files: fileIndices,
        count: fileIndices.length,
        representative: fileIndices[0]
      })),
      summary: {
        totalFiles: xmlContents.length,
        uniquePatterns: uniqueSignatures.size,
        duplicateGroups: Array.from(uniqueSignatures.values()).filter(group => group.length > 1).length
      }
    };
  }

  private async executeTagSpecificClusterJob(xmlContents: string[], params: any) {
    const targetTag = params.targetTag || 'root';
    const analyses = xmlContents.map(xml => analyzeXmlStructure(xml));
    
    // Filter files that contain the target tag
    const relevantFiles = analyses
      .map((analysis, index) => ({ analysis, index }))
      .filter(({ analysis }) => analysis.uniqueTags.includes(targetTag));

    if (relevantFiles.length === 0) {
      return {
        error: `No files contain the target tag: ${targetTag}`,
        availableTags: [...new Set(analyses.flatMap(a => a.uniqueTags))]
      };
    }

    // Create feature vectors based on tag-specific characteristics
    const points: ClusterPoint[] = relevantFiles.map(({ analysis, index }) => ({
      id: `file_${index}`,
      features: [
        analysis.elementCount,
        analysis.uniqueTags.length,
        analysis.maxDepth,
        this.countTagOccurrences(analysis, targetTag)
      ]
    }));

    const clusterCount = Math.min(params.clusters || 3, points.length);
    const clustering = kMeansClustering(points, clusterCount);
    
    return {
      targetTag,
      relevantFiles: relevantFiles.length,
      clusters: clustering.clusters.map((cluster, index) => ({
        id: index,
        files: cluster.map(p => p.id),
        avgTagOccurrences: cluster.reduce((sum, p) => sum + p.features[3], 0) / cluster.length
      })),
      summary: {
        totalFiles: xmlContents.length,
        relevantFiles: relevantFiles.length,
        clustersFound: clustering.clusters.length
      }
    };
  }

  private calculateClusterCharacteristics(cluster: ClusterPoint[], analyses: AnalysisResult[]) {
    const indices = cluster.map(p => parseInt(p.id.split('_')[1]));
    const clusterAnalyses = indices.map(i => analyses[i]);
    
    return {
      avgElementCount: clusterAnalyses.reduce((sum, a) => sum + a.elementCount, 0) / clusterAnalyses.length,
      avgUniqueTagCount: clusterAnalyses.reduce((sum, a) => sum + a.uniqueTags.length, 0) / clusterAnalyses.length,
      avgDepth: clusterAnalyses.reduce((sum, a) => sum + a.maxDepth, 0) / clusterAnalyses.length,
      commonTags: this.findCommonTagsInAnalyses(clusterAnalyses)
    };
  }

  private findCommonTags(cluster: ClusterPoint[], tagArray: string[], analyses: AnalysisResult[]): string[] {
    const indices = cluster.map(p => parseInt(p.id.split('_')[1]));
    const clusterAnalyses = indices.map(i => analyses[i]);
    
    return tagArray.filter(tag => 
      clusterAnalyses.every(analysis => analysis.uniqueTags.includes(tag))
    );
  }

  private findUniqueTagsForCluster(cluster: ClusterPoint[], tagArray: string[], analyses: AnalysisResult[], allClusters: ClusterPoint[][]): string[] {
    const clusterIndices = cluster.map(p => parseInt(p.id.split('_')[1]));
    const otherIndices = allClusters
      .filter(c => c !== cluster)
      .flat()
      .map(p => parseInt(p.id.split('_')[1]));
    
    const clusterTags = new Set<string>();
    clusterIndices.forEach(i => {
      analyses[i].uniqueTags.forEach(tag => clusterTags.add(tag));
    });
    
    const otherTags = new Set<string>();
    otherIndices.forEach(i => {
      analyses[i].uniqueTags.forEach(tag => otherTags.add(tag));
    });
    
    return Array.from(clusterTags).filter(tag => !otherTags.has(tag));
  }

  private findCommonTagsInAnalyses(analyses: AnalysisResult[]): string[] {
    if (analyses.length === 0) return [];
    
    const firstTags = new Set(analyses[0].uniqueTags);
    return Array.from(firstTags).filter(tag =>
      analyses.every(analysis => analysis.uniqueTags.includes(tag))
    );
  }

  private createStructureSignature(analysis: AnalysisResult): string {
    const sortedTags = [...analysis.uniqueTags].sort();
    return `${sortedTags.join(',')}|${analysis.maxDepth}|${analysis.elementCount}`;
  }

  private countTagOccurrences(analysis: AnalysisResult, targetTag: string): number {
    let count = 0;
    
    function traverse(elements: any[]): void {
      elements.forEach(element => {
        if (element.tagName === targetTag) {
          count++;
        }
        if (element.children) {
          traverse(element.children);
        }
      });
    }
    
    traverse(analysis.structure);
    return count;
  }
}

export const jobManager = new JobManager();