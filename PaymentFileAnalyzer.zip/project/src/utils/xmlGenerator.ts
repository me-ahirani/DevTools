export interface XsdElement {
  name: string;
  type: string;
  minOccurs: number;
  maxOccurs: number | 'unbounded';
  children: XsdElement[];
  attributes: XsdAttribute[];
  isComplexType: boolean;
  isSimpleType: boolean;
  dataType?: string;
  enumValues?: string[];
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  minValue?: number;
  maxValue?: number;
  namespace?: string;
}

export interface XsdAttribute {
  name: string;
  type: string;
  use: 'required' | 'optional' | 'prohibited';
  defaultValue?: string;
  enumValues?: string[];
}

export interface SchemaStructure {
  rootElement: XsdElement;
  targetNamespace?: string;
  complexTypes: Map<string, XsdElement>;
  simpleTypes: Map<string, any>;
  allElements: Map<string, XsdElement>;
}

export class XmlGenerator {
  private schema: SchemaStructure | null = null;
  private randomSeed = Math.random();
  private elementCounter = new Map<string, number>();

  constructor() {
    this.resetSeed();
  }

  resetSeed() {
    this.randomSeed = Math.random();
    this.elementCounter.clear();
  }

  // Parse XSD content and extract complete schema structure
  parseXsdSchema(xsdContent: string): SchemaStructure {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xsdContent, 'text/xml');
    
    if (doc.documentElement.tagName === 'parsererror') {
      throw new Error('Invalid XSD content');
    }

    const schema: SchemaStructure = {
      rootElement: { name: '', type: '', minOccurs: 1, maxOccurs: 1, children: [], attributes: [], isComplexType: false, isSimpleType: false },
      targetNamespace: doc.documentElement.getAttribute('targetNamespace') || undefined,
      complexTypes: new Map(),
      simpleTypes: new Map(),
      allElements: new Map()
    };

    // Parse complex types first
    const complexTypes = doc.querySelectorAll('xs\\:complexType, complexType');
    complexTypes.forEach(complexType => {
      const typeName = complexType.getAttribute('name');
      if (typeName) {
        const element = this.parseComplexType(complexType, schema);
        element.name = typeName;
        schema.complexTypes.set(typeName, element);
      }
    });

    // Parse simple types
    const simpleTypes = doc.querySelectorAll('xs\\:simpleType, simpleType');
    simpleTypes.forEach(simpleType => {
      const typeName = simpleType.getAttribute('name');
      if (typeName) {
        const typeInfo = this.parseSimpleType(simpleType);
        schema.simpleTypes.set(typeName, typeInfo);
      }
    });

    // Parse all elements (including nested ones)
    const allElements = doc.querySelectorAll('xs\\:element, element');
    allElements.forEach(elementNode => {
      const elementName = elementNode.getAttribute('name');
      if (elementName) {
        const element = this.parseElement(elementNode, schema);
        schema.allElements.set(elementName, element);
      }
    });

    // Parse root elements
    const rootElements = doc.querySelectorAll('xs\\:schema > xs\\:element, schema > element');
    if (rootElements.length > 0) {
      schema.rootElement = this.parseElement(rootElements[0], schema);
    } else if (schema.allElements.size > 0) {
      // If no direct root element, use the first element as root
      schema.rootElement = Array.from(schema.allElements.values())[0];
    }

    this.schema = schema;
    return schema;
  }

  private parseElement(elementNode: Element, schema: SchemaStructure): XsdElement {
    const element: XsdElement = {
      name: elementNode.getAttribute('name') || '',
      type: elementNode.getAttribute('type') || '',
      minOccurs: parseInt(elementNode.getAttribute('minOccurs') || '1'),
      maxOccurs: elementNode.getAttribute('maxOccurs') === 'unbounded' ? 'unbounded' : parseInt(elementNode.getAttribute('maxOccurs') || '1'),
      children: [],
      attributes: [],
      isComplexType: false,
      isSimpleType: false
    };

    // Check if element has inline complex type
    const inlineComplexType = elementNode.querySelector('xs\\:complexType, complexType');
    if (inlineComplexType) {
      const complexElement = this.parseComplexType(inlineComplexType, schema);
      element.children = complexElement.children;
      element.attributes = complexElement.attributes;
      element.isComplexType = true;
    } else if (element.type) {
      // Remove namespace prefix for type lookup
      const cleanType = element.type.replace(/^xs:/, '').replace(/^[^:]+:/, '');
      
      // Check if type is a complex type
      if (schema.complexTypes.has(element.type) || schema.complexTypes.has(cleanType)) {
        const complexType = schema.complexTypes.get(element.type) || schema.complexTypes.get(cleanType);
        if (complexType) {
          element.children = [...complexType.children];
          element.attributes = [...complexType.attributes];
          element.isComplexType = true;
        }
      } else {
        // Simple type
        element.isSimpleType = true;
        element.dataType = this.mapXsdTypeToDataType(element.type);
        
        // Check if it's a custom simple type
        if (schema.simpleTypes.has(element.type) || schema.simpleTypes.has(cleanType)) {
          const simpleType = schema.simpleTypes.get(element.type) || schema.simpleTypes.get(cleanType);
          if (simpleType) {
            element.enumValues = simpleType.enumValues;
            element.pattern = simpleType.pattern;
            element.minLength = simpleType.minLength;
            element.maxLength = simpleType.maxLength;
            element.minValue = simpleType.minValue;
            element.maxValue = simpleType.maxValue;
          }
        }
      }
    } else {
      // No type specified, treat as string
      element.isSimpleType = true;
      element.dataType = 'string';
    }

    return element;
  }

  private parseComplexType(complexTypeNode: Element, schema: SchemaStructure): XsdElement {
    const element: XsdElement = {
      name: '',
      type: '',
      minOccurs: 1,
      maxOccurs: 1,
      children: [],
      attributes: [],
      isComplexType: true,
      isSimpleType: false
    };

    // Parse sequence, choice, or all
    const sequence = complexTypeNode.querySelector('xs\\:sequence, sequence');
    const choice = complexTypeNode.querySelector('xs\\:choice, choice');
    const all = complexTypeNode.querySelector('xs\\:all, all');

    const container = sequence || choice || all;
    if (container) {
      const childElements = container.querySelectorAll('xs\\:element, element');
      childElements.forEach(childElement => {
        const childParsed = this.parseElement(childElement, schema);
        element.children.push(childParsed);
      });

      // Also look for nested groups
      const groups = container.querySelectorAll('xs\\:group, group');
      groups.forEach(group => {
        const groupElements = group.querySelectorAll('xs\\:element, element');
        groupElements.forEach(childElement => {
          const childParsed = this.parseElement(childElement, schema);
          element.children.push(childParsed);
        });
      });
    }

    // Parse attributes
    const attributes = complexTypeNode.querySelectorAll('xs\\:attribute, attribute');
    attributes.forEach(attr => {
      const attribute: XsdAttribute = {
        name: attr.getAttribute('name') || '',
        type: attr.getAttribute('type') || 'xs:string',
        use: (attr.getAttribute('use') as any) || 'optional',
        defaultValue: attr.getAttribute('default') || undefined
      };
      element.attributes.push(attribute);
    });

    // Parse attribute groups
    const attributeGroups = complexTypeNode.querySelectorAll('xs\\:attributeGroup, attributeGroup');
    attributeGroups.forEach(attrGroup => {
      const groupAttrs = attrGroup.querySelectorAll('xs\\:attribute, attribute');
      groupAttrs.forEach(attr => {
        const attribute: XsdAttribute = {
          name: attr.getAttribute('name') || '',
          type: attr.getAttribute('type') || 'xs:string',
          use: (attr.getAttribute('use') as any) || 'optional',
          defaultValue: attr.getAttribute('default') || undefined
        };
        element.attributes.push(attribute);
      });
    });

    return element;
  }

  private parseSimpleType(simpleTypeNode: Element): any {
    const typeInfo: any = {
      enumValues: [],
      pattern: undefined,
      minLength: undefined,
      maxLength: undefined,
      minValue: undefined,
      maxValue: undefined
    };

    // Parse restrictions
    const restriction = simpleTypeNode.querySelector('xs\\:restriction, restriction');
    if (restriction) {
      const base = restriction.getAttribute('base');
      typeInfo.baseType = base;

      // Parse enumerations
      const enumerations = restriction.querySelectorAll('xs\\:enumeration, enumeration');
      enumerations.forEach(enumNode => {
        const value = enumNode.getAttribute('value');
        if (value) typeInfo.enumValues.push(value);
      });

      // Parse pattern
      const patternNode = restriction.querySelector('xs\\:pattern, pattern');
      if (patternNode) {
        typeInfo.pattern = patternNode.getAttribute('value');
      }

      // Parse length restrictions
      const minLengthNode = restriction.querySelector('xs\\:minLength, minLength');
      if (minLengthNode) {
        typeInfo.minLength = parseInt(minLengthNode.getAttribute('value') || '0');
      }

      const maxLengthNode = restriction.querySelector('xs\\:maxLength, maxLength');
      if (maxLengthNode) {
        typeInfo.maxLength = parseInt(maxLengthNode.getAttribute('value') || '100');
      }

      // Parse value restrictions
      const minInclusiveNode = restriction.querySelector('xs\\:minInclusive, minInclusive');
      if (minInclusiveNode) {
        typeInfo.minValue = parseFloat(minInclusiveNode.getAttribute('value') || '0');
      }

      const maxInclusiveNode = restriction.querySelector('xs\\:maxInclusive, maxInclusive');
      if (maxInclusiveNode) {
        typeInfo.maxValue = parseFloat(maxInclusiveNode.getAttribute('value') || '1000');
      }
    }

    return typeInfo;
  }

  private mapXsdTypeToDataType(xsdType: string): string {
    const typeMap: { [key: string]: string } = {
      'xs:string': 'string',
      'string': 'string',
      'xs:int': 'integer',
      'int': 'integer',
      'xs:integer': 'integer',
      'integer': 'integer',
      'xs:decimal': 'decimal',
      'decimal': 'decimal',
      'xs:double': 'decimal',
      'double': 'decimal',
      'xs:float': 'decimal',
      'float': 'decimal',
      'xs:boolean': 'boolean',
      'boolean': 'boolean',
      'xs:date': 'date',
      'date': 'date',
      'xs:dateTime': 'datetime',
      'dateTime': 'datetime',
      'xs:time': 'time',
      'time': 'time',
      'xs:duration': 'duration',
      'duration': 'duration',
      'xs:base64Binary': 'base64',
      'base64Binary': 'base64',
      'xs:hexBinary': 'hex',
      'hexBinary': 'hex',
      'xs:anyURI': 'uri',
      'anyURI': 'uri',
      'xs:QName': 'qname',
      'QName': 'qname',
      'xs:NOTATION': 'notation',
      'NOTATION': 'notation',
      'xs:normalizedString': 'string',
      'normalizedString': 'string',
      'xs:token': 'string',
      'token': 'string',
      'xs:language': 'string',
      'language': 'string',
      'xs:NMTOKEN': 'string',
      'NMTOKEN': 'string',
      'xs:NMTOKENS': 'string',
      'NMTOKENS': 'string',
      'xs:Name': 'string',
      'Name': 'string',
      'xs:NCName': 'string',
      'NCName': 'string',
      'xs:ID': 'string',
      'ID': 'string',
      'xs:IDREF': 'string',
      'IDREF': 'string',
      'xs:IDREFS': 'string',
      'IDREFS': 'string',
      'xs:ENTITY': 'string',
      'ENTITY': 'string',
      'xs:ENTITIES': 'string',
      'ENTITIES': 'string',
      'xs:gYear': 'year',
      'gYear': 'year',
      'xs:gYearMonth': 'yearmonth',
      'gYearMonth': 'yearmonth',
      'xs:gMonth': 'month',
      'gMonth': 'month',
      'xs:gMonthDay': 'monthday',
      'gMonthDay': 'monthday',
      'xs:gDay': 'day',
      'gDay': 'day'
    };

    return typeMap[xsdType] || 'string';
  }

  // Generate XML with all tags from schema
  generateXmlFromSchema(
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    selectedTags: string[] = [],
    fileNumber: number = 1
  ): string {
    if (!this.schema) {
      throw new Error('Schema not parsed. Call parseXsdSchema first.');
    }

    this.resetSeed(); // Reset for consistent randomization per file
    
    const xmlDoc = document.implementation.createDocument(
      this.schema.targetNamespace || null,
      this.schema.rootElement.name,
      null
    );

    const rootElement = xmlDoc.documentElement;
    
    // Add namespace declarations if present
    if (this.schema.targetNamespace) {
      rootElement.setAttribute('xmlns', this.schema.targetNamespace);
      rootElement.setAttribute('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');
    }

    // Generate content based on file type
    this.generateElementContent(rootElement, this.schema.rootElement, fileType, selectedTags, fileNumber);

    // Serialize to string
    const serializer = new XMLSerializer();
    let xmlString = serializer.serializeToString(xmlDoc);
    
    // Add XML declaration
    xmlString = '<?xml version="1.0" encoding="UTF-8"?>\n' + xmlString;
    
    // Pretty print
    return this.formatXml(xmlString);
  }

  private generateElementContent(
    xmlElement: Element,
    schemaElement: XsdElement,
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    selectedTags: string[],
    fileNumber: number,
    depth: number = 0
  ) {
    // Prevent infinite recursion
    if (depth > 10) return;

    // Add attributes
    schemaElement.attributes.forEach(attr => {
      if (fileType === 'mandatory' && attr.use !== 'required') return;
      
      const value = this.generateAttributeValue(attr, fileType, fileNumber);
      if (value !== null) {
        xmlElement.setAttribute(attr.name, value);
      }
    });

    // Add child elements
    schemaElement.children.forEach(childSchema => {
      const shouldInclude = this.shouldIncludeElement(childSchema, fileType);
      if (!shouldInclude) return;

      // Determine how many instances to create
      let instanceCount = 1;
      
      if (fileType === 'multiple' && selectedTags.includes(childSchema.name)) {
        instanceCount = this.getMultipleOccurrenceCount(childSchema, true);
      } else if (childSchema.maxOccurs !== 1 && fileType !== 'mandatory') {
        instanceCount = this.getRandomOccurrenceCount(childSchema);
      } else if (fileType === 'random' && childSchema.maxOccurs !== 1) {
        // For random files, sometimes generate multiple occurrences
        instanceCount = this.getRandomOccurrenceCount(childSchema);
      }

      // Ensure minimum occurrences are met
      instanceCount = Math.max(instanceCount, childSchema.minOccurs);

      // Create instances
      for (let i = 0; i < instanceCount; i++) {
        const childElement = xmlElement.ownerDocument.createElement(childSchema.name);
        
        if (childSchema.isSimpleType) {
          // Generate text content for simple types
          const textContent = this.generateSimpleTypeValue(childSchema, fileType, fileNumber, i);
          if (textContent !== null && textContent !== '') {
            childElement.textContent = textContent;
          }
        } else if (childSchema.isComplexType) {
          // Recursively generate complex type content
          this.generateElementContent(childElement, childSchema, fileType, selectedTags, fileNumber, depth + 1);
        } else {
          // Mixed content or unknown type - generate simple text
          const textContent = this.generateSimpleTypeValue(
            { ...childSchema, isSimpleType: true, dataType: 'string' },
            fileType,
            fileNumber,
            i
          );
          if (textContent !== null && textContent !== '') {
            childElement.textContent = textContent;
          }
        }

        xmlElement.appendChild(childElement);
      }
    });
  }

  private shouldIncludeElement(element: XsdElement, fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly'): boolean {
    switch (fileType) {
      case 'mandatory':
        return element.minOccurs > 0;
      case 'random':
        // Include most elements, but sometimes skip optional ones
        return element.minOccurs > 0 || Math.random() > 0.2;
      case 'multiple':
      case 'anomaly':
        // Include all elements for comprehensive generation
        return true;
      default:
        return element.minOccurs > 0;
    }
  }

  private getMultipleOccurrenceCount(element: XsdElement, forceMultiple: boolean = false): number {
    if (element.maxOccurs === 'unbounded') {
      return forceMultiple ? Math.floor(Math.random() * 5) + 2 : Math.floor(Math.random() * 3) + 1; // 2-6 or 1-3 instances
    } else if (typeof element.maxOccurs === 'number' && element.maxOccurs > 1) {
      const min = forceMultiple ? Math.max(2, element.minOccurs) : element.minOccurs;
      return Math.floor(Math.random() * (element.maxOccurs - min + 1)) + min;
    }
    return Math.max(1, element.minOccurs);
  }

  private getRandomOccurrenceCount(element: XsdElement): number {
    if (element.minOccurs === 0 && Math.random() < 0.3) {
      return 0; // 30% chance to omit optional elements
    }
    
    if (element.maxOccurs === 'unbounded') {
      return Math.floor(Math.random() * 3) + Math.max(1, element.minOccurs); // 1-3 instances beyond minimum
    } else if (typeof element.maxOccurs === 'number' && element.maxOccurs > 1) {
      return Math.floor(Math.random() * (element.maxOccurs - element.minOccurs + 1)) + element.minOccurs;
    }
    return Math.max(1, element.minOccurs);
  }

  private generateAttributeValue(
    attribute: XsdAttribute,
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    fileNumber: number
  ): string | null {
    if (attribute.use === 'prohibited') return null;
    if (fileType === 'mandatory' && attribute.use !== 'required') return null;

    if (attribute.defaultValue) {
      return attribute.defaultValue;
    }

    if (attribute.enumValues && attribute.enumValues.length > 0) {
      return this.getRandomElement(attribute.enumValues);
    }

    return this.generateValueByType(attribute.type, fileType, fileNumber);
  }

  private generateSimpleTypeValue(
    element: XsdElement,
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    fileNumber: number,
    instanceIndex: number = 0
  ): string | null {
    // Handle enumerations
    if (element.enumValues && element.enumValues.length > 0) {
      return this.getRandomElement(element.enumValues);
    }

    // Handle patterns
    if (element.pattern) {
      return this.generateValueFromPattern(element.pattern, fileType, fileNumber, instanceIndex);
    }

    // Generate by data type
    return this.generateValueByType(element.dataType || element.type, fileType, fileNumber, instanceIndex, element);
  }

  private generateValueByType(
    dataType: string,
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    fileNumber: number,
    instanceIndex: number = 0,
    element?: XsdElement
  ): string {
    const isAnomaly = fileType === 'anomaly';
    
    // Increment counter for this element type
    const counterKey = `${dataType}_${fileNumber}_${instanceIndex}`;
    const currentCount = this.elementCounter.get(counterKey) || 0;
    this.elementCounter.set(counterKey, currentCount + 1);
    
    switch (dataType) {
      case 'string':
      case 'xs:string':
        return this.generateStringValue(isAnomaly, fileNumber, instanceIndex, element);
      
      case 'integer':
      case 'xs:int':
      case 'xs:integer':
        return this.generateIntegerValue(isAnomaly, fileNumber, instanceIndex, element);
      
      case 'decimal':
      case 'xs:decimal':
      case 'xs:double':
      case 'xs:float':
        return this.generateDecimalValue(isAnomaly, fileNumber, instanceIndex, element);
      
      case 'boolean':
      case 'xs:boolean':
        return this.generateBooleanValue(isAnomaly);
      
      case 'date':
      case 'xs:date':
        return this.generateDateValue(isAnomaly, fileNumber, instanceIndex);
      
      case 'datetime':
      case 'xs:dateTime':
        return this.generateDateTimeValue(isAnomaly, fileNumber, instanceIndex);
      
      case 'time':
      case 'xs:time':
        return this.generateTimeValue(isAnomaly);
      
      case 'uri':
      case 'xs:anyURI':
        return this.generateUriValue(isAnomaly, fileNumber, instanceIndex);
      
      default:
        return this.generateStringValue(isAnomaly, fileNumber, instanceIndex, element);
    }
  }

  private generateStringValue(
    isAnomaly: boolean,
    fileNumber: number,
    instanceIndex: number,
    element?: XsdElement
  ): string {
    if (isAnomaly) {
      const anomalyTypes = [
        () => `测试数据${fileNumber}_${instanceIndex}`, // Chinese characters
        () => `Тест${fileNumber}_${instanceIndex}`, // Cyrillic characters
        () => `Données${fileNumber}_${instanceIndex}`, // French accented characters
        () => `@#$%^&*()${fileNumber}_${instanceIndex}`, // Special characters
        () => `<script>alert('xss${fileNumber}')</script>`, // XSS attempt
        () => `' OR '1'='1' --`, // SQL injection attempt
        () => 'A'.repeat(Math.min(1000, Math.max(100, (element?.maxLength || 50) * 10))), // Very long string
        () => '', // Empty string
        () => '\x00\x01\x02', // Control characters
        () => `🚀🎉💻🔥⚡_${fileNumber}_${instanceIndex}` // Emojis
      ];
      return this.getRandomElement(anomalyTypes)();
    }

    // Apply length constraints if specified
    let minLength = element?.minLength || 1;
    let maxLength = element?.maxLength || 50;
    
    // Ensure reasonable bounds
    minLength = Math.max(1, minLength);
    maxLength = Math.min(200, Math.max(minLength, maxLength));

    const baseWords = [
      'Payment', 'Transaction', 'Transfer', 'Credit', 'Debit', 'Account', 'Bank', 'Customer',
      'Reference', 'Invoice', 'Order', 'Service', 'Product', 'Company', 'Business', 'Finance',
      'Amount', 'Currency', 'Exchange', 'Rate', 'Fee', 'Charge', 'Balance', 'Statement',
      'Report', 'Summary', 'Detail', 'Information', 'Data', 'Record', 'Entry', 'Item',
      'Code', 'Number', 'Identifier', 'Name', 'Description', 'Note', 'Comment', 'Remark',
      'Address', 'Street', 'City', 'Country', 'PostalCode', 'Phone', 'Email', 'Contact',
      'Message', 'Status', 'Type', 'Category', 'Group', 'Class', 'Level', 'Priority'
    ];

    const word = this.getRandomElement(baseWords);
    const uniqueId = `${fileNumber}${instanceIndex.toString().padStart(3, '0')}`;
    let result = `${word}_${uniqueId}`;

    // Add some variety to the data
    const variations = [
      () => `${word}_${uniqueId}`,
      () => `${word.toUpperCase()}_${uniqueId}`,
      () => `${word.toLowerCase()}_${uniqueId}`,
      () => `${word}_TEST_${uniqueId}`,
      () => `${word}_DATA_${uniqueId}`,
      () => `${word}_${uniqueId}_V${Math.floor(Math.random() * 10) + 1}`
    ];
    
    result = this.getRandomElement(variations)();

    // Adjust length to meet constraints
    if (result.length < minLength) {
      const padding = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      while (result.length < minLength) {
        result += padding[Math.floor(Math.random() * padding.length)];
      }
    } else if (result.length > maxLength) {
      result = result.substring(0, maxLength);
    }

    return result;
  }

  private generateIntegerValue(
    isAnomaly: boolean,
    fileNumber: number,
    instanceIndex: number,
    element?: XsdElement
  ): string {
    if (isAnomaly) {
      const anomalies = [
        'not_a_number',
        '12.34.56',
        'NaN',
        'Infinity',
        '-Infinity',
        '1e999',
        '0x1234',
        '1,234,567',
        '1 234 567',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const min = element?.minValue || 1;
    const max = element?.maxValue || 999999;
    
    // Add some variety based on file and instance
    const baseValue = Math.floor(Math.random() * (max - min + 1) + min);
    const variation = (fileNumber * 1000) + (instanceIndex * 10);
    const finalValue = Math.min(max, Math.max(min, baseValue + variation));
    
    return finalValue.toString();
  }

  private generateDecimalValue(
    isAnomaly: boolean,
    fileNumber: number,
    instanceIndex: number,
    element?: XsdElement
  ): string {
    if (isAnomaly) {
      const anomalies = [
        'not_a_decimal',
        '12,34',
        '12.34.56',
        'NaN',
        'Infinity',
        '1e999',
        '12.34.56.78',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const min = element?.minValue || 0.01;
    const max = element?.maxValue || 999999.99;
    
    // Add some variety based on file and instance
    const baseValue = Math.random() * (max - min) + min;
    const variation = (fileNumber * 100) + (instanceIndex * 10);
    const finalValue = Math.min(max, Math.max(min, baseValue + variation));
    
    return finalValue.toFixed(2);
  }

  private generateBooleanValue(isAnomaly: boolean): string {
    if (isAnomaly) {
      const anomalies = ['yes', 'no', '1', '0', 'TRUE', 'FALSE', 'maybe', 'unknown', 'null'];
      return this.getRandomElement(anomalies);
    }
    
    return Math.random() < 0.5 ? 'true' : 'false';
  }

  private generateDateValue(isAnomaly: boolean, fileNumber: number, instanceIndex: number): string {
    if (isAnomaly) {
      const anomalies = [
        '2024-13-45',
        '2024/12/31',
        '31-12-2024',
        '2024-02-30',
        'not_a_date',
        '2024-12-32',
        '0000-00-00',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const start = new Date(2020, 0, 1);
    const end = new Date(2025, 11, 31);
    const randomDate = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    
    // Add some variation based on file and instance
    randomDate.setDate(randomDate.getDate() + (fileNumber % 30) + (instanceIndex % 10));
    
    return randomDate.toISOString().split('T')[0];
  }

  private generateDateTimeValue(isAnomaly: boolean, fileNumber: number, instanceIndex: number): string {
    if (isAnomaly) {
      const anomalies = [
        '2024-13-45T25:70:80Z',
        '2024-12-31 12:34:56',
        '2024/12/31T12:34:56',
        'not_a_datetime',
        '2024-12-31T24:00:00Z',
        '2024-02-30T12:34:56Z',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const start = new Date(2020, 0, 1);
    const end = new Date(2025, 11, 31);
    const randomDate = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    
    // Add some variation based on file and instance
    randomDate.setHours(randomDate.getHours() + (fileNumber % 24));
    randomDate.setMinutes(randomDate.getMinutes() + (instanceIndex % 60));
    
    return randomDate.toISOString();
  }

  private generateTimeValue(isAnomaly: boolean): string {
    if (isAnomaly) {
      const anomalies = [
        '25:70:80',
        '12:34',
        '12.34.56',
        'not_a_time',
        '24:00:00',
        '12:60:00',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const hours = Math.floor(Math.random() * 24).toString().padStart(2, '0');
    const minutes = Math.floor(Math.random() * 60).toString().padStart(2, '0');
    const seconds = Math.floor(Math.random() * 60).toString().padStart(2, '0');
    
    return `${hours}:${minutes}:${seconds}`;
  }

  private generateUriValue(isAnomaly: boolean, fileNumber: number, instanceIndex: number): string {
    if (isAnomaly) {
      const anomalies = [
        'not_a_uri',
        'http://',
        'ftp://invalid uri',
        'javascript:alert("xss")',
        'file:///etc/passwd',
        'http://[invalid]',
        'null',
        'undefined'
      ];
      return this.getRandomElement(anomalies);
    }

    const domains = ['example.com', 'test.org', 'sample.net', 'demo.co.uk', 'api.service.com'];
    const paths = ['api', 'service', 'endpoint', 'resource', 'data', 'payment', 'transaction'];
    
    const domain = this.getRandomElement(domains);
    const path = this.getRandomElement(paths);
    
    return `https://${domain}/${path}/${fileNumber}/${instanceIndex}`;
  }

  private generateValueFromPattern(
    pattern: string,
    fileType: 'random' | 'mandatory' | 'multiple' | 'anomaly',
    fileNumber: number,
    instanceIndex: number
  ): string {
    if (fileType === 'anomaly') {
      return `INVALID_PATTERN_${fileNumber}_${instanceIndex}`;
    }

    // Enhanced pattern matching for common cases
    if (pattern.includes('[0-9]')) {
      const length = (pattern.match(/\{(\d+)\}/)?.[1]) || '6';
      return Math.floor(Math.random() * Math.pow(10, parseInt(length))).toString().padStart(parseInt(length), '0');
    }
    if (pattern.includes('[A-Z]')) {
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      return letters[Math.floor(Math.random() * letters.length)] + (fileNumber * 100 + instanceIndex);
    }
    if (pattern.includes('[a-z]')) {
      const letters = 'abcdefghijklmnopqrstuvwxyz';
      return letters[Math.floor(Math.random() * letters.length)] + (fileNumber * 100 + instanceIndex);
    }
    if (pattern.includes('[A-Za-z0-9]')) {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < 8; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
      }
      return result + '_' + fileNumber + '_' + instanceIndex;
    }
    
    // Fallback to simple string
    return `PATTERN_${fileNumber}_${instanceIndex}_${Math.floor(Math.random() * 1000)}`;
  }

  private getRandomElement<T>(array: T[]): T {
    return array[Math.floor(Math.random() * array.length)];
  }

  private formatXml(xml: string): string {
    const PADDING = '  ';
    const reg = /(>)(<)(\/*)/g;
    let formatted = xml.replace(reg, '$1\n$2$3');
    
    let pad = 0;
    return formatted.split('\n').map(line => {
      let indent = 0;
      if (line.match(/.+<\/\w[^>]*>$/)) {
        indent = 0;
      } else if (line.match(/^<\/\w/) && pad > 0) {
        pad -= 1;
      } else if (line.match(/^<\w[^>]*[^\/]>.*$/)) {
        indent = 1;
      } else {
        indent = 0;
      }
      
      const padding = PADDING.repeat(pad);
      pad += indent;
      
      return padding + line;
    }).join('\n');
  }
}

export const xmlGenerator = new XmlGenerator();