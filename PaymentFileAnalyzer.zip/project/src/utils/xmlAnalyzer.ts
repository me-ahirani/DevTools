// XML analysis utilities
export interface XmlElement {
  tagName: string;
  attributes: Record<string, string>;
  children: XmlElement[];
  textContent?: string;
  path: string;
}

export interface AnalysisResult {
  elementCount: number;
  uniqueTags: string[];
  maxDepth: number;
  attributeStats: Record<string, number>;
  structure: XmlElement[];
}

export function analyzeXmlStructure(xmlContent: string): AnalysisResult {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlContent, 'text/xml');
  
  if (doc.documentElement.tagName === 'parsererror') {
    throw new Error('Invalid XML content');
  }

  const result: AnalysisResult = {
    elementCount: 0,
    uniqueTags: [],
    maxDepth: 0,
    attributeStats: {},
    structure: []
  };

  const tagSet = new Set<string>();

  function traverseElement(element: Element, depth: number = 0, path: string = ''): XmlElement {
    result.elementCount++;
    result.maxDepth = Math.max(result.maxDepth, depth);
    
    const tagName = element.tagName;
    tagSet.add(tagName);
    
    const currentPath = path ? `${path}/${tagName}` : tagName;
    
    // Count attributes
    for (let i = 0; i < element.attributes.length; i++) {
      const attr = element.attributes[i];
      result.attributeStats[attr.name] = (result.attributeStats[attr.name] || 0) + 1;
    }

    const attributes: Record<string, string> = {};
    for (let i = 0; i < element.attributes.length; i++) {
      const attr = element.attributes[i];
      attributes[attr.name] = attr.value;
    }

    const children: XmlElement[] = [];
    const childElements = Array.from(element.children);
    
    for (const child of childElements) {
      children.push(traverseElement(child, depth + 1, currentPath));
    }

    return {
      tagName,
      attributes,
      children,
      textContent: element.textContent?.trim() || undefined,
      path: currentPath
    };
  }

  if (doc.documentElement) {
    result.structure = [traverseElement(doc.documentElement)];
  }

  result.uniqueTags = Array.from(tagSet);
  
  return result;
}

export function validateXmlAgainstXsd(xmlContent: string, xsdContent: string): { isValid: boolean; errors: string[] } {
  // Basic XSD validation - in a real implementation, you'd use a proper XSD validator
  // For now, we'll do basic structure validation
  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, 'text/xml');
    const xsdDoc = parser.parseFromString(xsdContent, 'text/xml');
    
    if (xmlDoc.documentElement.tagName === 'parsererror') {
      return { isValid: false, errors: ['Invalid XML syntax'] };
    }
    
    if (xsdDoc.documentElement.tagName === 'parsererror') {
      return { isValid: false, errors: ['Invalid XSD syntax'] };
    }
    
    // Basic validation - check if root element matches schema
    const xmlRoot = xmlDoc.documentElement.tagName;
    const schemaElements = Array.from(xsdDoc.querySelectorAll('xs\\:element, element'));
    const rootElementDefined = schemaElements.some(el => 
      el.getAttribute('name') === xmlRoot
    );
    
    if (!rootElementDefined) {
      return { 
        isValid: false, 
        errors: [`Root element '${xmlRoot}' not defined in schema`] 
      };
    }
    
    return { isValid: true, errors: [] };
  } catch (error) {
    return { 
      isValid: false, 
      errors: [error instanceof Error ? error.message : 'Unknown validation error'] 
    };
  }
}