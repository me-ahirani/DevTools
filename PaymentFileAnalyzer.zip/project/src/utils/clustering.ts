// Simple clustering algorithms implemented in TypeScript
export interface ClusterPoint {
  id: string;
  features: number[];
  cluster?: number;
}

export interface ClusterResult {
  clusters: ClusterPoint[][];
  centroids: number[][];
}

// Simple K-means clustering implementation
export function kMeansClustering(points: ClusterPoint[], k: number, maxIterations: number = 100): ClusterResult {
  if (points.length === 0 || k <= 0) {
    return { clusters: [], centroids: [] };
  }

  const dimensions = points[0].features.length;
  
  // Initialize centroids randomly
  let centroids: number[][] = [];
  for (let i = 0; i < k; i++) {
    const centroid: number[] = [];
    for (let j = 0; j < dimensions; j++) {
      const min = Math.min(...points.map(p => p.features[j]));
      const max = Math.max(...points.map(p => p.features[j]));
      centroid.push(Math.random() * (max - min) + min);
    }
    centroids.push(centroid);
  }

  for (let iteration = 0; iteration < maxIterations; iteration++) {
    // Assign points to clusters
    points.forEach(point => {
      let minDistance = Infinity;
      let closestCluster = 0;
      
      centroids.forEach((centroid, clusterIndex) => {
        const distance = euclideanDistance(point.features, centroid);
        if (distance < minDistance) {
          minDistance = distance;
          closestCluster = clusterIndex;
        }
      });
      
      point.cluster = closestCluster;
    });

    // Update centroids
    const newCentroids: number[][] = [];
    for (let i = 0; i < k; i++) {
      const clusterPoints = points.filter(p => p.cluster === i);
      if (clusterPoints.length === 0) {
        newCentroids.push([...centroids[i]]);
        continue;
      }

      const newCentroid: number[] = [];
      for (let j = 0; j < dimensions; j++) {
        const sum = clusterPoints.reduce((acc, p) => acc + p.features[j], 0);
        newCentroid.push(sum / clusterPoints.length);
      }
      newCentroids.push(newCentroid);
    }

    // Check for convergence
    let converged = true;
    for (let i = 0; i < k; i++) {
      if (euclideanDistance(centroids[i], newCentroids[i]) > 0.001) {
        converged = false;
        break;
      }
    }

    centroids = newCentroids;
    if (converged) break;
  }

  // Group points by cluster
  const clusters: ClusterPoint[][] = [];
  for (let i = 0; i < k; i++) {
    clusters.push(points.filter(p => p.cluster === i));
  }

  return { clusters, centroids };
}

function euclideanDistance(a: number[], b: number[]): number {
  return Math.sqrt(a.reduce((sum, val, i) => sum + Math.pow(val - b[i], 2), 0));
}

// Simple anomaly detection using statistical methods
export function detectAnomalies(values: number[], threshold: number = 2): number[] {
  const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
  const stdDev = Math.sqrt(variance);
  
  return values
    .map((value, index) => ({ value, index, zScore: Math.abs(value - mean) / stdDev }))
    .filter(item => item.zScore > threshold)
    .map(item => item.index);
}