import React, { useState, useEffect } from 'react';
import { Settings, Play, Loader2, ChevronDown } from 'lucide-react';
import { GenerationCriteria, MultipleOccurrenceTag } from '../types/types';

interface CriteriaSectionProps {
  criteria: GenerationCriteria;
  setCriteria: React.Dispatch<React.SetStateAction<GenerationCriteria>>;
  onGeneration: () => void;
  isGenerating: boolean;
  xsdFile: File | null;
  schemaAnalysis?: any; // Add schema analysis prop
}

const CriteriaSection: React.FC<CriteriaSectionProps> = ({
  criteria,
  setCriteria,
  onGeneration,
  isGenerating,
  xsdFile,
  schemaAnalysis,
}) => {
  const [availableTags, setAvailableTags] = useState<MultipleOccurrenceTag[]>([]);
  const [isLoadingTags, setIsLoadingTags] = useState(false);
  const [showTagDropdown, setShowTagDropdown] = useState(false);

  useEffect(() => {
    if (schemaAnalysis && schemaAnalysis.multipleOccurrenceTags) {
      setAvailableTags(schemaAnalysis.multipleOccurrenceTags);
    } else if (xsdFile && !schemaAnalysis) {
      loadMultipleOccurrenceTags();
    }
  }, [xsdFile, schemaAnalysis]);

  const loadMultipleOccurrenceTags = async () => {
    if (!xsdFile) return;

    setIsLoadingTags(true);
    try {
      // Since backend might not be available, provide mock data
      const mockTags: MultipleOccurrenceTag[] = [
        {
          name: 'DrctDbtTxInf',
          path: '/Document/CstmrDrctDbtInitn/PmtInf/DrctDbtTxInf',
          minOccurs: 1,
          maxOccurs: 'unbounded'
        },
        {
          name: 'PmtInf',
          path: '/Document/CstmrDrctDbtInitn/PmtInf',
          minOccurs: 1,
          maxOccurs: 'unbounded'
        },
        {
          name: 'CdtTrfTxInf',
          path: '/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf',
          minOccurs: 1,
          maxOccurs: 'unbounded'
        },
        {
          name: 'TxInf',
          path: '/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/TxInf',
          minOccurs: 1,
          maxOccurs: 'unbounded'
        },
        {
          name: 'InstdAmt',
          path: '/Document/*/PmtInf/*/InstdAmt',
          minOccurs: 0,
          maxOccurs: 'unbounded'
        }
      ];

      // Try to call the actual API first
      try {
        const formData = new FormData();
        formData.append('xsd_file', xsdFile);

        const response = await fetch('/api/analyze-xsd', {
          method: 'POST',
          body: formData,
        });

        if (response.ok) {
          const data = await response.json();
          setAvailableTags(data.multipleOccurrenceTags || mockTags);
        } else {
          // Fallback to mock data
          setAvailableTags(mockTags);
        }
      } catch (error) {
        // Fallback to mock data if API fails
        console.log('API not available, using mock data');
        setAvailableTags(mockTags);
      }
    } catch (error) {
      console.error('Failed to load multiple occurrence tags:', error);
      setAvailableTags([]);
    }
    setIsLoadingTags(false);
  };

  const updateCriteria = (key: keyof GenerationCriteria, value: any) => {
    setCriteria(prev => ({ ...prev, [key]: value }));
  };

  const toggleTag = (tagName: string) => {
    setCriteria(prev => ({
      ...prev,
      selectedTags: prev.selectedTags.includes(tagName)
        ? prev.selectedTags.filter(t => t !== tagName)
        : [...prev.selectedTags, tagName],
    }));
  };

  const totalFiles = criteria.randomData + criteria.mandatoryOnly + 
                    criteria.multipleOccurrence + criteria.anomalies;

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100 mb-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-purple-100 rounded-lg">
          <Settings className="h-6 w-6 text-purple-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Test Data Generation Criteria</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Random Data */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-gray-700">
            Random Data Files
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              value={criteria.randomData}
              onChange={(e) => updateCriteria('randomData', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="25"
            />
          </div>
          <p className="text-sm text-gray-600">
            Files with random numbers, amounts, currencies, and strings based on schema
          </p>
        </div>

        {/* Mandatory Only */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-gray-700">
            Mandatory Records Only
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              value={criteria.mandatoryOnly}
              onChange={(e) => updateCriteria('mandatoryOnly', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0"
            />
          </div>
          <p className="text-sm text-gray-600">
            Files with only mandatory fields populated with random data
          </p>
        </div>

        {/* Multiple Occurrence */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-gray-700">
            Multiple Occurrence Tags
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              value={criteria.multipleOccurrence}
              onChange={(e) => updateCriteria('multipleOccurrence', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0"
            />
          </div>
          <p className="text-sm text-gray-600">
            Files with tags that can occur multiple times
          </p>
        </div>

        {/* Anomaly Files */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-gray-700">
            Anomaly Files
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              value={criteria.anomalies}
              onChange={(e) => updateCriteria('anomalies', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0"
            />
          </div>
          <p className="text-sm text-gray-600">
            Files with anomalies (non-English characters, incorrect data types)
          </p>
        </div>
      </div>

      {/* Multiple Occurrence Tags Selection */}
      {criteria.multipleOccurrence > 0 && (
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Select Multiple Occurrence Tags
          </label>
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowTagDropdown(!showTagDropdown)}
              disabled={isLoadingTags || availableTags.length === 0}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-left flex items-center justify-between disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <span className="text-gray-700">
                {isLoadingTags ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Loading tags...
                  </div>
                ) : 
                 availableTags.length === 0 ? 'No multiple occurrence tags found' :
                 criteria.selectedTags.length === 0 ? 'Select tags' : 
                 `${criteria.selectedTags.length} tag(s) selected`}
              </span>
              <ChevronDown className={`h-5 w-5 text-gray-400 transition-transform ${
                showTagDropdown ? 'transform rotate-180' : ''
              }`} />
            </button>

            {showTagDropdown && availableTags.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-auto">
                {availableTags.map((tag) => (
                  <div
                    key={tag.name}
                    className="flex items-center px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                    onClick={() => toggleTag(tag.name)}
                  >
                    <input
                      type="checkbox"
                      checked={criteria.selectedTags.includes(tag.name)}
                      onChange={() => {}}
                      className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <div className="ml-3 flex-1">
                      <p className="text-sm font-medium text-gray-900">{tag.name}</p>
                      <p className="text-xs text-gray-500 font-mono">
                        {tag.path}
                      </p>
                      <p className="text-xs text-gray-400">
                        Occurs: {tag.minOccurs} to {tag.maxOccurs === 'unbounded' ? '∞' : tag.maxOccurs}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Selected Tags Display */}
          {criteria.selectedTags.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium text-gray-700 mb-2">Selected Tags:</p>
              <div className="flex flex-wrap gap-2">
                {criteria.selectedTags.map((tagName) => (
                  <span
                    key={tagName}
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {tagName}
                    <button
                      onClick={() => toggleTag(tagName)}
                      className="ml-2 text-blue-600 hover:text-blue-800"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Summary */}
      <div className="bg-gray-50 rounded-xl p-4 mb-6">
        <h3 className="font-semibold text-gray-800 mb-2">Generation Summary</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600">
              Total files to generate: <span className="font-semibold text-blue-600">{totalFiles}</span>
            </p>
            {totalFiles === 0 && (
              <p className="text-amber-600 text-sm mt-1">
                Default: 25 random data files will be generated if no criteria is specified
              </p>
            )}
          </div>
          {criteria.selectedTags.length > 0 && (
            <div>
              <p className="text-gray-600">
                Selected multiple occurrence tags: <span className="font-semibold text-purple-600">{criteria.selectedTags.length}</span>
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={onGeneration}
        disabled={!xsdFile || isGenerating}
        className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
      >
        {isGenerating ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            Generating Files...
          </>
        ) : (
          <>
            <Play className="h-5 w-5" />
            Generate Files
          </>
        )}
      </button>
    </div>
  );
};

export default CriteriaSection;