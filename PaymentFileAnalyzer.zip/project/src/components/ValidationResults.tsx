import React from 'react';
import { CheckCircle, XCircle, AlertCircle, Clock } from 'lucide-react';
import { ValidationResult } from '../types/types';

interface ValidationResultsProps {
  validationResult: ValidationResult | null;
}

const ValidationResults: React.FC<ValidationResultsProps> = ({ validationResult }) => {
  if (!validationResult) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gray-100 rounded-lg">
            <CheckCircle className="h-6 w-6 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Validation Results</h2>
        </div>
        <div className="text-center py-8">
          <Clock className="mx-auto h-12 w-12 text-gray-300 mb-3" />
          <p className="text-gray-500">Upload files and click validate to see results</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className={`p-2 rounded-lg ${
          validationResult.isValid ? 'bg-green-100' : 'bg-red-100'
        }`}>
          {validationResult.isValid ? (
            <CheckCircle className="h-6 w-6 text-green-600" />
          ) : (
            <XCircle className="h-6 w-6 text-red-600" />
          )}
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Validation Results</h2>
      </div>

      {/* Status */}
      <div className={`p-4 rounded-xl mb-4 ${
        validationResult.isValid 
          ? 'bg-green-50 border border-green-200' 
          : 'bg-red-50 border border-red-200'
      }`}>
        <div className="flex items-center gap-2">
          {validationResult.isValid ? (
            <CheckCircle className="h-5 w-5 text-green-600" />
          ) : (
            <XCircle className="h-5 w-5 text-red-600" />
          )}
          <span className={`font-semibold ${
            validationResult.isValid ? 'text-green-800' : 'text-red-800'
          }`}>
            {validationResult.isValid ? 'Validation Successful' : 'Validation Failed'}
          </span>
        </div>
        <p className="text-sm text-gray-600 mt-1">
          Validated on {new Date(validationResult.timestamp).toLocaleString()}
        </p>
      </div>

      {/* Errors */}
      {validationResult.errors.length > 0 && (
        <div className="mb-4">
          <h3 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
            <XCircle className="h-4 w-4" />
            Errors ({validationResult.errors.length})
          </h3>
          <div className="space-y-2">
            {validationResult.errors.map((error, index) => (
              <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Warnings */}
      {validationResult.warnings && validationResult.warnings.length > 0 && (
        <div className="mb-4">
          <h3 className="font-semibold text-amber-800 mb-2 flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            Warnings ({validationResult.warnings.length})
          </h3>
          <div className="space-y-2">
            {validationResult.warnings.map((warning, index) => (
              <div key={index} className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-sm text-amber-700">{warning}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {validationResult.isValid && validationResult.errors.length === 0 && (
        <div className="text-center py-4">
          <p className="text-green-600 font-medium">
            File successfully validates against the XSD schema
          </p>
        </div>
      )}
    </div>
  );
};

export default ValidationResults;