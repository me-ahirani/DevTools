import React from 'react';
import { FileText, BarChart3, Clock, CheckCircle, XCircle, AlertCircle, TrendingUp, Hash } from 'lucide-react';
import XsdTreeNode from './XsdTreeNode'; // Adjust the import path as necessary

interface XmlAnalysisResultsProps {
  xmlAnalysis: any;
}

const XmlAnalysisResults: React.FC<XmlAnalysisResultsProps> = ({ xmlAnalysis }) => {
  if (!xmlAnalysis) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-gray-100 rounded-lg">
            <FileText className="h-5 w-5 text-gray-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-900">XML Analysis</h3>
        </div>
        <div className="text-center py-6">
          <Clock className="mx-auto h-10 w-10 text-gray-300 mb-2" />
          <p className="text-gray-500 text-sm">Upload and analyze XML file to see results</p>
        </div>
      </div>
    );
  }

  if (!xmlAnalysis.isValid) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-red-100 rounded-lg">
            <XCircle className="h-5 w-5 text-red-600" />
          </div>
          <h3 className="text-lg font-bold text-gray-900">XML Analysis</h3>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <XCircle className="h-4 w-4 text-red-600" />
            <span className="font-semibold text-red-800">Invalid XML</span>
          </div>
          <p className="text-sm text-red-700">{xmlAnalysis.error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-green-100 rounded-lg">
          <CheckCircle className="h-5 w-5 text-green-600" />
        </div>
        <h3 className="text-lg font-bold text-gray-900">XML Analysis Results</h3>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 text-xs font-semibold">Elements</p>
              <p className="text-xl font-bold text-blue-900">{xmlAnalysis.elementCount}</p>
            </div>
            <Hash className="h-6 w-6 text-blue-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-xs font-semibold">Unique Tags</p>
              <p className="text-xl font-bold text-green-900">{xmlAnalysis.uniqueTags.length}</p>
            </div>
            <FileText className="h-6 w-6 text-green-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-600 text-xs font-semibold">Max Depth</p>
              <p className="text-xl font-bold text-purple-900">{xmlAnalysis.maxDepth}</p>
            </div>
            <TrendingUp className="h-6 w-6 text-purple-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-600 text-xs font-semibold">File Size</p>
              <p className="text-xl font-bold text-orange-900">{(xmlAnalysis.fileSize / 1024).toFixed(1)}KB</p>
            </div>
            <BarChart3 className="h-6 w-6 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Detailed Information */}
      <div className="space-y-4">
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-semibold text-gray-800 mb-3 text-sm">Document Information</h4>
          <div className="grid grid-cols-1 gap-3 text-sm">
            <div>
              <span className="text-gray-600">Root Element:</span>
              <span className="ml-2 font-medium text-gray-900">{xmlAnalysis.rootElement || (xmlAnalysis.rootElements && xmlAnalysis.rootElements.join(', '))}</span>
            </div>
            {xmlAnalysis.namespace || xmlAnalysis.targetNamespace ? (
              <div>
                <span className="text-gray-600">Namespace:</span>
                <p className="font-mono text-xs text-gray-800 mt-1 break-all">
                  {xmlAnalysis.namespace || xmlAnalysis.targetNamespace}
                </p>
              </div>
            ) : null}
            <div>
              <span className="text-gray-600">Complexity Score:</span>
              <span className="ml-2 font-medium text-gray-900">{xmlAnalysis.complexity || (xmlAnalysis.statistics && xmlAnalysis.statistics.complexTypes)}</span>
            </div>
            {xmlAnalysis.statistics && (
              <div className="grid grid-cols-2 gap-2 mt-2">
                <div><span className="text-gray-600">Total Elements:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.totalElements}</span></div>
                <div><span className="text-gray-600">Total Types:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.totalTypes}</span></div>
                <div><span className="text-gray-600">Complex Types:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.complexTypes}</span></div>
                <div><span className="text-gray-600">Simple Types:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.simpleTypes}</span></div>
                <div><span className="text-gray-600">Multiple Occurrence Elements:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.multipleOccurrenceElements}</span></div>
                <div><span className="text-gray-600">Mandatory Elements:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.mandatoryElements}</span></div>
                <div><span className="text-gray-600">Optional Elements:</span> <span className="ml-1 text-gray-900">{xmlAnalysis.statistics.optionalElements}</span></div>
              </div>
            )}
          </div>
        </div>

        {/* Multiple Occurrence Tags */}
        {xmlAnalysis.multipleOccurrenceTags && xmlAnalysis.multipleOccurrenceTags.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Multiple Occurrence Tags ({xmlAnalysis.multipleOccurrenceTags.length})</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full text-xs text-left">
                <thead>
                  <tr className="text-gray-600">
                    <th className="px-2 py-1">Name</th>
                    <th className="px-2 py-1">Path</th>
                    <th className="px-2 py-1">Type</th>
                    <th className="px-2 py-1">minOccurs</th>
                    <th className="px-2 py-1">maxOccurs</th>
                    <th className="px-2 py-1">Mandatory</th>
                    <th className="px-2 py-1">Complex</th>
                    <th className="px-2 py-1">Documentation</th>
                  </tr>
                </thead>
                <tbody>
                  {xmlAnalysis.multipleOccurrenceTags.map((tag: any, idx: number) => (
                    <tr key={idx} className="border-b last:border-b-0">
                      <td className="px-2 py-1 font-mono">{tag.name}</td>
                      <td className="px-2 py-1 font-mono">{tag.path}</td>
                      <td className="px-2 py-1 font-mono">{tag.type}</td>
                      <td className="px-2 py-1">{tag.minOccurs}</td>
                      <td className="px-2 py-1">{tag.maxOccurs}</td>
                      <td className="px-2 py-1">{tag.isMandatory ? 'Yes' : 'No'}</td>
                      <td className="px-2 py-1">{tag.isComplex ? 'Yes' : 'No'}</td>
                      <td className="px-2 py-1">{tag.documentation || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tags Overview */}
        {xmlAnalysis.uniqueTags.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Element Tags ({xmlAnalysis.uniqueTags.length})</h4>
            <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
              {xmlAnalysis.uniqueTags.slice(0, 20).map((tag: string, index: number) => (
                <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                  {tag}
                </span>
              ))}
              {xmlAnalysis.uniqueTags.length > 20 && (
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded text-xs">
                  +{xmlAnalysis.uniqueTags.length - 20} more
                </span>
              )}
            </div>
          </div>
        )}

        {/* Attributes */}
        {Object.keys(xmlAnalysis.attributes).length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Attributes Used</h4>
            <div className="space-y-2 max-h-24 overflow-y-auto">
              {Object.entries(xmlAnalysis.attributes).map(([attr, count]) => (
                <div key={attr} className="flex justify-between items-center text-sm">
                  <span className="text-gray-700">{attr}</span>
                  <span className="text-gray-500">{count} times</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* XSD Schema Tree */}
        {xmlAnalysis.hierarchy && Object.keys(xmlAnalysis.hierarchy).length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Schema Structure</h4>
            {Object.entries(xmlAnalysis.hierarchy).map(([root, tree]: any) => (
              <div key={root} className="mb-2">
                <span className="font-bold text-blue-700">{root}</span>
                <XsdTreeNode node={tree} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default XmlAnalysisResults;