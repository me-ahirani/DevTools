import React from 'react';
import { FileText, BarChart3, Clock, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';

interface SchemaAnalysisResultsProps {
  schemaAnalysis: any;
}

const SchemaAnalysisResults: React.FC<SchemaAnalysisResultsProps> = ({ schemaAnalysis }) => {
  if (!schemaAnalysis) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gray-100 rounded-lg">
            <BarChart3 className="h-6 w-6 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Schema Analysis</h2>
        </div>
        <div className="text-center py-8">
          <Clock className="mx-auto h-12 w-12 text-gray-300 mb-3" />
          <p className="text-gray-500">Upload and analyze XSD schema to see results</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-green-100 rounded-lg">
          <BarChart3 className="h-6 w-6 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Schema Analysis Results</h2>
      </div>

      {/* Statistics Overview */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 text-sm font-semibold">Total Elements</p>
              <p className="text-2xl font-bold text-blue-900">{schemaAnalysis.statistics.totalElements}</p>
            </div>
            <FileText className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-semibold">Complex Types</p>
              <p className="text-2xl font-bold text-green-900">{schemaAnalysis.statistics.complexTypes}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-600 text-sm font-semibold">Simple Types</p>
              <p className="text-2xl font-bold text-purple-900">{schemaAnalysis.statistics.simpleTypes}</p>
            </div>
            <BarChart3 className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-600 text-sm font-semibold">Attributes</p>
              <p className="text-2xl font-bold text-orange-900">{schemaAnalysis.statistics.totalAttributes}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Schema Information */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="font-semibold text-gray-800 mb-4">Schema Details</h3>
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-gray-600">Target Namespace:</span>
              <p className="font-mono text-xs text-gray-800 mt-1 break-all">
                {schemaAnalysis.targetNamespace}
              </p>
            </div>
            <div>
              <span className="text-gray-600">Root Elements:</span>
              <div className="flex flex-wrap gap-2 mt-1">
                {schemaAnalysis.rootElements.map((element: string, index: number) => (
                  <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                    {element}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="font-semibold text-gray-800 mb-4">Type Distribution</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Complex Types</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full"
                    style={{ 
                      width: `${(schemaAnalysis.statistics.complexTypes / schemaAnalysis.statistics.totalTypes) * 100}%` 
                    }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{schemaAnalysis.statistics.complexTypes}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Simple Types</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full"
                    style={{ 
                      width: `${(schemaAnalysis.statistics.simpleTypes / schemaAnalysis.statistics.totalTypes) * 100}%` 
                    }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{schemaAnalysis.statistics.simpleTypes}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Multiple Occurrence Tags */}
      {schemaAnalysis.multipleOccurrenceTags && schemaAnalysis.multipleOccurrenceTags.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <h3 className="font-semibold text-amber-800">Multiple Occurrence Elements</h3>
          </div>
          <div className="space-y-3">
            {schemaAnalysis.multipleOccurrenceTags.map((tag: any, index: number) => (
              <div key={index} className="bg-white rounded-lg p-4 border border-amber-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{tag.name}</span>
                  <span className="text-sm text-gray-600">
                    {tag.minOccurs} - {tag.maxOccurs === 'unbounded' ? '∞' : tag.maxOccurs}
                  </span>
                </div>
                <p className="text-sm text-gray-600 font-mono">{tag.path}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SchemaAnalysisResults;