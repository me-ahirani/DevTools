import React from 'react';
import { Settings, Folder, FileText, Sliders } from 'lucide-react';
import { Job, JobConfiguration as JobConfigurationType } from '../types/jobTypes';

interface JobConfigurationProps {
  configuration: JobConfigurationType;
  setConfiguration: React.Dispatch<React.SetStateAction<JobConfigurationType>>;
  jobs: Job[];
}

const JobConfiguration: React.FC<JobConfigurationProps> = ({
  configuration,
  setConfiguration,
  jobs,
}) => {
  const updateConfiguration = (key: keyof JobConfigurationType, value: any) => {
    setConfiguration(prev => ({ ...prev, [key]: value }));
  };

  const toggleJob = (jobId: string) => {
    setConfiguration(prev => ({
      ...prev,
      enabledJobs: prev.enabledJobs.includes(jobId)
        ? prev.enabledJobs.filter(id => id !== jobId)
        : [...prev.enabledJobs, jobId],
    }));
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-purple-100 rounded-lg">
          <Settings className="h-6 w-6 text-purple-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Job Configuration</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Path Configuration */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            <Folder className="h-5 w-5" />
            Path Configuration
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Test Suite Path
              </label>
              <input
                type="text"
                value={configuration.testSuitePath}
                onChange={(e) => updateConfiguration('testSuitePath', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="./Test_Suite"
              />
              <p className="text-sm text-gray-600 mt-1">
                Local path to Test_Suite folder containing payment files
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                XSD Schema Path
              </label>
              <input
                type="text"
                value={configuration.xsdPath}
                onChange={(e) => updateConfiguration('xsdPath', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="./schemas/payment.xsd"
              />
              <p className="text-sm text-gray-600 mt-1">
                Path to XSD schema file for validation
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Output Path
              </label>
              <input
                type="text"
                value={configuration.outputPath}
                onChange={(e) => updateConfiguration('outputPath', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="./Test_Suite/output"
              />
              <p className="text-sm text-gray-600 mt-1">
                Output directory for clustered files
              </p>
            </div>
          </div>
        </div>

        {/* Algorithm Configuration */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            <Sliders className="h-5 w-5" />
            Algorithm Configuration
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Uniqueness Threshold
              </label>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.1"
                value={configuration.uniquenessThreshold}
                onChange={(e) => updateConfiguration('uniquenessThreshold', parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-gray-600">
                <span>0.1 (Less Unique)</span>
                <span className="font-semibold">{configuration.uniquenessThreshold}</span>
                <span>1.0 (More Unique)</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Cosine similarity threshold for determining file uniqueness
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">Clustering Algorithm</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• DBSCAN with cosine distance</li>
                <li>• DictVectorizer for feature extraction</li>
                <li>• XML tag structure analysis</li>
                <li>• Content similarity comparison</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Job Selection */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
          <FileText className="h-5 w-5" />
          Job Selection
        </h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          {jobs.map((job) => (
            <div
              key={job.id}
              className={`border rounded-xl p-4 cursor-pointer transition-all duration-200 ${
                configuration.enabledJobs.includes(job.id)
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onClick={() => toggleJob(job.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <input
                      type="checkbox"
                      checked={configuration.enabledJobs.includes(job.id)}
                      onChange={() => toggleJob(job.id)}
                      className="h-4 w-4 text-blue-600 rounded"
                    />
                    <h4 className="font-semibold text-gray-900">{job.name}</h4>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{job.description}</p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>Priority: {job.priority}</span>
                    <span>~{Math.floor(job.estimatedDuration / 60)}m {job.estimatedDuration % 60}s</span>
                    <span className={`px-2 py-1 rounded-full ${
                      job.type === 'clustering' ? 'bg-blue-100 text-blue-700' :
                      job.type === 'anomaly-detection' ? 'bg-red-100 text-red-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {job.type}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default JobConfiguration;