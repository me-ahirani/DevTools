import React, { useState, useEffect } from 'react';
import { Play, Clock, CheckCircle, XCircle, Loader, Square } from 'lucide-react';
import { JobConfiguration, JobExecution as JobExecutionType } from '../types/jobTypes';

interface JobExecutionProps {
  configuration: JobConfiguration;
  jobs: any[];
  jobExecutions: JobExecutionType[];
  isExecuting: boolean;
  onExecute: () => void;
  onStop: () => void;
}

export default function JobExecution({ 
  configuration, 
  jobs, 
  jobExecutions, 
  isExecuting, 
  onExecute, 
  onStop 
}: JobExecutionProps) {
  const getOverallStatus = () => {
    if (isExecuting) return 'running';
    if (jobExecutions.length === 0) return 'ready';
    
    const hasFailures = jobExecutions.some(job => job.status === 'failed');
    const allCompleted = jobExecutions.every(job => job.status === 'completed');
    
    if (hasFailures) return 'failed';
    if (allCompleted) return 'completed';
    return 'partial';
  };

  const getStatusIcon = () => {
    const status = getOverallStatus();
    
    switch (status) {
      case 'running':
        return <Loader className="w-5 h-5 animate-spin" />;
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'partial':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <Play className="w-5 h-5" />;
    }
  };

  const getStatusText = () => {
    const status = getOverallStatus();
    
    switch (status) {
      case 'running':
        return 'Executing jobs...';
      case 'completed':
        return 'All jobs completed successfully';
      case 'failed':
        return 'Some jobs failed';
      case 'partial':
        return 'Jobs partially completed';
      default:
        return 'Ready to execute';
    }
  };

  const getOverallProgress = () => {
    if (jobExecutions.length === 0) return 0;
    
    const totalProgress = jobExecutions.reduce((sum, job) => sum + (job.progress || 0), 0);
    return Math.round(totalProgress / jobExecutions.length);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Job Execution</h3>
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          {getStatusIcon()}
          <span>{getStatusText()}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-2">Job Configuration</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Job Type:</span>
              <span className="ml-2 font-medium">{configuration.jobType?.replace('_', ' ') || 'Not specified'}</span>
            </div>
            <div>
              <span className="text-gray-600">Total Jobs:</span>
              <span className="ml-2 font-medium">{jobs.length}</span>
            </div>
            <div>
              <span className="text-gray-600">Completed:</span>
              <span className="ml-2 font-medium">{jobExecutions.filter(job => job.status === 'completed').length}</span>
            </div>
            <div>
              <span className="text-gray-600">Failed:</span>
              <span className="ml-2 font-medium">{jobExecutions.filter(job => job.status === 'failed').length}</span>
            </div>
          </div>
        </div>

        {isExecuting && (
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-900">Overall Progress</span>
              <span className="text-sm text-blue-700">{getOverallProgress()}%</span>
            </div>
            <div className="w-full bg-blue-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${getOverallProgress()}%` }}
              />
            </div>
          </div>
        )}

        {jobExecutions.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">Job Status</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {jobExecutions.map((job, index) => (
                <div key={job.id || index} className="flex items-center justify-between text-sm">
                  <span className="text-gray-700">Job {index + 1}</span>
                  <div className="flex items-center space-x-2">
                    {job.status === 'running' && <Loader className="w-4 h-4 animate-spin text-blue-500" />}
                    {job.status === 'completed' && <CheckCircle className="w-4 h-4 text-green-500" />}
                    {job.status === 'failed' && <XCircle className="w-4 h-4 text-red-500" />}
                    <span className={`
                      ${job.status === 'completed' ? 'text-green-600' : ''}
                      ${job.status === 'failed' ? 'text-red-600' : ''}
                      ${job.status === 'running' ? 'text-blue-600' : ''}
                    `}>
                      {job.status === 'running' ? `${job.progress || 0}%` : job.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {jobExecutions.some(job => job.status === 'failed') && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <h4 className="font-medium text-red-900 mb-2">Error Details</h4>
            <div className="space-y-1 text-sm text-red-700 max-h-32 overflow-y-auto">
              {jobExecutions
                .filter(job => job.status === 'failed')
                .map((job, index) => (
                  <div key={job.id || index}>
                    <strong>Job {jobExecutions.indexOf(job) + 1}:</strong> {job.error || 'Unknown error'}
                  </div>
                ))}
            </div>
          </div>
        )}

        <div className="flex justify-center space-x-4">
          <button
            onClick={onExecute}
            disabled={isExecuting || jobs.length === 0}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            {isExecuting ? (
              <>
                <Loader className="w-4 h-4 animate-spin" />
                <span>Executing...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Execute Jobs</span>
              </>
            )}
          </button>
          
          {isExecuting && (
            <button
              onClick={onStop}
              className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center space-x-2"
            >
              <Square className="w-4 h-4" />
              <span>Stop</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}