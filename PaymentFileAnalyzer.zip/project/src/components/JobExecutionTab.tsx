import React, { useState, useEffect } from 'react';
import { Play, Settings, Clock, CheckCircle, XCircle, AlertCircle, Folder, FileText, BarChart3 } from 'lucide-react';
import JobConfiguration from './JobConfiguration';
import JobExecution from './JobExecution';
import JobResults from './JobResults';
import { Job, JobExecution as JobExecutionType, JobConfiguration as JobConfigurationType } from '../types/jobTypes';

const JobExecutionTab: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jobExecutions, setJobExecutions] = useState<JobExecutionType[]>([]);
  const [configuration, setConfiguration] = useState<JobConfigurationType>({
    testSuitePath: './Test_Suite',
    xsdPath: '',
    outputPath: './Test_Suite/output',
    uniquenessThreshold: 0.8,
    enabledJobs: [],
  });
  const [isExecuting, setIsExecuting] = useState(false);

  useEffect(() => {
    // Initialize available jobs
    const availableJobs: Job[] = [
      {
        id: 'schema-cluster',
        name: 'Scan and Create Schema Clusters',
        description: 'Create folder with schema name and today\'s date. Scan all payment files and create clusters based on schema type. Copy schema validated files into the created folder.',
        type: 'clustering',
        status: 'ready',
        priority: 1,
        estimatedDuration: 300,
        dependencies: [],
      },
      {
        id: 'tag-match-cluster',
        name: 'Create Tag Match Clusters',
        description: 'Create clusters based on matched tags (structure match). All tags are matched but data may differ. Create folder "All_Tag_Matched" and copy matched XML files.',
        type: 'clustering',
        status: 'ready',
        priority: 2,
        estimatedDuration: 240,
        dependencies: ['schema-cluster'],
      },
      {
        id: 'tag-data-cluster',
        name: 'Create Tag + Data Match Clusters',
        description: 'Create clusters where both tags and data are matched. Multiple folders like "All_Tag_Matched_2" for files with 2 transactions, etc.',
        type: 'clustering',
        status: 'ready',
        priority: 3,
        estimatedDuration: 360,
        dependencies: ['schema-cluster'],
      },
      {
        id: 'anomaly-cluster',
        name: 'Create Anomaly Clusters',
        description: 'Create clusters based on payment anomalies: non-English characters (Chinese, European), incorrect data types (string instead of number).',
        type: 'anomaly-detection',
        status: 'ready',
        priority: 4,
        estimatedDuration: 180,
        dependencies: ['schema-cluster'],
      },
      {
        id: 'unique-sample-cluster',
        name: 'Create Unique Sample Clusters',
        description: 'Pick one file from each cluster set and create "unique_test_set" folder. Uniqueness defined by job configuration threshold.',
        type: 'sampling',
        status: 'ready',
        priority: 5,
        estimatedDuration: 120,
        dependencies: ['tag-match-cluster', 'tag-data-cluster'],
      },
      {
        id: 'tag-specific-cluster',
        name: 'Create Tag-Specific Clusters',
        description: 'Create clusters based on specific tag names like country tag or currency tag. Configurable tag selection.',
        type: 'clustering',
        status: 'ready',
        priority: 6,
        estimatedDuration: 200,
        dependencies: ['schema-cluster'],
      },
    ];

    setJobs(availableJobs);
    setConfiguration(prev => ({
      ...prev,
      enabledJobs: availableJobs.map(job => job.id),
    }));
  }, []);

  const handleExecuteJobs = async () => {
    setIsExecuting(true);
    
    try {
      const response = await fetch('/api/jobs/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          configuration,
          enabledJobs: configuration.enabledJobs,
        }),
      });

      if (response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n').filter(line => line.trim());

          for (const line of lines) {
            try {
              const data = JSON.parse(line);
              if (data.type === 'job_update') {
                setJobExecutions(prev => {
                  const existing = prev.find(exec => exec.jobId === data.jobId);
                  if (existing) {
                    return prev.map(exec => 
                      exec.jobId === data.jobId 
                        ? { ...exec, ...data.execution }
                        : exec
                    );
                  } else {
                    return [...prev, { jobId: data.jobId, ...data.execution }];
                  }
                });
              }
            } catch (e) {
              console.error('Failed to parse job update:', e);
            }
          }
        }
      }
    } catch (error) {
      console.error('Failed to execute jobs:', error);
    }
    
    setIsExecuting(false);
  };

  const handleStopExecution = async () => {
    try {
      await fetch('/api/jobs/stop', {
        method: 'POST',
      });
      setIsExecuting(false);
    } catch (error) {
      console.error('Failed to stop job execution:', error);
    }
  };

  return (
    <div className="space-y-8">
      {/* Job Configuration */}
      <JobConfiguration
        configuration={configuration}
        setConfiguration={setConfiguration}
        jobs={jobs}
      />

      {/* Job Execution Controls */}
      <JobExecution
        jobs={jobs}
        jobExecutions={jobExecutions}
        isExecuting={isExecuting}
        onExecute={handleExecuteJobs}
        onStop={handleStopExecution}
        configuration={configuration}
      />

      {/* Job Results */}
      <JobResults
        jobExecutions={jobExecutions}
        jobs={jobs}
      />
    </div>
  );
};

export default JobExecutionTab;