import React, { useState } from 'react';
import { Upload, FileCheck, Settings, Download, Play, CheckCircle, XCircle, AlertCircle, FileText, Archive } from 'lucide-react';
import FileUploadSection from './FileUploadSection';
import CriteriaSection from './CriteriaSection';
import GenerationResults from './GenerationResults';
import SchemaAnalysisResults from './SchemaAnalysisResults';
import XmlAnalysisResults from './XmlAnalysisResults';
import { GenerationCriteria, GeneratedFile } from '../types/types';
import { xmlGenerator } from '../utils/xmlGenerator';

const FileAnalyzerTab: React.FC = () => {
  const [uploadedFiles, setUploadedFiles] = useState<{
    xmlFile: File | null;
    xsdFile: File | null;
  }>({
    xmlFile: null,
    xsdFile: null,
  });

  const [criteria, setCriteria] = useState<GenerationCriteria>({
    randomData: 25,
    mandatoryOnly: 0,
    multipleOccurrence: 0,
    anomalies: 0,
    selectedTags: [],
  });

  const [schemaAnalysis, setSchemaAnalysis] = useState<any>(null);
  const [xmlAnalysis, setXmlAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isAnalyzingXml, setIsAnalyzingXml] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([]);
  const [generationProgress, setGenerationProgress] = useState(0);

  const handleSchemaAnalysis = async () => {
    if (!uploadedFiles.xsdFile) {
      alert('Please upload XSD schema file');
      return;
    }

    setIsAnalyzing(true);
    try {
      // Read the XSD file and parse it
      const xsdContent = await readFileAsText(uploadedFiles.xsdFile);
      const schema = xmlGenerator.parseXsdSchema(xsdContent);
      
      // Helper functions defined locally
      const countTotalElements = (element: any): number => {
        let count = 1;
        if (element.children) {
          element.children.forEach((child: any) => {
            count += countTotalElements(child);
          });
        }
        return count;
      };

      const countTotalAttributes = (element: any): number => {
        let count = element.attributes ? element.attributes.length : 0;
        if (element.children) {
          element.children.forEach((child: any) => {
            count += countTotalAttributes(child);
          });
        }
        return count;
      };

      const buildHierarchy = (element: any): any => {
        return {
          name: element.name,
          type: element.isComplexType ? 'ComplexType' : 'SimpleType',
          minOccurs: element.minOccurs,
          maxOccurs: element.maxOccurs,
          children: element.children ? element.children.map((child: any) => buildHierarchy(child)) : []
        };
      };
      
      // Extract multiple occurrence tags from parsed schema
      const multipleOccurrenceTags: any[] = [];
      
      function extractMultipleOccurrenceTags(element: any, path: string = '') {
        const currentPath = path ? `${path}/${element.name}` : element.name;
        
        if (element.maxOccurs && (element.maxOccurs === 'unbounded' || element.maxOccurs > 1)) {
          multipleOccurrenceTags.push({
            name: element.name,
            path: currentPath,
            minOccurs: element.minOccurs,
            maxOccurs: element.maxOccurs
          });
        }
        
        if (element.children) {
          element.children.forEach((child: any) => {
            extractMultipleOccurrenceTags(child, currentPath);
          });
        }
      }
      
      extractMultipleOccurrenceTags(schema.rootElement);
      
      // Count types
      const complexTypeCount = schema.complexTypes.size;
      const simpleTypeCount = schema.simpleTypes.size;
      
      const analysis = {
        multipleOccurrenceTags,
        statistics: {
          totalElements: countTotalElements(schema.rootElement),
          totalTypes: complexTypeCount + simpleTypeCount,
          complexTypes: complexTypeCount,
          simpleTypes: simpleTypeCount,
          totalAttributes: countTotalAttributes(schema.rootElement)
        },
        hierarchy: {
          [schema.rootElement.name]: buildHierarchy(schema.rootElement)
        },
        targetNamespace: schema.targetNamespace,
        rootElements: [schema.rootElement.name]
      };
      
      setSchemaAnalysis(analysis);
    } catch (error) {
      console.error('Schema analysis error:', error);
      alert('Schema analysis failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
    setIsAnalyzing(false);
  };

  const handleXmlAnalysis = async () => {
    if (!uploadedFiles.xmlFile) {
      alert('Please upload XML file');
      return;
    }

    setIsAnalyzingXml(true);
    try {
      // Read and analyze the XML file
      const xmlContent = await readFileAsText(uploadedFiles.xmlFile);
      const analysis = analyzeXmlContent(xmlContent);
      setXmlAnalysis(analysis);
    } catch (error) {
      alert('XML analysis failed');
    }
    setIsAnalyzingXml(false);
  };

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  };

  const analyzeXmlContent = (xmlContent: string) => {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(xmlContent, 'text/xml');
      
      if (doc.documentElement.tagName === 'parsererror') {
        throw new Error('Invalid XML content');
      }

      const analysis = {
        isValid: true,
        rootElement: doc.documentElement.tagName,
        namespace: doc.documentElement.namespaceURI,
        elementCount: 0,
        uniqueTags: new Set<string>(),
        maxDepth: 0,
        attributes: new Map<string, number>(),
        textNodes: 0,
        structure: []
      };

      function traverseElement(element: Element, depth = 0, path = '') {
        analysis.elementCount++;
        analysis.maxDepth = Math.max(analysis.maxDepth, depth);
        analysis.uniqueTags.add(element.tagName);
        
        // Count attributes
        for (let i = 0; i < element.attributes.length; i++) {
          const attr = element.attributes[i];
          const count = analysis.attributes.get(attr.name) || 0;
          analysis.attributes.set(attr.name, count + 1);
        }

        // Count text nodes
        if (element.textContent && element.textContent.trim()) {
          analysis.textNodes++;
        }

        // Traverse children
        for (const child of element.children) {
          traverseElement(child, depth + 1, `${path}/${element.tagName}`);
        }
      }

      traverseElement(doc.documentElement);

      return {
        ...analysis,
        uniqueTags: Array.from(analysis.uniqueTags),
        attributes: Object.fromEntries(analysis.attributes),
        fileSize: xmlContent.length,
        hasNamespace: !!analysis.namespace,
        complexity: analysis.elementCount + analysis.uniqueTags.size + analysis.maxDepth
      };
    } catch (error) {
      return {
        isValid: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        fileSize: xmlContent.length
      };
    }
  };

  const handleGeneration = async () => {
    if (!uploadedFiles.xsdFile) {
      alert('Please upload XSD schema file');
      return;
    }

    const totalFiles = criteria.randomData + criteria.mandatoryOnly + 
                      criteria.multipleOccurrence + criteria.anomalies;
    
    if (totalFiles === 0) {
      alert('Please specify at least one file to generate');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);
    setGeneratedFiles([]);

    try {
      // Parse the XSD schema first
      const xsdContent = await readFileAsText(uploadedFiles.xsdFile);
      xmlGenerator.parseXsdSchema(xsdContent);

      const files: GeneratedFile[] = [];
      let fileIndex = 0;
      
      // Generate random data files
      for (let i = 0; i < criteria.randomData; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const xmlContent = xmlGenerator.generateXmlFromSchema('random', criteria.selectedTags, i + 1);
        
        const file: GeneratedFile = {
          id: `random_${i + 1}`,
          name: `random_data_${String(i + 1).padStart(3, '0')}.xml`,
          type: 'Random Data',
          size: xmlContent.length,
          downloadUrl: `data:text/xml;charset=utf-8,${encodeURIComponent(xmlContent)}`,
          created: new Date().toISOString(),
          content: xmlContent
        };
        
        files.push(file);
        setGeneratedFiles([...files]);
        setGenerationProgress(((++fileIndex) / totalFiles) * 100);
      }

      // Generate mandatory only files
      for (let i = 0; i < criteria.mandatoryOnly; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const xmlContent = xmlGenerator.generateXmlFromSchema('mandatory', criteria.selectedTags, i + 1);
        
        const file: GeneratedFile = {
          id: `mandatory_${i + 1}`,
          name: `mandatory_only_${String(i + 1).padStart(3, '0')}.xml`,
          type: 'Mandatory Only',
          size: xmlContent.length,
          downloadUrl: `data:text/xml;charset=utf-8,${encodeURIComponent(xmlContent)}`,
          created: new Date().toISOString(),
          content: xmlContent
        };
        
        files.push(file);
        setGeneratedFiles([...files]);
        setGenerationProgress(((++fileIndex) / totalFiles) * 100);
      }

      // Generate multiple occurrence files
      for (let i = 0; i < criteria.multipleOccurrence; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const xmlContent = xmlGenerator.generateXmlFromSchema('multiple', criteria.selectedTags, i + 1);
        
        const file: GeneratedFile = {
          id: `multiple_${i + 1}`,
          name: `multiple_occurrence_${String(i + 1).padStart(3, '0')}.xml`,
          type: 'Multiple Occurrence',
          size: xmlContent.length,
          downloadUrl: `data:text/xml;charset=utf-8,${encodeURIComponent(xmlContent)}`,
          created: new Date().toISOString(),
          content: xmlContent
        };
        
        files.push(file);
        setGeneratedFiles([...files]);
        setGenerationProgress(((++fileIndex) / totalFiles) * 100);
      }

      // Generate anomaly files
      for (let i = 0; i < criteria.anomalies; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const xmlContent = xmlGenerator.generateXmlFromSchema('anomaly', criteria.selectedTags, i + 1);
        
        const file: GeneratedFile = {
          id: `anomaly_${i + 1}`,
          name: `anomaly_${String(i + 1).padStart(3, '0')}.xml`,
          type: 'Anomaly',
          size: xmlContent.length,
          downloadUrl: `data:text/xml;charset=utf-8,${encodeURIComponent(xmlContent)}`,
          created: new Date().toISOString(),
          content: xmlContent
        };
        
        files.push(file);
        setGeneratedFiles([...files]);
        setGenerationProgress(((++fileIndex) / totalFiles) * 100);
      }

      setGenerationProgress(100);
    } catch (error) {
      console.error('Generation error:', error);
      alert('Failed to generate files: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
    setIsGenerating(false);
  };

  const handleDownloadAll = async () => {
    if (generatedFiles.length === 0) {
      alert('No files to download');
      return;
    }

    // Create a ZIP file containing all generated files
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      
      generatedFiles.forEach(file => {
        if (file.content) {
          zip.file(file.name, file.content);
        }
      });
      
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'generated_payment_files.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      // Fallback: download files individually
      alert('Bulk download not available. Files can be downloaded individually.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Upload className="h-6 w-6 text-blue-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">File Upload</h2>
          </div>

          <div className="space-y-6">
            {/* XML File Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                XML File (for analysis)
              </label>
              <div
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                  uploadedFiles.xmlFile
                    ? 'border-green-300 bg-green-50'
                    : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                }`}
                onClick={() => document.getElementById('xml-file')?.click()}
              >
                <input
                  id="xml-file"
                  type="file"
                  accept=".xml"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setUploadedFiles(prev => ({ ...prev, xmlFile: file }));
                    }
                  }}
                  className="hidden"
                />
                {uploadedFiles.xmlFile ? (
                  <div className="flex items-center justify-center gap-2">
                    <FileCheck className="h-6 w-6 text-green-600" />
                    <span className="text-green-700 font-medium">
                      {uploadedFiles.xmlFile.name}
                    </span>
                  </div>
                ) : (
                  <div>
                    <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-gray-600">
                      Click to upload XML file for analysis
                    </p>
                    <p className="text-sm text-gray-400 mt-1">XML files only</p>
                  </div>
                )}
              </div>
            </div>

            {/* XSD File Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                XSD Schema File
              </label>
              <div
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                  uploadedFiles.xsdFile
                    ? 'border-green-300 bg-green-50'
                    : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                }`}
                onClick={() => document.getElementById('xsd-file')?.click()}
              >
                <input
                  id="xsd-file"
                  type="file"
                  accept=".xsd"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setUploadedFiles(prev => ({ ...prev, xsdFile: file }));
                    }
                  }}
                  className="hidden"
                />
                {uploadedFiles.xsdFile ? (
                  <div className="flex items-center justify-center gap-2">
                    <FileCheck className="h-6 w-6 text-green-600" />
                    <span className="text-green-700 font-medium">
                      {uploadedFiles.xsdFile.name}
                    </span>
                  </div>
                ) : (
                  <div>
                    <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-gray-600">
                      Click to upload XSD schema file
                    </p>
                    <p className="text-sm text-gray-400 mt-1">XSD files only</p>
                  </div>
                )}
              </div>
            </div>

            {/* Analysis Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={handleXmlAnalysis}
                disabled={!uploadedFiles.xmlFile || isAnalyzingXml}
                className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
              >
                {isAnalyzingXml ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <FileText className="h-5 w-5" />
                    Analyze XML
                  </>
                )}
              </button>

              <button
                onClick={handleSchemaAnalysis}
                disabled={!uploadedFiles.xsdFile || isAnalyzing}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <FileCheck className="h-5 w-5" />
                    Analyze Schema
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Analysis Results */}
        <div className="space-y-6">
          {/* XML Analysis Results */}
          <XmlAnalysisResults xmlAnalysis={xmlAnalysis} />
          
          {/* Schema Analysis Results */}
          <SchemaAnalysisResults schemaAnalysis={schemaAnalysis} />
        </div>
      </div>

      {/* Criteria Section - Pass schema analysis */}
      <CriteriaSection
        criteria={criteria}
        setCriteria={setCriteria}
        onGeneration={handleGeneration}
        isGenerating={isGenerating}
        xsdFile={uploadedFiles.xsdFile}
        schemaAnalysis={schemaAnalysis}
      />

      {/* Generation Results */}
      <GenerationResults
        generatedFiles={generatedFiles}
        generationProgress={generationProgress}
        isGenerating={isGenerating}
        onDownloadAll={handleDownloadAll}
      />
    </div>
  );
};

export default FileAnalyzerTab;