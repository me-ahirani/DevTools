import React, { useState } from 'react';
import { RefreshCw, Upload, FileCheck, Download, CheckCircle, XCircle, AlertCircle, FileText } from 'lucide-react';

interface ConversionResult {
  success: boolean;
  output?: string;
  errors?: string[];
  warnings?: string[];
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
}

const XmlXsdConverterTab: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'xml-to-xsd' | 'xsd-to-xml' | 'validate'>('xml-to-xsd');
  const [inputFile, setInputFile] = useState<File | null>(null);
  const [schemaFile, setSchemaFile] = useState<File | null>(null);
  const [inputContent, setInputContent] = useState<string>('');
  const [conversionResult, setConversionResult] = useState<ConversionResult | null>(null);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileUpload = (file: File, type: 'input' | 'schema') => {
    if (type === 'input') {
      setInputFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setInputContent(e.target?.result as string || '');
      };
      reader.readAsText(file);
    } else {
      setSchemaFile(file);
    }
  };

  const handleXmlToXsd = async () => {
    if (!inputContent) {
      alert('Please upload an XML file first');
      return;
    }

    setIsProcessing(true);
    try {
      // Basic XML to XSD conversion
      const xsdContent = generateXsdFromXml(inputContent);
      setConversionResult({
        success: true,
        output: xsdContent
      });
    } catch (error) {
      setConversionResult({
        success: false,
        errors: [error instanceof Error ? error.message : 'Conversion failed']
      });
    }
    setIsProcessing(false);
  };

  const handleXsdToXml = async () => {
    if (!inputContent) {
      alert('Please upload an XSD file first');
      return;
    }

    setIsProcessing(true);
    try {
      // Basic XSD to XML conversion
      const xmlContent = generateXmlFromXsd(inputContent);
      setConversionResult({
        success: true,
        output: xmlContent
      });
    } catch (error) {
      setConversionResult({
        success: false,
        errors: [error instanceof Error ? error.message : 'Conversion failed']
      });
    }
    setIsProcessing(false);
  };

  const handleValidation = async () => {
    if (!inputContent || !schemaFile) {
      alert('Please upload both XML and XSD files');
      return;
    }

    setIsProcessing(true);
    try {
      const schemaReader = new FileReader();
      schemaReader.onload = (e) => {
        const schemaContent = e.target?.result as string;
        const result = validateXmlAgainstXsd(inputContent, schemaContent);
        setValidationResult(result);
        setIsProcessing(false);
      };
      schemaReader.readAsText(schemaFile);
    } catch (error) {
      setValidationResult({
        isValid: false,
        errors: [error instanceof Error ? error.message : 'Validation failed']
      });
      setIsProcessing(false);
    }
  };

  const downloadResult = () => {
    if (!conversionResult?.output) return;

    const blob = new Blob([conversionResult.output], { type: 'text/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeMode === 'xml-to-xsd' ? 'generated.xsd' : 'generated.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Mode Selection */}
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-purple-100 rounded-lg">
            <RefreshCw className="h-6 w-6 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">XML/XSD Converter & Validator</h2>
        </div>

        <div className="flex flex-wrap gap-4 mb-6">
          <button
            onClick={() => setActiveMode('xml-to-xsd')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
              activeMode === 'xml-to-xsd'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            XML to XSD
          </button>
          <button
            onClick={() => setActiveMode('xsd-to-xml')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
              activeMode === 'xsd-to-xml'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            XSD to XML
          </button>
          <button
            onClick={() => setActiveMode('validate')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
              activeMode === 'validate'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Validate XML
          </button>
        </div>

        {/* File Upload Areas */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Input File */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              {activeMode === 'xml-to-xsd' ? 'XML File' : 
               activeMode === 'xsd-to-xml' ? 'XSD File' : 'XML File'}
            </label>
            <div
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                inputFile
                  ? 'border-green-300 bg-green-50'
                  : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
              }`}
              onClick={() => document.getElementById('input-file')?.click()}
            >
              <input
                id="input-file"
                type="file"
                accept={activeMode === 'xsd-to-xml' ? '.xsd' : '.xml'}
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'input')}
                className="hidden"
              />
              {inputFile ? (
                <div className="flex items-center justify-center gap-2">
                  <FileCheck className="h-6 w-6 text-green-600" />
                  <span className="text-green-700 font-medium">{inputFile.name}</span>
                </div>
              ) : (
                <div>
                  <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                  <p className="text-gray-600">
                    Click to upload {activeMode === 'xsd-to-xml' ? 'XSD' : 'XML'} file
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Schema File (for validation only) */}
          {activeMode === 'validate' && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                XSD Schema File
              </label>
              <div
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                  schemaFile
                    ? 'border-green-300 bg-green-50'
                    : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                }`}
                onClick={() => document.getElementById('schema-file')?.click()}
              >
                <input
                  id="schema-file"
                  type="file"
                  accept=".xsd"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'schema')}
                  className="hidden"
                />
                {schemaFile ? (
                  <div className="flex items-center justify-center gap-2">
                    <FileCheck className="h-6 w-6 text-green-600" />
                    <span className="text-green-700 font-medium">{schemaFile.name}</span>
                  </div>
                ) : (
                  <div>
                    <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-gray-600">Click to upload XSD schema file</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="flex justify-center">
          <button
            onClick={() => {
              if (activeMode === 'xml-to-xsd') handleXmlToXsd();
              else if (activeMode === 'xsd-to-xml') handleXsdToXml();
              else handleValidation();
            }}
            disabled={isProcessing || !inputFile || (activeMode === 'validate' && !schemaFile)}
            className="px-8 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors duration-200 flex items-center gap-2"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="h-5 w-5 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <RefreshCw className="h-5 w-5" />
                {activeMode === 'xml-to-xsd' ? 'Convert to XSD' :
                 activeMode === 'xsd-to-xml' ? 'Generate XML' : 'Validate'}
              </>
            )}
          </button>
        </div>
      </div>

      {/* Results */}
      {(conversionResult || validationResult) && (
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className={`p-2 rounded-lg ${
              (conversionResult?.success || validationResult?.isValid) ? 'bg-green-100' : 'bg-red-100'
            }`}>
              {(conversionResult?.success || validationResult?.isValid) ? (
                <CheckCircle className="h-6 w-6 text-green-600" />
              ) : (
                <XCircle className="h-6 w-6 text-red-600" />
              )}
            </div>
            <h2 className="text-2xl font-bold text-gray-900">
              {activeMode === 'validate' ? 'Validation Results' : 'Conversion Results'}
            </h2>
          </div>

          {/* Validation Results */}
          {validationResult && (
            <div className="space-y-4">
              <div className={`p-4 rounded-xl ${
                validationResult.isValid 
                  ? 'bg-green-50 border border-green-200' 
                  : 'bg-red-50 border border-red-200'
              }`}>
                <div className="flex items-center gap-2">
                  {validationResult.isValid ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-600" />
                  )}
                  <span className={`font-semibold ${
                    validationResult.isValid ? 'text-green-800' : 'text-red-800'
                  }`}>
                    {validationResult.isValid ? 'Validation Successful' : 'Validation Failed'}
                  </span>
                </div>
              </div>

              {validationResult.errors.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-red-800">Errors:</h3>
                  {validationResult.errors.map((error, index) => (
                    <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <p className="text-sm text-red-700">{error}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Conversion Results */}
          {conversionResult && (
            <div className="space-y-4">
              {conversionResult.success ? (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-800">Generated Output:</h3>
                    <button
                      onClick={downloadResult}
                      className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Download
                    </button>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-auto">
                    <pre className="text-sm text-gray-800 whitespace-pre-wrap">
                      {conversionResult.output}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <h3 className="font-semibold text-red-800">Conversion Errors:</h3>
                  {conversionResult.errors?.map((error, index) => (
                    <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <p className="text-sm text-red-700">{error}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Helper functions for conversion and validation
function generateXsdFromXml(xmlContent: string): string {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlContent, 'text/xml');
  
  if (doc.documentElement.tagName === 'parsererror') {
    throw new Error('Invalid XML content');
  }

  const rootElement = doc.documentElement;
  const namespace = rootElement.namespaceURI || 'http://example.com/schema';
  
  let xsd = `<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           targetNamespace="${namespace}"
           xmlns="${namespace}"
           elementFormDefault="qualified">

`;

  function analyzeElement(element: Element, processed: Set<string> = new Set()): string {
    const tagName = element.tagName;
    if (processed.has(tagName)) return '';
    processed.add(tagName);

    let elementDef = `  <xs:element name="${tagName}"`;
    
    if (element.children.length > 0) {
      elementDef += `>
    <xs:complexType>
      <xs:sequence>
`;
      
      const childElements = new Set<string>();
      Array.from(element.children).forEach(child => {
        childElements.add(child.tagName);
      });
      
      childElements.forEach(childTag => {
        elementDef += `        <xs:element name="${childTag}" type="xs:string" minOccurs="0"/>
`;
      });
      
      elementDef += `      </xs:sequence>
    </xs:complexType>
  </xs:element>

`;
    } else {
      elementDef += ` type="xs:string"/>

`;
    }
    
    return elementDef;
  }

  xsd += analyzeElement(rootElement);
  xsd += `</xs:schema>`;
  
  return xsd;
}

function generateXmlFromXsd(xsdContent: string): string {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xsdContent, 'text/xml');
  
  if (doc.documentElement.tagName === 'parsererror') {
    throw new Error('Invalid XSD content');
  }

  const elements = doc.querySelectorAll('xs\\:element, element');
  if (elements.length === 0) {
    throw new Error('No elements found in XSD schema');
  }

  const rootElement = elements[0];
  const rootName = rootElement.getAttribute('name') || 'root';
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<${rootName}>
  <!-- Sample data generated from XSD schema -->
  <sampleElement>Sample Value</sampleElement>
</${rootName}>`;

  return xml;
}

function validateXmlAgainstXsd(xmlContent: string, xsdContent: string): ValidationResult {
  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, 'text/xml');
    const xsdDoc = parser.parseFromString(xsdContent, 'text/xml');
    
    if (xmlDoc.documentElement.tagName === 'parsererror') {
      return { isValid: false, errors: ['Invalid XML syntax'] };
    }
    
    if (xsdDoc.documentElement.tagName === 'parsererror') {
      return { isValid: false, errors: ['Invalid XSD syntax'] };
    }
    
    // Basic validation - check if root element matches schema
    const xmlRoot = xmlDoc.documentElement.tagName;
    const schemaElements = Array.from(xsdDoc.querySelectorAll('xs\\:element, element'));
    const rootElementDefined = schemaElements.some(el => 
      el.getAttribute('name') === xmlRoot
    );
    
    if (!rootElementDefined) {
      return { 
        isValid: false, 
        errors: [`Root element '${xmlRoot}' not defined in schema`] 
      };
    }
    
    return { isValid: true, errors: [] };
  } catch (error) {
    return { 
      isValid: false, 
      errors: [error instanceof Error ? error.message : 'Unknown validation error'] 
    };
  }
}

export default XmlXsdConverterTab;