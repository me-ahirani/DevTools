import React, { useState } from 'react';

interface XsdTreeNodeProps {
  node: any;
  depth?: number;
}

const XsdTreeNode: React.FC<XsdTreeNodeProps> = ({ node, depth = 0 }) => {
  const [expanded, setExpanded] = useState(depth < 1); // Expand root by default
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div style={{ marginLeft: depth * 16 }}>
      <div
        className="flex items-center gap-2 cursor-pointer py-1"
        onClick={() => hasChildren && setExpanded((e) => !e)}
      >
        {hasChildren && (
          <span className="text-xs select-none">
            {expanded ? '▼' : '▶'}
          </span>
        )}
        <span className="font-mono text-blue-900 font-semibold">{node.name}</span>
        <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-700 ml-1">
          {node.isComplex ? 'Complex' : 'Simple'}
        </span>
        <span className="text-xs text-gray-600 ml-1">
          Occurs: {node.minOccurs}..{node.maxOccurs === 'unbounded' ? 'n' : node.maxOccurs}
        </span>
        <span className={`text-xs ml-1 ${node.isMandatory ? 'text-green-700' : 'text-yellow-700'}`}> 
          {node.isMandatory ? 'Mandatory' : 'Optional'}
        </span>
      </div>
      {hasChildren && expanded && (
        <div>
          {node.children.map((child: any, idx: number) => (
            <XsdTreeNode key={idx} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

export default XsdTreeNode;
