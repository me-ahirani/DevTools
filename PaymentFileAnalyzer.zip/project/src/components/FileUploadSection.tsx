import React, { useRef } from 'react';
import { Upload, FileCheck, AlertCircle, Loader2 } from 'lucide-react';

interface FileUploadSectionProps {
  uploadedFiles: {
    paymentFile: File | null;
    xsdFile: File | null;
  };
  setUploadedFiles: React.Dispatch<React.SetStateAction<{
    paymentFile: File | null;
    xsdFile: File | null;
  }>>;
  onValidation: () => void;
  isValidating: boolean;
}

const FileUploadSection: React.FC<FileUploadSectionProps> = ({
  uploadedFiles,
  setUploadedFiles,
  onValidation,
  isValidating,
}) => {
  const paymentFileRef = useRef<HTMLInputElement>(null);
  const xsdFileRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (type: 'paymentFile' | 'xsdFile') => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFiles(prev => ({ ...prev, [type]: file }));
    }
  };

  const handleDrop = (type: 'paymentFile' | 'xsdFile') => (
    event: React.DragEvent<HTMLDivElement>
  ) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      setUploadedFiles(prev => ({ ...prev, [type]: file }));
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-100 rounded-lg">
          <Upload className="h-6 w-6 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Upload Files</h2>
      </div>

      <div className="space-y-6">
        {/* Payment File Upload */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Payment XML File
          </label>
          <div
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
              uploadedFiles.paymentFile
                ? 'border-green-300 bg-green-50'
                : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
            }`}
            onClick={() => paymentFileRef.current?.click()}
            onDrop={handleDrop('paymentFile')}
            onDragOver={handleDragOver}
          >
            <input
              ref={paymentFileRef}
              type="file"
              accept=".xml"
              onChange={handleFileUpload('paymentFile')}
              className="hidden"
            />
            {uploadedFiles.paymentFile ? (
              <div className="flex items-center justify-center gap-2">
                <FileCheck className="h-6 w-6 text-green-600" />
                <span className="text-green-700 font-medium">
                  {uploadedFiles.paymentFile.name}
                </span>
              </div>
            ) : (
              <div>
                <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-gray-600">
                  Click to upload or drag and drop your payment XML file
                </p>
                <p className="text-sm text-gray-400 mt-1">XML files only</p>
              </div>
            )}
          </div>
        </div>

        {/* XSD File Upload */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            XSD Schema File
          </label>
          <div
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
              uploadedFiles.xsdFile
                ? 'border-green-300 bg-green-50'
                : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
            }`}
            onClick={() => xsdFileRef.current?.click()}
            onDrop={handleDrop('xsdFile')}
            onDragOver={handleDragOver}
          >
            <input
              ref={xsdFileRef}
              type="file"
              accept=".xsd"
              onChange={handleFileUpload('xsdFile')}
              className="hidden"
            />
            {uploadedFiles.xsdFile ? (
              <div className="flex items-center justify-center gap-2">
                <FileCheck className="h-6 w-6 text-green-600" />
                <span className="text-green-700 font-medium">
                  {uploadedFiles.xsdFile.name}
                </span>
              </div>
            ) : (
              <div>
                <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-gray-600">
                  Click to upload or drag and drop your XSD schema file
                </p>
                <p className="text-sm text-gray-400 mt-1">XSD files only</p>
              </div>
            )}
          </div>
        </div>

        {/* Validation Button */}
        <button
          onClick={onValidation}
          disabled={!uploadedFiles.paymentFile || !uploadedFiles.xsdFile || isValidating}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
        >
          {isValidating ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              Validating...
            </>
          ) : (
            <>
              <FileCheck className="h-5 w-5" />
              Validate File
            </>
          )}
        </button>

        {(!uploadedFiles.paymentFile || !uploadedFiles.xsdFile) && (
          <div className="flex items-center gap-2 text-amber-600 bg-amber-50 p-3 rounded-lg">
            <AlertCircle className="h-5 w-5" />
            <span className="text-sm">Upload both files to enable validation</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileUploadSection;