import React from 'react';
import { Download, Archive, FileText, Clock, CheckCircle } from 'lucide-react';
import { GeneratedFile } from '../types/types';

interface GenerationResultsProps {
  generatedFiles: GeneratedFile[];
  generationProgress: number;
  isGenerating: boolean;
  onDownloadAll: () => void;
}

const GenerationResults: React.FC<GenerationResultsProps> = ({
  generatedFiles,
  generationProgress,
  isGenerating,
  onDownloadAll,
}) => {
  const handleDownloadFile = async (file: GeneratedFile) => {
    try {
      if (file.downloadUrl.startsWith('data:')) {
        // Handle data URL downloads
        const a = document.createElement('a');
        a.href = file.downloadUrl;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      } else {
        // Handle regular URL downloads
        const response = await fetch(file.downloadUrl);
        if (response.ok) {
          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = file.name;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
        } else {
          throw new Error('Download failed');
        }
      }
    } catch (error) {
      alert('Failed to download file');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!isGenerating && generatedFiles.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gray-100 rounded-lg">
            <Download className="h-6 w-6 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Generation Results</h2>
        </div>
        <div className="text-center py-8">
          <Clock className="mx-auto h-12 w-12 text-gray-300 mb-3" />
          <p className="text-gray-500">Generate files to see results here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-green-100 rounded-lg">
          <Download className="h-6 w-6 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Generation Results</h2>
      </div>

      {/* Progress Bar */}
      {isGenerating && (
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Generating Files</span>
            <span className="text-sm text-gray-500">{Math.round(generationProgress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${generationProgress}%` }}
            ></div>
          </div>
        </div>
      )}

      {/* Generated Files List */}
      {generatedFiles.length > 0 && (
        <>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              Generated Files ({generatedFiles.length})
            </h3>
            <button
              onClick={onDownloadAll}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200 flex items-center gap-2"
            >
              <Archive className="h-4 w-4" />
              Download All (ZIP)
            </button>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {generatedFiles.map((file) => (
              <div
                key={file.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <FileText className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{file.name}</h4>
                    <div className="flex items-center gap-3 text-sm text-gray-500">
                      <span>{file.type}</span>
                      <span>•</span>
                      <span>{formatFileSize(file.size)}</span>
                      <span>•</span>
                      <span>{new Date(file.created).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleDownloadFile(file)}
                  className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-3 rounded-lg transition-colors duration-200 flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Download
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Completion Status */}
      {!isGenerating && generatedFiles.length > 0 && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-semibold text-green-800">Generation Complete</span>
          </div>
          <p className="text-sm text-green-700 mt-1">
            Successfully generated {generatedFiles.length} test files with actual XML content
          </p>
        </div>
      )}
    </div>
  );
};

export default GenerationResults;