import React from 'react';
import { BarChart3, Folder, FileText, Download, Eye, TrendingUp } from 'lucide-react';
import { Job, JobExecution } from '../types/jobTypes';

interface JobResultsProps {
  jobExecutions: JobExecution[];
  jobs: Job[];
}

const JobResults: React.FC<JobResultsProps> = ({ jobExecutions, jobs }) => {
  const completedExecutions = jobExecutions.filter(exec => exec.status === 'completed');
  
  const totalStats = completedExecutions.reduce(
    (acc, exec) => ({
      filesProcessed: acc.filesProcessed + (exec.results?.filesProcessed || 0),
      clustersCreated: acc.clustersCreated + (exec.results?.clustersCreated || 0),
      anomaliesFound: acc.anomaliesFound + (exec.results?.anomaliesFound || 0),
    }),
    { filesProcessed: 0, clustersCreated: 0, anomaliesFound: 0 }
  );

  const getJobName = (jobId: string) => {
    return jobs.find(job => job.id === jobId)?.name || jobId;
  };

  if (completedExecutions.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-blue-100 rounded-lg">
            <BarChart3 className="h-6 w-6 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Job Results & Analytics</h2>
        </div>
        <div className="text-center py-8">
          <TrendingUp className="mx-auto h-12 w-12 text-gray-300 mb-3" />
          <p className="text-gray-500">No completed jobs yet</p>
          <p className="text-sm text-gray-400">Execute jobs to see results and analytics here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-100 rounded-lg">
          <BarChart3 className="h-6 w-6 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Job Results & Analytics</h2>
      </div>

      {/* Overall Statistics */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 text-sm font-semibold">Files Processed</p>
              <p className="text-3xl font-bold text-blue-900">{totalStats.filesProcessed}</p>
            </div>
            <FileText className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-semibold">Clusters Created</p>
              <p className="text-3xl font-bold text-green-900">{totalStats.clustersCreated}</p>
            </div>
            <Folder className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-600 text-sm font-semibold">Anomalies Found</p>
              <p className="text-3xl font-bold text-red-900">{totalStats.anomaliesFound}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-red-600" />
          </div>
        </div>
      </div>

      {/* Job Results Details */}
      <div className="space-y-6">
        <h3 className="text-lg font-semibold text-gray-800">Detailed Results</h3>
        
        {completedExecutions.map((execution) => (
          <div key={execution.jobId} className="border border-gray-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-lg font-semibold text-gray-900">
                  {getJobName(execution.jobId)}
                </h4>
                <p className="text-sm text-gray-600">
                  Completed: {execution.endTime ? new Date(execution.endTime).toLocaleString() : 'N/A'}
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  View Details
                </button>
                <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Download
                </button>
              </div>
            </div>

            {execution.results && (
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Files Processed</p>
                  <p className="text-2xl font-bold text-gray-900">{execution.results.filesProcessed}</p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Clusters Created</p>
                  <p className="text-2xl font-bold text-gray-900">{execution.results.clustersCreated}</p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Anomalies Found</p>
                  <p className="text-2xl font-bold text-gray-900">{execution.results.anomaliesFound}</p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Processing Time</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {execution.startTime && execution.endTime
                      ? `${Math.round((new Date(execution.endTime).getTime() - new Date(execution.startTime).getTime()) / 1000)}s`
                      : 'N/A'}
                  </p>
                </div>
              </div>
            )}

            {execution.results?.outputPath && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm font-semibold text-blue-800">Output Location</p>
                <p className="text-sm text-blue-700 font-mono">{execution.results.outputPath}</p>
              </div>
            )}

            {execution.results?.clusterDetails && (
              <div className="mt-4">
                <h5 className="font-semibold text-gray-800 mb-2">Cluster Details</h5>
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.entries(execution.results.clusterDetails).map(([clusterName, count]) => (
                    <div key={clusterName} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium text-gray-700">{clusterName}</span>
                      <span className="text-sm font-bold text-gray-900">{count} files</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default JobResults;