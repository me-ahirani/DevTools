import React, { useState } from 'react';
import { FileText, Play, Settings, RefreshCw } from 'lucide-react';
import FileAnalyzerTab from './components/FileAnalyzerTab';
import JobExecutionTab from './components/JobExecutionTab';
import XmlXsdConverterTab from './components/XmlXsdConverterTab';

function App() {
  const [activeTab, setActiveTab] = useState<'analyzer' | 'jobs' | 'converter'>('analyzer');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex flex-col">
      {/* Header */}
      <header className="bg-blue-600 shadow-lg border-b border-blue-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold text-white">H2H DevTool</h1>
            </div>
            <div className="text-sm text-blue-100">
              Payment File Analysis & Processing Suite
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Page Title */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-blue-600 rounded-xl">
                <FileText className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-4xl font-bold text-gray-900">Payment File Analyzer</h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive payment file analysis, validation, conversion, and automated job execution system
            </p>
          </div>

          {/* Tab Navigation */}
          <div className="flex justify-center mb-8">
            <div className="bg-white rounded-xl shadow-lg p-1 flex">
              <button
                onClick={() => setActiveTab('analyzer')}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                  activeTab === 'analyzer'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <FileText className="h-5 w-5" />
                Schema Analyzer
              </button>
              <button
                onClick={() => setActiveTab('converter')}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                  activeTab === 'converter'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <RefreshCw className="h-5 w-5" />
                XML/XSD Converter
              </button>
              <button
                onClick={() => setActiveTab('jobs')}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                  activeTab === 'jobs'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <Play className="h-5 w-5" />
                Job Execution
              </button>
            </div>
          </div>

          {/* Tab Content */}
          {activeTab === 'analyzer' && <FileAnalyzerTab />}
          {activeTab === 'converter' && <XmlXsdConverterTab />}
          {activeTab === 'jobs' && <JobExecutionTab />}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-400">
                © 2024 JPMorgan Chase & Co. All rights reserved.
              </div>
            </div>
            <div className="flex items-center gap-6 text-sm text-gray-400">
              <span>H2H DevTool v1.0</span>
              <span>•</span>
              <span>Payment Processing Suite</span>
              <span>•</span>
              <span>Enterprise Solutions</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-800">
            <div className="text-xs text-gray-500 text-center">
              This tool is designed for internal use by authorized personnel only. 
              All data processing complies with JPMC security and privacy policies.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;